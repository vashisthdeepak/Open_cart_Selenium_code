/**
 * 
 */
package ExcelResults;

import org.automationtesting.excelreport.Xl;

/**
 * @author Mohit
 *
 */
public class Generate_Excel {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		Xl.generateReport("excel-report.xlsx");
		
		Xl.generateReport("C:\\Users\\Mohit\\Desktop\\Automation_Report", "excel-report.xlsx");




	}
}