package ExcelResults;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.common.excelreport.ExcelReportGenerator;

public class ExcelGenerate {
	         
	public static void main(String[] args) {
				try {
					ExcelReportGenerator.generateExcelReport("MyProject.xlsx", "D:\\workspace");
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SAXException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		System.out.println("Report Generated");
		

	}

}
