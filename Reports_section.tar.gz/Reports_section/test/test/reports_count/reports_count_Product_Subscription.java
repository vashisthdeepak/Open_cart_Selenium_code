package test.reports_count;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.reports_count.Product_Subscription;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;


public class reports_count_Product_Subscription extends BaseClass {
 
  @Test(priority=1)
  public void Verify_element(){
	  Product_Subscription obj = PageFactory.initElements(driver, Product_Subscription.class);
  obj.Verify_element_method();
}

  @Test(priority=2)
  public void valid(){
	  Product_Subscription obj = PageFactory.initElements(driver, Product_Subscription.class);
  obj.valid_method();
}
  
  @Test(priority=3)
  public void invalid(){
	  Product_Subscription obj = PageFactory.initElements(driver, Product_Subscription.class);
	  obj.invalid_method();	  
	  
  }
  
  @AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
};