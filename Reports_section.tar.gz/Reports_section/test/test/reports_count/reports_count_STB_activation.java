package test.reports_count;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.reports_count.STB_Activation;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;


public class reports_count_STB_activation extends BaseClass {
 
  @Test(priority=1)
  public void Verify_element(){
  STB_Activation obj = PageFactory.initElements(driver, STB_Activation.class);
  obj.Verify_element_method();
}

  @Test(priority=2)
  public void invalid(){
	  STB_Activation obj = PageFactory.initElements(driver, STB_Activation.class);
	  obj.invalid_method();	  
	  
  }
  
  @AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}