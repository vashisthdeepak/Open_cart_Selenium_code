package test.reports_case;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_case.reports_case_webelement;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;


public class reports_case extends BaseClass {



		@Test(priority=1)
		//----------------------------------Reports->Historical Activations and Historical De-activations || Reports Total number of Subscriber on the network Active and De-active count---------------------------
	
		public void Reports_Historical_STB_Activations_and_STB_De_activations_and_Total_No_Of_Subscribers_On_The_network() throws Throwable{	
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Reports_Historical_STB_Activations_and_STB_De_activations_and_Total_No_Of_Subscribers_On_The_network_method();
		}
	
		@Test(priority=2)
		public void Reports_count_STB_activation() throws IOException{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Reports_count_STB_activation_method(); 
	
		}
	
		@Test(priority=3)
		public void Reports_count_STB_Deactivation() throws IOException{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Reports_count_STB_Deactivation_method(); 
	
		}
	
		@Test(priority=4)
		public void Reports_List_STB_activation() throws IOException{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Reports_List_STB_activation_method(); 
	
		}
	
		@Test(priority=5)
		public void Reports_List_STB_Deactivation() throws IOException{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Reports_List_STB_Deactivation_method(); 
	
		} 
	
		@Test(priority=6)
		public void Reports_Logs() throws IOException, InterruptedException{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Logs_method(); 
	
		} 
	
		@Test(priority=7)
		public void STB_History() throws IOException, InterruptedException{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.STB_History_method(); 
	
		} 
	
		@Test(priority=8)
		public void Reports_historical_Package_Subscription_and_Desubcription() throws Throwable{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Reports_historical_Package_Subscription_and_Desubcription_method(); 
	
		} 
	
		@Test(priority=9)
		public void Reports_List_and_Count_Package_Subscription() throws Throwable{
			reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
			obj.Reports_List_and_Count_Package_Subscription_and_STB_wise_change_of_Package_Product_method(); 
	
		} 




//	@Test(priority=11)
//	public void Reprts_List_Prdct_Subs(){
//		reports_case_webelement obj = PageFactory.initElements(driver, reports_case_webelement.class);
//		obj.Reprts_List_Count_Prdct_Subs_method();
//
//	}

	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
			TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	} 






















};