package test.category;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import test.baseclass.BaseClass;

import com.category_webelement.webelement_Category;

public class insert_category extends BaseClass {
	
	    
	    @Test(priority=2)
	    public void categoryadd()
	    {
	    	webelement_Category obj=PageFactory.initElements(driver,webelement_Category.class);
	    	obj.Insert_Categories_method();
	    }
	    
	    @Test(priority=3)
	    public void categoryaddwithparent()
	    {
	    	webelement_Category obj=PageFactory.initElements(driver,webelement_Category.class);
	    	obj.Insert_Categories_methodwithparent();
	    }
	    
	    @Test(priority=4)
	    public void Special_Character_in_Column_method()
	    {
	    	webelement_Category obj = PageFactory.initElements(driver, webelement_Category.class);
	    	obj.Catalog_Categories_Special_Character_in_Column_method(driver);	    	
	    }
	    
	    @Test(priority=5)
	    public void Category_without_entering_the_Category_Name()
	    {
	    	webelement_Category obj=PageFactory.initElements(driver,webelement_Category.class);
	    	obj.Category_without_entering_the_Category_Name_method(driver);
	    }
			
	    @Test(priority=6)
	    public void Invalid_Category_Name()
	    {
	    	webelement_Category obj=PageFactory.initElements(driver,webelement_Category.class);
	    	obj.Invalid_Category_Name_method(driver);
	    	
	    }
	
	   @Test(priority=7)
       public void Cancel_functionality(){
	   webelement_Category obj=PageFactory.initElements(driver,webelement_Category.class);   
	   obj.Cancel_functionality_method(driver);   
	   }
	   
	   @AfterMethod
		public void TestOnFail(ITestResult result) 

		{  
		  if(ITestResult.FAILURE==result.getStatus())
		 	{
		 	//To take screenshot on fail of test methods
		 	webelement_Category Category = PageFactory.initElements(driver,webelement_Category.class);	 	
		 	String methodName = result.getName().toString().trim();
		    //System.out.println(methodName + ":Screenshot taken");   	  
		    Category.Screenshot_of_All_Tab(methodName);   
		 }	
	  }		
	   
	   
}
