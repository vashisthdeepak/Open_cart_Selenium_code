package test.Reports_As_on_date;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_As_on_date.Broadcaster_Report;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;

public class Reports_Broadcaster_Report extends BaseClass{

	@Test
	private void Verify_element() throws Throwable{
		
		Broadcaster_Report obj = PageFactory.initElements(driver, Broadcaster_Report.class);
		obj.Verify_element_method();
	}

	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}
