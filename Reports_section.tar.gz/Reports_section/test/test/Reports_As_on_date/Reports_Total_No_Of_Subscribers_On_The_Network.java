package test.Reports_As_on_date;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.reports_As_on_date.Total_No_Of_Subscribers_On_The_Network;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;

public class Reports_Total_No_Of_Subscribers_On_The_Network extends BaseClass{

	@Test
	private void Verify_element() throws Throwable{
		
		Total_No_Of_Subscribers_On_The_Network obj = PageFactory.initElements(driver, Total_No_Of_Subscribers_On_The_Network.class);
		obj.Verify_element_method();
	}
//	@Test
//	private void invalid(){
//		
//		Total_No_Of_Subscribers_On_The_Network obj = PageFactory.initElements(driver, Total_No_Of_Subscribers_On_The_Network.class);
//		obj.invalid_method();
//	
//	}

	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}
