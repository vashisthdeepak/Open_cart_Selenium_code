package test.reports_logs;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.reports_logs.Reports_complete_Logs;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;

public class Complete_Logs extends BaseClass{

	
	
	@Test(priority=1)
	public void verify_elements(){
		Reports_complete_Logs obj = PageFactory.initElements(driver, Reports_complete_Logs.class);
		obj.Verify_element_method();
		
	}
	
	@Test(priority=2)
	public void valid(){
		Reports_complete_Logs obj = PageFactory.initElements(driver, Reports_complete_Logs.class);
		obj.valid_method();
		
	}	
	

	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}		