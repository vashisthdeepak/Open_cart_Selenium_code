package test.baseclass;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;


public class PDFRead {

	public static void ReadPDF(String unzippath) throws IOException {
		    PDDocument pdDoc;		
			pdDoc = PDDocument.load( new File(unzippath));
			System.out.println(pdDoc.getNumberOfPages());		
			PDFTextStripper g = new PDFTextStripper();
			String data = g.getText(pdDoc);
			System.out.println(data);
	}
}
