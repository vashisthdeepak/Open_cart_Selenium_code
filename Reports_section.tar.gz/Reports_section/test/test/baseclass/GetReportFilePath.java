package test.baseclass;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;

public class GetReportFilePath {
	
      public static void DeleteFolderfiles() throws IOException {
    	//Specify directory name where you want to delete all files
		  File directoryZip = new File("C:\\Users\\Mohit\\Downloads\\");
		  FileUtils.cleanDirectory(directoryZip); 
		  
		  File directoryUnzip = new File("D:\\Unzip\\");
		  FileUtils.cleanDirectory(directoryUnzip);
		  
		  //To check if the folder is available and if not will create new folder
		  File theDirzip = new File("C:\\Users\\Mohit\\Downloads\\");		  
		  if (!theDirzip.exists()) {
			    System.out.println("creating directory: " + theDirzip.getName());
			    boolean result = false;
			    try{
			    	theDirzip.mkdir();
			        result = true;
			    } 
			    catch(SecurityException se){
			        //handle it
			    }        
			    if(result) {    
			        System.out.println("DIR created");  
			    }
			}  
		  
		  
		//To check if the folder is available and if not will create new folder
		  File theDirUnzip = new File("D:\\Unzip");		  
		  if (!theDirUnzip.exists()) {
			    System.out.println("creating directory: " + theDirUnzip.getName());
			    boolean result = false;
			    try{
			    	theDirUnzip.mkdir();
			        result = true;
			    } 
			    catch(SecurityException se){
			        //handle it
			    }        
			    if(result) {    
			        System.out.println("DIR created");  
			    }
			}  
      }	
	
	  public static void FileNameRead() throws Throwable{
		  		  
		  //Specify folder name where the file gets downloaded
		  File file = new File("C:\\Users\\Mohit\\Downloads\\");
	      File[] files = file.listFiles();
	      SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
		 
	      //Get the current time stamp
	      Date date = new Date();   
	      System.out.println("Current Date" + formatter.format(date));
	      Thread.sleep(2000);
	      //To get all file names and its modified time
	      for(File f: files){    	  
	          //System.out.println(f.getName());
	          Date ModifyTime = new Date(f.lastModified());
	          // System.out.println("Modify"+formatter.format(ModifyTime));  
	          
	          //Adds 5 seconds with the downloaded file time
	          ModifyTime.setSeconds(ModifyTime.getSeconds()+5);
	          //System.out.println(ModifyTime);
	          
	          //Compare with the current time and get full path of the file
	          if(ModifyTime.after(date)) {
	          System.out.println(f.getAbsolutePath());
	          String Zippath1 = f.getAbsolutePath();
	          
	          //To unzip the file
	          UnzipFolder.unzip(Zippath1, "D://Unzip");
	          }
	     }
	} 
	  
	public static void FileNameReadUnzip() throws IOException {
		//Specify the destination folder where the unzipped files are there
		File file = new File("D:\\Unzip");
	    File[] files = file.listFiles();
	    
	    for(File f: files){    	  
	          //System.out.println(f.getName());
	          String unzippath = f.getAbsolutePath();
	          System.out.println(unzippath);
	         // System.out.println("jkfdl");
	          //Reads the data from the PDF
	         // PDFRead.ReadPDF(unzippath);
	          }
	}

	public static PDDocument PDF_Data_Reader() throws Throwable{
		
		PDDocument pdDoc;
		//String value = Read_PDF_name();
		pdDoc = PDDocument.load( new File("D:\\Unzip"));
		//System.out.println(pdDoc.getNumberOfPages());
		return pdDoc;
		
}	
	
   public static String current_date(){
	
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String current_date = dateFormat.format(date);
		return current_date;
}
   public static String current_date_only(){
		
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		String current_date = dateFormat.format(date);
		return current_date;
}
	
   public static String Read_Unzipped_file_name() throws Throwable {
		String Zippath1 = null;

		File file = new File("D:\\Unzip");
		File[] files = file.listFiles();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

		// Get the current time stamp
		Date date = new Date();
		Thread.sleep(1000);
		for (File f : files) {
			Date ModifyTime = new Date(f.lastModified());
			ModifyTime.setSeconds(ModifyTime.getSeconds() + 5);

			if (ModifyTime.after(date)) {
				System.out.println(f.getAbsolutePath());
				Zippath1 = f.getName();

			}
		}

		return Zippath1;
	}

	public static String Read_PDF_name() throws Throwable {
		String Zippath1 = null;

		File file = new File("D:\\Unzip\\");
		File[] files = file.listFiles();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

		// Get the current time stamp
		Date date = new Date();
		Thread.sleep(1000);
		for(File f:files) {
			Date ModifyTime = new Date(f.lastModified());
			ModifyTime.setSeconds(ModifyTime.getSeconds() + 5);

			if (ModifyTime.after(date)) {
				System.out.println(f.getAbsolutePath());
				Zippath1 = f.getName();

			}
		}

		return Zippath1;
	}
	
	public static String date_time_stamp() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		// Get the current time stamp
		Date date = new Date();
		return formatter.format(date);

	}
	
	public static String current_year() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
		// Get the current time stamp
		Date date = new Date();
		return formatter.format(date);

	}
	public static String current_month() {
		SimpleDateFormat formatter = new SimpleDateFormat("MMM");
		// Get the current time stamp
		Date date = new Date();
		return formatter.format(date);

	}
	
	
	
	
}