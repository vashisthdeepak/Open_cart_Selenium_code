package test.reports_Subscription_Sent_in_Particular_Month;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_Subscription_Sent_in_Particular_Month.Reports_Package_Wise_Subscription_Sent_in_particular_month;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;

public class Package_Wise_Subscription_Sent_in_particular_month extends BaseClass{

	
	
	@Test(priority=1)
	public void verify_elements(){
		Reports_Package_Wise_Subscription_Sent_in_particular_month obj = PageFactory.initElements(driver, Reports_Package_Wise_Subscription_Sent_in_particular_month.class);
		obj.Verify_element_method();
		
	}
	
	@Test(priority=2)
	public void valid(){
		Reports_Package_Wise_Subscription_Sent_in_particular_month obj = PageFactory.initElements(driver, Reports_Package_Wise_Subscription_Sent_in_particular_month.class);
		obj.valid_method();
		
	}
	
	
	@Test(priority=3)
	public void Invalid(){
		Reports_Package_Wise_Subscription_Sent_in_particular_month obj = PageFactory.initElements(driver, Reports_Package_Wise_Subscription_Sent_in_particular_month.class);
		obj.Invalid_method();
		
	}
	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}		