package test.reports_package_details;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_Package_details.Reports_Alacarte_details;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;

public class Alacarte_details extends BaseClass{

	
	
	@Test(priority=1)
	public void verify_elements(){
		Reports_Alacarte_details obj = PageFactory.initElements(driver, Reports_Alacarte_details.class);
		obj.Verify_element_method();
		
	}
	
	@Test(priority=2)
	public void valid(){
		Reports_Alacarte_details obj = PageFactory.initElements(driver, Reports_Alacarte_details.class);
		obj.valid_method();
		
	}
	
	
	@Test(priority=3)
	public void Invalid(){
		Reports_Alacarte_details obj = PageFactory.initElements(driver, Reports_Alacarte_details.class);
		obj.Invalid_methos();
		
	}
	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}		