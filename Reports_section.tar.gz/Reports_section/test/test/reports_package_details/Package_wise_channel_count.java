package test.reports_package_details;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_Package_details.Reports_Package_details_Package_wise_channel_count;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;

public class Package_wise_channel_count extends BaseClass{

	
	
	@Test(priority=1)
	public void verify_elements(){
		Reports_Package_details_Package_wise_channel_count obj = PageFactory.initElements(driver, Reports_Package_details_Package_wise_channel_count.class);
		obj.Verify_element_method();
    }
	
	@Test(priority=2)
	public void valid(){
		Reports_Package_details_Package_wise_channel_count obj = PageFactory.initElements(driver, Reports_Package_details_Package_wise_channel_count.class);
		obj.valid_method();
	}
	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}
