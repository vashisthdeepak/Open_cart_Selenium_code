package test.reports.list;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_list.*;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;


public class reports_list_STB_activation extends BaseClass {
 
  @Test(priority=1)
  public void Verify_element(){
	  STB_activation obj = PageFactory.initElements(driver, STB_activation.class);
  obj.Verify_element_method();
}

  @Test(priority=2)
  public void valid(){
	  STB_activation obj = PageFactory.initElements(driver, STB_activation.class);
  obj.valid_method();
}
  
  @Test(priority=3)
  public void invalid(){
	  STB_activation obj = PageFactory.initElements(driver, STB_activation.class);
	  obj.invalid_method();	  
	  
  }
  
  @AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
  
  
  
  
  
  
};