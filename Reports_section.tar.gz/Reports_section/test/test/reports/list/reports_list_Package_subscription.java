package test.reports.list;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_list.*;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;


public class reports_list_Package_subscription extends BaseClass {
 
  @Test(priority=1)
  public void Verify_element(){
	  package_subscription obj = PageFactory.initElements(driver, package_subscription.class);
  obj.Verify_element_method();
}

  @Test(priority=2)
  public void valid(){
	  package_subscription obj = PageFactory.initElements(driver, package_subscription.class);
  obj.valid_method();
}
  
  @Test(priority=3)
  public void invalid(){
	  package_subscription obj = PageFactory.initElements(driver, package_subscription.class);
	  obj.invalid_method();	  
	  
  }
  
  @AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	} 
  
  
  
  
  
  
};