package test.reports;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports.Reports_Historical_Package_Subscription;


import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;
public class Historical_Package_Subscription extends BaseClass {

	@Test(priority=1)
	  public void verify_element() {
		
		  Reports_Historical_Package_Subscription obj= PageFactory.initElements(driver, Reports_Historical_Package_Subscription.class);
		  obj.verify_element_method(driver);
	  }
	  
	  @Test(priority=2)
	  public void Validation_Generate_button() {
		
		  Reports_Historical_Package_Subscription obj = PageFactory.initElements(driver, Reports_Historical_Package_Subscription.class);
		  obj.Validation_Generate_button_method(driver);
	  }
	  
	  @Test(priority=3)
  public void invalid_test_cases() {
		
		  Reports_Historical_Package_Subscription obj = PageFactory.initElements(driver, Reports_Historical_Package_Subscription.class);
		  obj.invalid_test_cases_method(driver);
	  }
	  
	  
	  @Test(priority=4)
	public void Validation() throws Throwable{
		
		  Reports_Historical_Package_Subscription obj = PageFactory.initElements(driver, Reports_Historical_Package_Subscription.class);
		  obj.Validation_method(driver);
	}
	  
	
	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}
