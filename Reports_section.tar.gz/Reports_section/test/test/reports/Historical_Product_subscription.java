package test.reports;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports.Reports_Historical_product_subscription;


import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;
public class Historical_Product_subscription extends BaseClass {

	@Test(priority=1)
	  public void verify_element() {
		
		  Reports_Historical_product_subscription obj= PageFactory.initElements(driver, Reports_Historical_product_subscription.class);
		  obj.verify_element_method(driver);
	  }
	  
	  @Test(priority=2)
	  public void Validation_Generate_button() {
		
		  Reports_Historical_product_subscription obj = PageFactory.initElements(driver, Reports_Historical_product_subscription.class);
		  obj.Validation_Generate_button_method(driver);
	  }
	  
	  @Test(priority=3)
	  public void invalid_test_cases() {
		
		  Reports_Historical_product_subscription obj = PageFactory.initElements(driver, Reports_Historical_product_subscription.class);
		  obj.invalid_test_cases_method(driver);
	  }
	  
	  
	  @Test(priority=4)
	public void Validation() throws Throwable{
		
		  Reports_Historical_product_subscription obj = PageFactory.initElements(driver, Reports_Historical_product_subscription.class);
		  obj.Validation_method(driver);
	}
	  
	  
		@Test(priority=5)
		public void change_customer_name_check_in_PDF() throws Throwable{
			
			Reports_Historical_product_subscription obj = PageFactory.initElements(driver, Reports_Historical_product_subscription.class);
			  obj.change_customer_name_check_in_PDF_method(driver);
		}
	
	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}
