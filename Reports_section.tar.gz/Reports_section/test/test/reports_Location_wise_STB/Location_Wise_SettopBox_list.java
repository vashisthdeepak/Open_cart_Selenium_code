package test.reports_Location_wise_STB;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.reports_Location_Wise_SettopBox.Reports_Location_Wise_SettopBox_List;

import screenshot.TakeScreenShoot;
import test.baseclass.BaseClass;

public class Location_Wise_SettopBox_list extends BaseClass{

	
	
	@Test(priority=1)
	public void verify_elements(){
		Reports_Location_Wise_SettopBox_List obj = PageFactory.initElements(driver, Reports_Location_Wise_SettopBox_List.class);
		obj.Verify_element_method();
		
	}
	
	@Test(priority=2)
	public void valid(){
		Reports_Location_Wise_SettopBox_List obj = PageFactory.initElements(driver, Reports_Location_Wise_SettopBox_List.class);
		obj.valid_method();
		
	}
	
	
	@Test(priority=3)
	public void Invalid(){
		Reports_Location_Wise_SettopBox_List obj = PageFactory.initElements(driver, Reports_Location_Wise_SettopBox_List.class);
		obj.Invalid_method();
		
	}
	@AfterMethod()
	public void teardown(ITestResult result) throws IOException
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
		TakeScreenShoot.TakeScreenshot(result.getName().toString().trim());
		}	
	}
}		