package Channel_Addition_demo;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
public class Channel_addition {






	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver;
		  String baseUrl;
		  @SuppressWarnings("unused")
		boolean acceptNextAlert = true;
		  @SuppressWarnings("unused")
		StringBuffer verificationErrors = new StringBuffer();

		 
		  
		    driver = new FirefoxDriver();
		    baseUrl = "http://42.104.126.159/sms/upload/admin/";
		    driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		    driver.manage().window().maximize();
		  

		 
		  /* Login into the application*/
		 
			  driver.get(baseUrl);
			  driver.findElement(By.name("username")).clear();
			  driver.findElement(By.name("username")).sendKeys("admin");  
			  driver.findElement(By.name("password")).clear();
			  driver.findElement(By.name("password")).sendKeys("passwd");
			  driver.findElement(By.linkText("Login")).click();
			  
		 /* Initialize the variable for looping*/
			  int i;
			  int g=1360;
			  int j=1360;
			  int k=1360;
			  int h=1360;
			  for(i=1360;i<=1420;i++){

		    //Tree menu structure
			driver.findElement(By.linkText("Catalog")).click();
		    driver.findElement(By.linkText("Channels")).click();
		    driver.findElement(By.linkText("Insert")).click();
		  
		    //General Tab
		    driver.findElement(By.name("broadcaster_channel_name")).clear();
		    driver.findElement(By.name("broadcaster_channel_name")).sendKeys("Channel "+g);
		    
		    //Data Tab
		    driver.findElement(By.linkText("Data")).click();
		    driver.findElement(By.name("lcn")).clear();
		    driver.findElement(By.name("lcn")).sendKeys(""+h);
		    driver.findElement(By.name("model")).clear();
		    driver.findElement(By.name("model")).sendKeys(""+g);
		    driver.findElement(By.name("service_id")).clear();
		    driver.findElement(By.name("service_id")).sendKeys(""+j);
		    driver.findElement(By.name("access_criteria")).clear();
		    driver.findElement(By.name("access_criteria")).sendKeys(""+k);
		    driver.findElement(By.name("price")).clear();
		    driver.findElement(By.name("price")).sendKeys("100");
		  //  new Select(driver.findElement(By.name("tax_class_id"))).selectByVisibleText("GST Test");
		    
		    driver.findElement(By.linkText("Browse")).click();
		    //driver.findElement(By.xpath("//*[@id='tab-data']/table/tbody/tr[6]/td[2]/div/a[1]")).click();
			driver.switchTo().frame(1);
			Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			Actions action = new Actions(driver);
		    WebElement element=driver.findElement(By.xpath("//*[@id='column-right']/div/a[2]/img"));
		    action.doubleClick(element).perform();

			//Double click action on the image folder
			/*Actions action1 = new Actions(driver);
			WebElement element1=driver.findElement(By.xpath("//*[@id='top']/a"));
			Thread.sleep(1000);
			action1.doubleClick(element1).perform();
			Thread.sleep(1000);
				   
			//click action on the channel folder
			driver.findElement(By.xpath("//*[@id='top']/ul/li[1]/a")).click();
			Thread.sleep(1000);
			Actions action2 = new Actions(driver);   
			Thread.sleep(1000);
			WebElement element2=driver.findElement(By.xpath("//*[@id='column-right']/div/a[50]/img"));
			action2.doubleClick(element2).perform();*/
		    
		    driver.findElement(By.linkText("Links")).click();
		    driver.findElement(By.name("category")).clear();
		    driver.findElement(By.name("category")).sendKeys("Movies");
		    driver.findElement(By.linkText("Channel Packages  >  Movies")).click();
		    driver.findElement(By.linkText("Option")).click();
		    driver.findElement(By.name("option")).clear();
		    driver.findElement(By.name("option")).sendKeys("Subscription");
		    driver.findElement(By.linkText("Subscription")).click();
		    driver.findElement(By.linkText("Add Option Value")).click();
		    
		    new Select(driver.findElement(By.name("product_option[0][product_option_value][0][option_value_id]"))).selectByVisibleText("1 month");
		    driver.findElement(By.name("product_option[0][product_option_value][0][price]")).clear();
		    driver.findElement(By.name("product_option[0][product_option_value][0][price]")).sendKeys("30");
		    
		    driver.findElement(By.linkText("Add Option Value")).click();
		    new Select(driver.findElement(By.name("product_option[0][product_option_value][1][option_value_id]"))).selectByVisibleText("3 months");
		    driver.findElement(By.name("product_option[0][product_option_value][1][price]")).clear();
		    driver.findElement(By.name("product_option[0][product_option_value][1][price]")).sendKeys("60");
		    
		    driver.findElement(By.linkText("Add Option Value")).click();
		    new Select(driver.findElement(By.name("product_option[0][product_option_value][2][option_value_id]"))).selectByVisibleText("6 months");
		    driver.findElement(By.name("product_option[0][product_option_value][2][price]")).clear();
		    driver.findElement(By.name("product_option[0][product_option_value][2][price]")).sendKeys("90");
		    
		    driver.findElement(By.linkText("Add Option Value")).click();
		    new Select(driver.findElement(By.name("product_option[0][product_option_value][3][option_value_id]"))).selectByVisibleText("9 months");
		    driver.findElement(By.name("product_option[0][product_option_value][3][price]")).clear();
		    driver.findElement(By.name("product_option[0][product_option_value][3][price]")).sendKeys("120");
		    
		    driver.findElement(By.linkText("Add Option Value")).click();
		    new Select(driver.findElement(By.name("product_option[0][product_option_value][4][option_value_id]"))).selectByVisibleText("12 months");
		    driver.findElement(By.name("product_option[0][product_option_value][4][price]")).clear();
		    driver.findElement(By.name("product_option[0][product_option_value][4][price]")).sendKeys("150");
		    
		    driver.findElement(By.linkText("Submit")).click();
		    g=g+1;
		    j=j+1;
		    k=k+1;
		    h=h+1;
		    }
			  
		  

		
		
	
	}
		 
		  
}	
		
		

