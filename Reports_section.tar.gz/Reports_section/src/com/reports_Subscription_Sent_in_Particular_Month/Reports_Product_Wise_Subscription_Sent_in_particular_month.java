package com.reports_Subscription_Sent_in_Particular_Month;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class Reports_Product_Wise_Subscription_Sent_in_particular_month extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Subscription Sent in Particular Month")
	WebElement Subscription_Sent_in_Particular_Month;
	
	@FindBy(xpath="//a[text()='Product Wise Subscription']")
	WebElement Product_Wise_Subscription;
			
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Product_Wise_Subscription_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Product Name']")
	WebElement subheading_Product_Name;
		
	@FindBy(xpath="//td[@class='left' and text()='STB No.']")
	WebElement subheading_STB_No;
		
	@FindBy(xpath="//td[@class='left' and text()='Subscription Date']")
	WebElement subheading_Subscription_Date;
	
	@FindBy(xpath="//td[@class='left' and text()='Expiry Date']")
	WebElement subheading_Expiry_Date;
			
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Product_Wise_Subscription;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[5]")
	WebElement details_Product_Name;
			
	@FindBy(xpath="(//td[@class='left'])[6]")
	WebElement details_STB_No;
	
	@FindBy(xpath="(//td[@class='left'])[7]")
	WebElement details_Subscription_Date;
	
	@FindBy(xpath="(//td[@class='left'])[8]")
	WebElement details_Expiry_Date;
		
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
    @FindBy(xpath=".//*[@id='filter_product']")
    WebElement select_product;
    
    @FindBy(xpath=".//*[@id='month_date']")
    WebElement date_picker;
	
    @FindBy(xpath="//select[@class='mtz-monthpicker mtz-monthpicker-year']")
    WebElement Year_picker;
    
    @FindBy(xpath="//td[text()='Jan']")
    WebElement jan_month;
    
    
private void click_on_Subscription_Sent_in_Particular_Month_Product_Wise_Subscription(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
//     wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText("A-la-carte Details"))).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Subscription_Sent_in_Particular_Month)).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Product_Wise_Subscription)).click();
	}
	
	public void Verify_element_method(){
		this.click_on_Subscription_Sent_in_Particular_Month_Product_Wise_Subscription();
		
		assertEquals(driver.getTitle(), "Product Wise Subscription (Sent in particular month)");
		Home_link.isDisplayed();
		Product_Wise_Subscription_link.isDisplayed();
		subheading_Expiry_Date.isDisplayed();
		subheading_Product_Name.isDisplayed();
		subheading_STB_No.isDisplayed();
		subheading_Subscription_Date.isDisplayed();
		Filter_button.isDisplayed();		
		print_button.isDisplayed();
		
		Product_Wise_Subscription_link.click();
		assertEquals(driver.getTitle(), "Product Wise Subscription (Sent in particular month)");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		this.click_on_Subscription_Sent_in_Particular_Month_Product_Wise_Subscription();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(select_product).selectByValue("1291");                   //select first Product
		String month = GetReportFilePath.current_month();
		date_picker.click();
		String str1="//td[text()='";
		String Pick_month=str1+month+"']";
		driver.findElement(By.xpath(Pick_month)).click();
		Filter_button.click();
		details_Expiry_Date.isDisplayed();
		details_Product_Name.isDisplayed();
		details_STB_No.isDisplayed();
		details_Subscription_Date.isDisplayed();
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");        //Search Valid 
		
	}
	
	public void Invalid_method(){
		
		this.click_on_Subscription_Sent_in_Particular_Month_Product_Wise_Subscription();
		new Select(select_product).selectByValue("1291");                     //select first Product
		date_picker.click();
		new Select(Year_picker).selectByVisibleText("2020");
		jan_month.click();
		Filter_button.click();
		details_no_results.click();
							
	}
	
	
	
	}
