package com.reports_Subscription_Sent_in_Particular_Month;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class Reports_Package_Wise_Subscription_Sent_in_particular_month extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Subscription Sent in Particular Month")
	WebElement Subscription_Sent_in_Particular_Month;
	
	@FindBy(xpath="//a[text()='Package Wise Subscription']")
	WebElement Package_Wise_Subscription;
			
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Package_Wise_Subscription_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Package Name']")
	WebElement subheading_Package_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Package No']")
	WebElement subheading_Package_No;
	
	@FindBy(xpath="//td[@class='left' and text()='STB No.']")
	WebElement subheading_STB_No;
		
	@FindBy(xpath="//td[@class='left' and text()='Subscription Date']")
	WebElement subheading_Subscription_Date;
	
	@FindBy(xpath="//td[@class='left' and text()='Expiry Date']")
	WebElement subheading_Expiry_Date;
			
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Package_Wise_Subscription;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[6]")
	WebElement details_Package_Name;
	
	@FindBy(xpath="(//td[@class='left'])[7]")
	WebElement details_Package_No;
	
	@FindBy(xpath="(//td[@class='left'])[8]")
	WebElement details_STB_No;
	
	@FindBy(xpath="(//td[@class='left'])[9]")
	WebElement details_Subscription_Date;
	
	@FindBy(xpath="(//td[@class='left'])[10]")
	WebElement details_Expiry_Date;
		
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
    @FindBy(xpath=".//*[@id='filter_package']")
    WebElement select_package;
    
    @FindBy(xpath=".//*[@id='month_date']")
    WebElement date_picker;
	
    @FindBy(xpath="//select[@class='mtz-monthpicker mtz-monthpicker-year']")
    WebElement Year_picker;
    
    @FindBy(xpath="//td[text()='Jan']")
    WebElement jan_month;
    
    
private void click_on_Subscription_Sent_in_Particular_Month_Package_Wise_Subscription(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
//     wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText("A-la-carte Details"))).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Subscription_Sent_in_Particular_Month)).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Package_Wise_Subscription)).click();
	}
	
	public void Verify_element_method(){
		this.click_on_Subscription_Sent_in_Particular_Month_Package_Wise_Subscription();
		
		assertEquals(driver.getTitle(), "Package Wise Subscription (Sent in particular month)");
		Home_link.isDisplayed();
		Package_Wise_Subscription_link.isDisplayed();
		subheading_Expiry_Date.isDisplayed();
		subheading_Package_Name.isDisplayed();
		subheading_Package_No.isDisplayed();
		subheading_STB_No.isDisplayed();
		subheading_Subscription_Date.isDisplayed();
		heading_Package_Wise_Subscription.isDisplayed();
		Filter_button.isDisplayed();		
		print_button.isDisplayed();
		
		Package_Wise_Subscription_link.click();
		assertEquals(driver.getTitle(), "Package Wise Subscription (Sent in particular month)");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		this.click_on_Subscription_Sent_in_Particular_Month_Package_Wise_Subscription();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(select_package).selectByValue("1302");
	
		String month = GetReportFilePath.current_month();
		date_picker.click();
		String str1="//td[text()='";
		String Pick_month=str1+month+"']";
		driver.findElement(By.xpath(Pick_month)).click();
		Filter_button.click();
		details_Expiry_Date.isDisplayed();
		details_Package_Name.isDisplayed();
		details_Package_No.isDisplayed();
		details_STB_No.isDisplayed();
		details_Subscription_Date.isDisplayed();
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");        //Search Valid 
		
	}
	
	public void Invalid_method(){
		
		this.click_on_Subscription_Sent_in_Particular_Month_Package_Wise_Subscription();
		new Select(select_package).selectByValue("1302");
		date_picker.click();
		new Select(Year_picker).selectByVisibleText("2020");
		jan_month.click();
		Filter_button.click();
		details_no_results.click();
					
						
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
