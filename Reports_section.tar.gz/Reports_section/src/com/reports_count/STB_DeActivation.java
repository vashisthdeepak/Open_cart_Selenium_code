package com.reports_count;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.baseclass.BaseClass;


public class STB_DeActivation extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Count")
	WebElement count;
	
	@FindBy(partialLinkText="STB De-Activation")
	WebElement STB_Deactivation;
		
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement STB_Deactivation_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='center' and text()='OPERATORS']")
	WebElement subheading_OPERATORS;
	
	@FindBy(xpath="//td[@class='center' and text()='DE-ACTIVE COUNT']")
	WebElement subheading_DE_ACTIVE_COUNT;
	
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_STB_Deactivation;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(id="selectoption")
	WebElement selectoption_from_to;
	
	@FindBy(xpath=".//*[@id='month_date']")
	WebElement from_date_start_box;
	
	@FindBy(xpath=".//*[@id='from_date']")
	WebElement from_date_start_box_on_date;
	
	@FindBy(id="date-start")
	WebElement date_start_option;
	
	@FindBy(xpath="//select[@name='filter_operator']")
	WebElement filter_operator;
	
	@FindBy(partialLinkText="Filter")
	WebElement Filter_button;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr/td[2]")
	WebElement Count_details;
	
	@FindBy(xpath="(//td[@class='center'])[4]")
    WebElement Count_details_result;
	
	@FindBy(xpath="(//td[@class='left'])[1]")
	WebElement Result_operaters;
	
	@FindBy(xpath="(//td[@class='left'])[2]")
	WebElement Result_count;
	
	@FindBy(xpath="//td[@class='ui-state-default mtz-monthpicker mtz-monthpicker-month' and text()='Jan']")
	WebElement select_jan;
	
	@FindBy(xpath="//*[@class='ui-icon ui-icon-circle-triangle-w']")
	WebElement date_start_prew_month;
	
	@FindBy(xpath="//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_first_date;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]")
	WebElement date_start_next_month;
	
	
	private void click_on_count_STB_Deactivation(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(count);
		act.click(STB_Deactivation).build().perform();
	}
	
	public void Verify_element_method(){
		this.click_on_count_STB_Deactivation();
		
		assertEquals(driver.getTitle(), "STB DeActive Count");
		Home_link.isDisplayed();
		STB_Deactivation_link.isDisplayed();
		subheading_DE_ACTIVE_COUNT.isDisplayed();
		subheading_OPERATORS.isDisplayed();
		heading_STB_Deactivation.isDisplayed();
		print_button.isDisplayed();
		filter_operator.isDisplayed();
		new Select(filter_operator).selectByVisibleText("ALL");
		new Select(filter_operator).selectByVisibleText("admin");
		STB_Deactivation_link.click();
		Filter_button.isDisplayed();
		selectoption_from_to.isDisplayed();
		new Select(selectoption_from_to).selectByVisibleText("Monthly");
		assertEquals(driver.getTitle(), "STB DeActive Count");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");

		this.click_on_count_STB_Deactivation();
	    STB_Deactivation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Monthly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    from_date_start_box.click();
	    select_jan.click();
	   	Filter_button.click();
	   	Count_details_result.isDisplayed();
	   	
	   	Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(count);
		act.click(driver.findElement(By.xpath(".//*[@id=' ']/ul/li[6]/ul/li[2]/a"))).build().perform();
//	    STB_Deactivation_link.click();
//	    new Select(selectoption_from_to).selectByVisibleText("On-Date");
//	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//	    from_date_start_box_on_date.click();
//	    from_date_start_box_on_date.sendKeys(Keys.ENTER);
//	   	Filter_button.click();
//	   	Count_details_result.isDisplayed();
		
	    STB_Deactivation_link.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("On-Date");
	    driver.findElement(By.xpath(".//*[@id='from_date']")).click();
	    for(int i=0;i<10;i++){
	    	date_start_prew_month.click(); 
	     }
	    date_start_first_date.click();
	    Filter_button.click();
	    Count_details_result.isDisplayed();
	    System.out.println(Count_details_result.getText().trim());
	    assertEquals("0", Count_details_result.getText());
	    
	    STB_Deactivation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("On-Date");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    from_date_start_box_on_date.click();
	    from_date_start_box_on_date.sendKeys(Keys.ENTER);
	   	Filter_button.click();
	   	Count_details_result.isDisplayed();
	   	Result_operaters.isDisplayed();
	   	Result_count.isDisplayed();
	   	
	}
	
	public void invalid_method(){
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(count);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		act.click(driver.findElement(By.xpath(".//*[@id=' ']/ul/li[6]/ul/li[2]/a"))).build().perform();
		    	    
	    STB_Deactivation_link.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//STB_Deactivation_link.click();
	   // print_button.click();
	    WebDriverWait wait = new WebDriverWait(driver,10);
	   	wait.until(ExpectedConditions.elementToBeClickable(print_button)).click();
	    assertEquals(msg_error.getText(), "Warning : Please filter records before printing!");
//		new Select(selectoption_from_to).selectByVisibleText("On-Date");
//	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    STB_Deactivation_link.click();
	    Filter_button.click();
	    assertEquals(msg_error.getText(), "Warning : On date required!");
	    
	    
	    

	    
	    
	}
			
	
	
	
	
	  
	

	
	

}