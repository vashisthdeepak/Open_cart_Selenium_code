package com.reports_count;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class Package_Subscription extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Count")
	WebElement count;
	
	@FindBy(partialLinkText="Package Subscription")
	WebElement Package_Subscription;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Package_Subscription_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Package No']")
	WebElement subheading_Package_No;
	
	@FindBy(xpath="//td[@class='left' and text()='Package Name']")
	WebElement subheading_Package_Name;
	
	@FindBy(xpath="//td[@class='center' and text()='Subscription Count']")
	WebElement subheading_Subscription_Count;
	
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Package_Subscription;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(id="selectoption")
	WebElement selectoption_from_to;
	
	@FindBy(xpath=".//*[@id='month_date']")
	WebElement from_date_start_box;
	
	@FindBy(id="date-start")
	WebElement date_start_option;
	
	@FindBy(id="date-end")
	WebElement date_end_option;
	
	@FindBy(id="from_date")
	WebElement date_end_box;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_end_next_month;
	
	@FindBy(xpath="//select[@name='filter_operator']")
	WebElement filter_operator;
	
	@FindBy(partialLinkText="Filter")
	WebElement Filter_button;
	
	@FindBy(id="year_date")
	WebElement select_year;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr/td[2]")
	WebElement details_package_no;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[3]")
	WebElement details_package_name;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[4]")
	WebElement details_Subscription_Count;
	
	@FindBy(xpath="//td[@class='ui-state-default mtz-monthpicker mtz-monthpicker-month' and text()='Jan']")
	WebElement select_jan;
	
	@FindBy(xpath="//*[@class='ui-icon ui-icon-circle-triangle-w']")
	WebElement date_start_prew_month;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[1]")
	WebElement date_end_pre_month;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_start_next_month;
	
	@FindBy(xpath="//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_first_date;
	
	@FindBy(xpath="//select[@class='mtz-monthpicker mtz-monthpicker-year']")
	WebElement date_start_Year_option;
		
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	private void click_on_count_STB_activation(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(count);
		act.click(Package_Subscription).build().perform();
	}
	
	public void Verify_element_method(){
		this.click_on_count_STB_activation();
		
		assertEquals(driver.getTitle(), "Package Subscription Count");
		Home_link.isDisplayed();
		Package_Subscription_link.isDisplayed();
		subheading_Package_Name.isDisplayed();
		subheading_Package_No.isDisplayed();
		subheading_Subscription_Count.isDisplayed();
		heading_Package_Subscription.isDisplayed();
		print_button.isDisplayed();
		filter_operator.isDisplayed();
		new Select(filter_operator).selectByVisibleText("ALL");
		new Select(filter_operator).selectByVisibleText("admin");
		Package_Subscription_link.click();
		Filter_button.isDisplayed();
		selectoption_from_to.isDisplayed();
		new Select(selectoption_from_to).selectByVisibleText("Monthly");
		new Select(selectoption_from_to).selectByVisibleText("Yearly");
		assertEquals(driver.getTitle(), "Package Subscription Count");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	public void valid_method(){		
		
		this.click_on_count_STB_activation();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    for(int i=0;i<10;i++){
	    	date_start_prew_month.click(); 
	     }
	    date_start_first_date.click();
	    date_end_box.click();
	    date_end_box.sendKeys(Keys.ENTER);
	    Filter_button.click();
	    details_package_no.isDisplayed();
	    details_package_name.isDisplayed();
	    details_Subscription_Count.isDisplayed();
	    //System.out.println(details_product_no.getText().trim()+details_product_name.getText()+details_Subscription_Count.getText());
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");  			//get data by date
	    
	    this.click_on_count_STB_activation();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    for(int i=0;i<30;i++){
	    	date_start_next_month.click(); 
	     }
	    date_start_first_date.click();
	    date_end_box.click();
	    for(int i=0;i<30;i++){
	    date_end_next_month.click();
	    }
	    date_start_first_date.click();
	    Filter_button.click();
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");  			//Future date no result    

	    Package_Subscription_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Monthly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    from_date_start_box.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    String value = GetReportFilePath.current_month();
	    System.out.println("Current month : "+value);
	    String str = "//td[text()='"+value+"']";
	    driver.findElement(By.xpath(str)).click();
	   	Filter_button.click();
	   	details_package_no.isDisplayed();
	    details_package_name.isDisplayed();
	    details_Subscription_Count.isDisplayed();     //valid month data
	    
	    
	    Package_Subscription_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Yearly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    String year = GetReportFilePath.current_year();
	    select_year.click();
	    new Select(select_year).selectByVisibleText(year);
	   	Filter_button.click();
	   	details_package_no.isDisplayed();
	    details_package_name.isDisplayed();
	    details_Subscription_Count.isDisplayed();    
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");     //valid Year data
	    
	   
	}

	public void invalid_method(){
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		this.click_on_count_STB_activation();
		
		Package_Subscription_link.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    date_start_next_month.click();
	    date_start_first_date.click();
	    date_end_box.click();
	    date_end_box.sendKeys(Keys.ENTER);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    Filter_button.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    System.out.println(msg_error.getText().trim());
	    assertEquals(msg_error.getText(), "Warning : From date is greater than To date!");      //invalid date
	    
	    
	    Package_Subscription_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Monthly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    from_date_start_box.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    date_start_Year_option.click();
	    new Select(date_start_Year_option).selectByVisibleText("2012");
	    select_jan.click();
	   	Filter_button.click();                                                                
	   	assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");                 //Invalid month
	   	
	   	Package_Subscription_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Yearly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    select_year.click();
	    new Select(select_year).selectByVisibleText("2016");
	    Filter_button.click();
	   	assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");     //Invalid Year data
	   	
	   	
	   	Package_Subscription_link.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    for(int i=0;i<30;i++){
	    	date_start_prew_month.click(); 
	     }
	    date_start_first_date.click();
	    date_end_box.click();
	    for(int i=0;i<30;i++){
	    	date_end_pre_month.click(); 
	     }
	    date_start_first_date.click();
	    Filter_button.click();
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");	     //invalid date
	   	    
		Package_Subscription_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("From-To");
	    Filter_button.click();
	    assertEquals(msg_error.getText(), "Warning : From date required!");
	    System.out.println(msg_error.getText());                              //Filter without date
	    	    
	    Package_Subscription_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Monthly");
	    Filter_button.click();
	    assertEquals(msg_error.getText(), "Warning : Please select month!");
	    System.out.println(msg_error.getText());                              //Filter without Month
	    
//	    Product_Subscription_link.click();
//	    new Select(selectoption_from_to).selectByVisibleText("Yearly");
//	    Filter_button.click();
//	    assertEquals(msg_error.getText(), "Warning : Please select year!");
//	    System.out.println(msg_error.getText());    						 //Filter without year -------------Bug in SMS
	    
	    Package_Subscription_link.click();
	    print_button.click();
	    assertEquals(msg_error.getText(), "Warning : Please filter records before printing!");
	    System.out.println(msg_error.getText());   
	    
  
	}
}