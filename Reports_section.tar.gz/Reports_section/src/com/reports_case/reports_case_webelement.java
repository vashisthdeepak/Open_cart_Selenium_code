package com.reports_case;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class reports_case_webelement extends BaseClass{

	@FindBy(partialLinkText="Count")
	WebElement count;

	@FindBy(partialLinkText = "Package Subscription")
	WebElement Package_Subscription;
	
	@FindBy(partialLinkText = "Product Subscription")
	WebElement Prdct_Subscription;

	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;

	@FindBy(partialLinkText = "STB DeActivations")
	WebElement STB_DeActivations;

	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Package_Subscription_link;

	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;

	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;

	@FindBy(xpath="//td[@class='left' and text()='Package No']")
	WebElement subheading_Package_No;

	@FindBy(xpath="//td[@class='left' and text()='Package Name']")
	WebElement subheading_Package_Name;

	@FindBy(xpath="//td[@class='center' and text()='Subscription Count']")
	WebElement subheading_Subscription_Count;

	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Package_Subscription;

	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(id="selectoption")
	WebElement selectoption_from_to;

	@FindBy(xpath=".//*[@id='month_date']")
	WebElement from_date_start_box;

	@FindBy(id="date-start")
	WebElement date_start_option;

	@FindBy(id="date-end")
	WebElement date_end_option;

	@FindBy(id="from_date")
	WebElement date_end_box;

	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_end_next_month;

	@FindBy(xpath="//select[@name='filter_operator']")
	WebElement filter_operator;

	@FindBy(partialLinkText="Filter")
	WebElement Filter_button;

	@FindBy(id="year_date")
	WebElement select_year;

	@FindBy(xpath="(//td[@class='left'])[12]")
	WebElement details_trigger_on;

	@FindBy(xpath="(//td[@class='left'])[13]")
	WebElement details_Deactivate_time;

	@FindBy(xpath="(//td[@class='left'])[14]")
	WebElement details_customer_name;

	@FindBy(xpath="//td[@class='ui-state-default mtz-monthpicker mtz-monthpicker-month' and text()='Jan']")
	WebElement select_jan;

	@FindBy(xpath="//*[@class='ui-icon ui-icon-circle-triangle-w']")
	WebElement date_start_prew_month;

	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[1]")
	WebElement date_end_pre_month;

	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_start_next_month;

	@FindBy(xpath="//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_first_date;

	@FindBy(xpath="//select[@class='mtz-monthpicker mtz-monthpicker-year']")
	WebElement date_start_Year_option;

	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;

	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;

	@FindBy(xpath = "//a[@class='parent' and text()='Historical']")
	WebElement Historical;

	@FindBy(partialLinkText = "STB Activations")
	WebElement STB_Activations;

	@FindBy(xpath="//a[text()='Historical STB Activations']")
	WebElement Historical_STB_Activations_link;

	@FindBy(xpath = ".//*[@id='selectoption']")
	WebElement from_to_monthly_yearly_option;

	@FindBy(xpath = "//input[@id='to_date' and @type='text' and @name='filter_date_start']")
	WebElement date_start_box;

	@FindBy(xpath = "//a[@class='button' and text()='Report Generate']")
	WebElement Report_Generate_button;

	@FindBy(xpath = ".//*[@id='date-start']")
	WebElement date_start;

	@FindBy(partialLinkText="Total No Of Subscribers On The n/w")
	WebElement Total_No_Of_Subscribers_On_The_network;

	@FindBy(xpath = ".//*[@id='date-end']")
	WebElement date_end;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[1]/span")
	WebElement date_start_calender_back_month;

	@FindBy(xpath = "//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_calender_back_month_first_date;

	@FindBy(xpath = "//div[@id='success' and text()='Report Generated Successfully!']")
	WebElement msg_report_generated_sucessfully;

	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[2]")
	WebElement Date_of_Generation_first_option;

	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[1]")
	WebElement Report_Name_first_option;

	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[3]/a")
	WebElement download_first_option;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[6]/a")
	WebElement date_start_box_first_date;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[6]/a")
	WebElement date_end_box_first_date;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_start_box_next_month;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_end_box_next_month;

	@FindBy(xpath = ".//*[@id='year_date']")
	WebElement date_year;

	@FindBy(xpath = "//a[@class='top' and text()='Commands']")
	WebElement commands;

	@FindBy(xpath = "//a[@class='parent' and text()='EMM Commands']")
	public WebElement EMM_commands;

	@FindBy(partialLinkText = "Box Activation")
	public WebElement Box_Activation;

	@FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[2]")   //commands>EMM Commands >STB Activation
	WebElement copy_first_customer_STB_NO;

	@FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[5]")
	WebElement copy_first_customer_first_name;

	@FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[3]")
	WebElement copy_first_customer_Activation_time_;

	@FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[4]")
	WebElement copy_first_customer_Deactivation_time_;

	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[2]/td[4]")
	WebElement sales_customer_copy_first_STB_NO;

	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[4]/input")
	WebElement sales_customers_STB_search_option;

	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement sales_customers_search_option;

	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[2]/td[11]/a")
	WebElement sales_customers_click_first_edit;

	@FindBy(xpath=".//*[@id='tab-customer']/table/tbody/tr[2]/td[2]/input")
	WebElement sales_customers_click_first_name_option;

	@FindBy(xpath="//a[@class='button' and  text()='Submit']")
	WebElement sales_customers_Submit_button;

	@FindBy(xpath=".//*[@id='tab-customer']/table/tbody/tr[6]/td[2]/input")
	WebElement sales_customers_confirm_passwd;

	@FindBy(xpath="//a[@class='button' and  text()='Submit']")
	WebElement sales_customers_Success_msg;

	@FindBy(xpath=".//*[@id='scriptBox']")
	WebElement box_act_search_box;

	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement search_option;

	@FindBy(xpath="//a[@class='button' and text()='Insert']")
	WebElement command_act_insert_option;

	@FindBy(xpath="//input[@class='ui-autocomplete-input' and @type='text']")
	WebElement command_act_insert_STB_No;

	@FindBy(xpath="//a[@class='button' and text()='Activate']")
	WebElement command_act_insert_Activate_button;

	@FindBy(xpath="(//a[text()='De activate '])[1]")
	WebElement command_deact_stb;

	//-------------------------------------------click_on_Total_No_Of_Subscribers_On_The_network---------------------------------------------------------------------------------

	@FindBy(xpath="(//td[@class='left'])[10]")
	WebElement deatils_Total_No_Of_Subscribers_On_The_network_Active_Subscriber;

	@FindBy(xpath="(//td[@class='left'])[11]")
	WebElement deatils_Total_No_Of_Subscribers_On_The_network_DeActive_Subscriber;

	//-------------------------------------------------------Count STB Activations---------------------------------------------------------------		

	@FindBy(partialLinkText="STB Activation")
	WebElement STB_activation;

	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr/td[2]")
	WebElement Count_details;
	//-------------------------------------------------------Count STB DeActivations---------------------------------------------------------------			
	@FindBy(partialLinkText="STB De-Activation")
	WebElement STB_Deactivation;

	@FindBy(xpath=".//*[@id='from_date']")
	WebElement from_date_start_box_on_date;

	@FindBy(xpath="(//td[@class='center'])[4]")
	WebElement Count_details_result;
	//-------------------------------------------------------list STB Activations and De-activations---------------------------------------------------------------				
	@FindBy(partialLinkText="List")
	WebElement list;

	@FindBy(xpath=".//*[@id=' ']/ul/li[7]/ul/a[1]")
	WebElement list_STB_activation;

	@FindBy(xpath=".//*[@id=' ']/ul/li[7]/ul/a[2]")
	WebElement STB_deactivation;

	@FindBy(xpath=".//*[@id='from_date']")
	WebElement list_STB_Deact_from_date_start_box;

	//-------------------------------------------------------logs---------------------------------------------------------------				

	@FindBy(partialLinkText="Logs")
	WebElement Logs;

	@FindBy(xpath="(//a[text()='Complete Logs'])[1]")
	WebElement Complete_Logs;

	@FindBy(xpath="//input[@id='scriptBox' and @name='filter_value']")
	WebElement Complete_logs_STB_search_box;

	@FindBy(xpath=".//*[@id='filter_command' and @name='filter_command']")
	WebElement command_select_option;

	@FindBy(xpath="(//a[text()='Activation/Deactivation Logs'])[1]")
	WebElement Activation_Deactivation_Logs;

	@FindBy(xpath="(//a[text()='Activation/Deactivation Logs'])[1]")
	WebElement Next_page;

	//-------------------------------------------------------STB History---------------------------------------------------------------				

	@FindBy(partialLinkText="STB History")
	WebElement STB_Histroy;

	@FindBy(id="filter_stbno")
	WebElement filter_stbno_box;

	@FindBy(id="filter_command")
	WebElement filter_command_dropdown;




	private void click_on_STB_Historyt(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.click(STB_Histroy).build().perform();
	}

	private void click_on_Activation_Deactivation_Logs(){

		// reports.click();
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.elementToBeClickable(reports)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Logs)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Activation_Deactivation_Logs)).click();
	}		

	private void click_on_Complete_Logs(){

		reports.click();
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.elementToBeClickable(Logs)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Complete_Logs)).click();
	}

	private void click_on_list_STB_deactivation(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(list);
		act.click(STB_deactivation).build().perform();
	}	

	private void click_on_list_STB_activation(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(list);
		act.click(list_STB_activation).build().perform();
	}

	private void click_on_Total_No_Of_Subscribers_On_The_network(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.click(Total_No_Of_Subscribers_On_The_network).build().perform();
	}

	public static PDDocument PDF_Data_Reader_act() throws Throwable{

		PDDocument pdDoc;
		//String value = Read_PDF_name();
		pdDoc = PDDocument.load( new File("D:\\Unzip\\historicalactivation_1.pdf"));
		//System.out.println(pdDoc.getNumberOfPages());
		return pdDoc;
	}	

	public static PDDocument PDF_Data_Reader_deact() throws Throwable{

		PDDocument pdDoc;
		//String value = Read_PDF_name();
		pdDoc = PDDocument.load( new File("D:\\Unzip\\historicaldeactivation_1.pdf"));

		System.out.println(pdDoc.getNumberOfPages());
		return pdDoc;
	}

	public void click_on_reports_historical_STB_Activation_method() {
		reports.click();
		Historical.click();
		STB_Activations.click();

	}

	public String current_date(){

		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String current_date = dateFormat.format(date);
		return current_date;
	}	 

	private void click_on_commands_STB_Activation() {

		commands.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		EMM_commands.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Box_Activation.click();
	}


	public void click_on_reports_historical_STB_DeActivation_method() {
		reports.click();
		Historical.click();
		STB_DeActivations.click();
	}

	private void click_on_count_STB_activation(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(count);
		act.click(STB_activation).build().perform();
	}

	private void click_on_count_STB_Deactivation(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(count);
		act.click(STB_Deactivation).build().perform();
	}


	SoftAssert sAssert = new SoftAssert();
	ExcelReader read = new ExcelReader();
	String STB_NO = "SDA5CE49994999";
//	String STB_NO = "SDA4CE24000002";                            				 //copy STB number 

	//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	//-------------------------------------------------------Historical STB Activations, STB De-activations and Total No Of Subscribers On The network------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	


	public void Reports_Historical_STB_Activations_and_STB_De_activations_and_Total_No_Of_Subscribers_On_The_network_method() throws Throwable{		
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files	
		this.Commands_Package_deactivate();


		//---------------------------------------------------------------------------------------deactivate STB ------------------------------------------------------------------------------------------------------	
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		//--------------------------------------------------Check in click_on_Total_No_Of_Subscribers_On_The_network--------------------------------------------------------------------------------------------------
		this.click_on_Total_No_Of_Subscribers_On_The_network();
		String Active_Subscriver_in_total_no_before_activate = deatils_Total_No_Of_Subscribers_On_The_network_Active_Subscriber.getText();
		int integer_value_of_Active_Subscriver_in_total_no_before_activate = Integer.parseInt(Active_Subscriver_in_total_no_before_activate);
		System.out.println("int value before activate STB------>"+integer_value_of_Active_Subscriver_in_total_no_before_activate);		

		String deactive_deatils_Total_No_Of_Subscribers_On_The_network_DeActive_Subscriber = deatils_Total_No_Of_Subscribers_On_The_network_DeActive_Subscriber.getText();
		int integer_value_of_DeActive_Subscriver_in_total_no_after_deactivate = Integer.parseInt(deactive_deatils_Total_No_Of_Subscribers_On_The_network_DeActive_Subscriber);
		System.out.println("Deactive int value Deactivate STB------>"+integer_value_of_DeActive_Subscriver_in_total_no_after_deactivate);

		//----------------------------------------------------------------------------go to Commands STB Activation -----------------------------------------------------------------------------------------------

		this.click_on_commands_STB_Activation();

		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					   //Activate STB

		String trigget_on = details_trigger_on.getText();
		System.out.println(trigget_on);
		String deactivation_time = details_Deactivate_time.getText();
		System.out.println(deactivation_time);
		String cust_name=details_customer_name.getText();
		System.out.println(cust_name);                             	            	  //copy_STB Details	

		//------------------------------------------------------------------------------------go to reports STB Act ----------------------------------------------------------------------------------------------------

		this.click_on_reports_historical_STB_Activation_method();		
		Select sel = new Select(from_to_monthly_yearly_option);     
		sel.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText(GetReportFilePath.current_year());   

		Report_Generate_button.click();
		assertTrue(msg_report_generated_sucessfully.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		Thread.sleep(2000);
		GetReportFilePath.FileNameReadUnzip();
		GetReportFilePath.FileNameRead();

		String value =GetReportFilePath.Read_Unzipped_file_name();
		System.out.println(value);
		Assert.assertEquals(value, "historicalactivation_1.pdf");

		PDFTextStripper g = new PDFTextStripper();
		assertTrue(g.getText(PDF_Data_Reader_act()).contains(STB_NO));
		assertTrue(g.getText(PDF_Data_Reader_act()).contains(trigget_on));
		assertTrue(g.getText(PDF_Data_Reader_act()).contains(deactivation_time));
		assertTrue(g.getText(PDF_Data_Reader_act()).contains(cust_name));                    //Search data in PDF

		//--------------------------------------------------Check in click_on_Total_No_Of_Subscribers_On_The_network--------------------------------------------------------------------------------------------------
		this.click_on_Total_No_Of_Subscribers_On_The_network();
		String Active_Subscriver_in_total_no_after_activate = deatils_Total_No_Of_Subscribers_On_The_network_Active_Subscriber.getText();
		int integer_value_of_Active_Subscriver_in_total_no_after_activate = Integer.parseInt(Active_Subscriver_in_total_no_after_activate);
		System.out.println("int value after activate STB ----------->"+integer_value_of_Active_Subscriver_in_total_no_after_activate);
		assertEquals(integer_value_of_Active_Subscriver_in_total_no_after_activate,integer_value_of_Active_Subscriver_in_total_no_before_activate+1);


		String DeActive_Subscriver_in_total_no_after_activate = deatils_Total_No_Of_Subscribers_On_The_network_DeActive_Subscriber.getText();
		int integer_value_of_DeActive_Subscriver_in_total_no_after_activate = Integer.parseInt(DeActive_Subscriver_in_total_no_after_activate);
		System.out.println("Deactive int value after activate STB ----------->"+integer_value_of_DeActive_Subscriver_in_total_no_after_activate);
		assertEquals(integer_value_of_DeActive_Subscriver_in_total_no_after_activate,integer_value_of_DeActive_Subscriver_in_total_no_after_deactivate-1);


		//-------------------------------------------------------------------------------------------deactivate STB --------------------------------------------------------------------------------------------------	
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		String trigget_on_deact = details_trigger_on.getText();
		System.out.println(trigget_on_deact);

		//-------------------------------------------------------------------------------go to reports STB De-activations and check data---------------------------------------------------------------------------------	
		this.click_on_reports_historical_STB_DeActivation_method();
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files

		Select sell = new Select(from_to_monthly_yearly_option);
		sell.selectByVisibleText("Yearly");
		Select selecc = new Select(date_year);
		selecc.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);

		GetReportFilePath.FileNameReadUnzip();
		GetReportFilePath.FileNameRead();

		String value1 = GetReportFilePath.Read_PDF_name();
		System.out.println(value1);
		Assert.assertEquals(value1, "historicaldeactivation_1.pdf");

		assertTrue(g.getText(PDF_Data_Reader_deact()).contains(STB_NO));                 	     //STB NO
		assertTrue(g.getText(PDF_Data_Reader_deact()).contains(cust_name));               	    //cust_name
		assertTrue(g.getText(PDF_Data_Reader_deact()).contains(trigget_on_deact));         	   //trigget_on


	}

	//#############################################################################################################################################################################################################	
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	//#############################################################################################################################################################################################################	

	public void Reports_count_STB_activation_method() throws IOException{

		//---------------------------------------------------------------------------------------deactivate STB ---------------
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		//------------------------------------------------------------------GO to count STB activation --------------------------	 	 
		this.click_on_count_STB_activation();
		String current_year=GetReportFilePath.current_year();
		System.out.println(current_year);

		new Select(selectoption_from_to).selectByVisibleText("From-To");
		driver.findElement(By.xpath(".//*[@id='to_date']")).click();
		String date1="//a[@class='ui-state-default' and text()='";
		String date2=GetReportFilePath.current_date_only();
		int current_date = Integer.parseInt(date2);
		int one_day_prev_date=current_date-1;
		String date_element_prev = date1+one_day_prev_date+"']";
		driver.findElement(By.xpath(date_element_prev)).click();

		date_end_box.click();
		int one_day_next_date=current_date+1;
		String date_element_next = date1+one_day_next_date+"']";
		driver.findElement(By.xpath(date_element_next)).click(); 	    
		Filter_button.click();
		Count_details.isDisplayed();
		String count_result1=Count_details.getText();
		int count_result_after_deactivation = Integer.parseInt(count_result1);                                 //convert String count into int
		System.out.println("count_result_after_deactivation------------->"+count_result_after_deactivation);


		//----------------------------------------------------------------------------go to Commands STB Activation -----

		this.click_on_commands_STB_Activation();

		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					   //Activate STB

		//------------------------------------------------------------------GO to count STB activation -------- 	 
		this.click_on_count_STB_activation();

		new Select(selectoption_from_to).selectByVisibleText("From-To");
		driver.findElement(By.xpath(".//*[@id='to_date']")).click();
		driver.findElement(By.xpath(date_element_prev)).click();
		date_end_box.click();
		driver.findElement(By.xpath(date_element_next)).click(); 	    
		Filter_button.click();
		Count_details.isDisplayed();
		String count_result_after_activation=Count_details.getText().trim();
		System.out.println("count_result_after_activation---------------->"+count_result_after_activation);	 		
		assertEquals(count_result_after_activation, count_result_after_deactivation+1);


	}

	public void Reports_count_STB_Deactivation_method(){


		//----------------------------------------------------------------------------go to Commands STB Activation -----------------------------------------------------------------------------------------------

		this.click_on_commands_STB_Activation();

		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					   //Activate STB


		//------------------------------------------------------------------GO to count STB Deactivation ------------------------------------------------------------------------------------------------------	 	 

		this.click_on_count_STB_Deactivation();
		new Select(selectoption_from_to).selectByVisibleText("On-Date");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		from_date_start_box_on_date.click();
		from_date_start_box_on_date.sendKeys(Keys.ENTER);
		Filter_button.click();
		Count_details_result.isDisplayed();
		String total_count = Count_details_result.getText();
		int total_deactive_count_before_deactiavte = Integer.parseInt(total_count);   
		System.out.println("total_deactive_count_before_deactiavte---------->"+total_deactive_count_before_deactiavte);

		//---------------------------------------------------------------------------------------deactivate STB ------------------------------------------------------------------------------------------------------	
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		//------------------------------------------------------------------GO to count STB Deactivation ------------------------------------------------------------------------------------------------------	 	 

		this.click_on_count_STB_Deactivation();
		new Select(selectoption_from_to).selectByVisibleText("On-Date");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		from_date_start_box_on_date.click();
		from_date_start_box_on_date.sendKeys(Keys.ENTER);
		Filter_button.click();
		Count_details_result.isDisplayed();
		String total_count1 = Count_details_result.getText();
		int total_deactive_count_after_deactiavte = Integer.parseInt(total_count1);   
		System.out.println("total_deactive_count_after_deactiavte---------->"+total_deactive_count_after_deactiavte);
		assertEquals(total_deactive_count_after_deactiavte, total_deactive_count_before_deactiavte+1);		

	}

	public void Reports_List_STB_activation_method(){

		//---------------------------------------------------------------------------------------deactivate STB ---------------
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	
		//----------------------------------------------------------------------------go to Commands STB Activation -----------------------------------------------------------------------------------------------

		this.click_on_commands_STB_Activation();
		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					   //Activate STB

		String trigget_on = details_trigger_on.getText();
		System.out.println(trigget_on);
		String deactivation_time = details_Deactivate_time.getText();
		System.out.println(deactivation_time);
		String cust_name=details_customer_name.getText();
		System.out.println(cust_name);                             	            	  //copy_STB Details	

		//----------------------------------------------------------------------------go to List STB Activation -----------------------------------------------------------------------------------------------		

		this.click_on_list_STB_activation();
		new Select(selectoption_from_to).selectByVisibleText("Yearly");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String year = GetReportFilePath.current_year();
		select_year.click();
		new Select(select_year).selectByVisibleText(year);
		Filter_button.click();
		String STB_NO_1 = "//td[@class='center' and text()='";
		String STB_NO_2 = STB_NO_1+STB_NO+"']";

		String trigget_on_1 = "//td[@class='center' and text()='";
		String trigget_on_2 = trigget_on_1+trigget_on+"']";

		String cust_name_1 = "//td[@class='center' and text()='";
		String cust_name_2 = cust_name_1+cust_name+"']";

		String deactivation_time_1 = "//td[@class='center' and text()='";
		String deactivation_time_2 = deactivation_time_1+deactivation_time+"']";

		driver.findElement(By.xpath(STB_NO_2)).isDisplayed();
		driver.findElement(By.xpath(trigget_on_2)).isDisplayed();
		driver.findElement(By.xpath(cust_name_2)).isDisplayed();
		driver.findElement(By.xpath(deactivation_time_2)).isDisplayed();

	}

	public void Reports_List_STB_Deactivation_method(){

		//---------------------------------------------------------------------------------------deactivate STB ---------------
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		String trigget_on = details_trigger_on.getText();
		System.out.println(trigget_on);
		String deactivation_time = details_Deactivate_time.getText();
		System.out.println(deactivation_time);
		String cust_name=details_customer_name.getText();
		System.out.println(cust_name);                             	            	  //copy_STB Details	

		//----------------------------------------------------------------------------go to List STB DeActivation -----------------------------------------------------------------------------------------------		

		this.click_on_list_STB_deactivation();

		new Select(selectoption_from_to).selectByVisibleText("On-Date");
		list_STB_Deact_from_date_start_box.click();
		list_STB_Deact_from_date_start_box.sendKeys(Keys.ENTER);
		Filter_button.click();
		String STB_NO_1 = "//td[@class='center' and text()='";
		String STB_NO_2 = STB_NO_1+STB_NO+"']";

		String trigget_on_1 = "//td[@class='center' and text()='";
		String trigget_on_2 = trigget_on_1+trigget_on+"']";

		String cust_name_1 = "//td[@class='center' and text()='";
		String cust_name_2 = cust_name_1+cust_name+"']";

		driver.findElement(By.xpath(STB_NO_2)).isDisplayed();
		driver.findElement(By.xpath(trigget_on_2)).isDisplayed();
		driver.findElement(By.xpath(cust_name_2)).isDisplayed();

	}

	public void Logs_method() throws InterruptedException{

		//----------------------------------------------------------------------------go to Commands STB Activation -----------------------------------------------------------------------------------------------

		this.click_on_commands_STB_Activation();
		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					   //Activate STB


		//---------------------------------------------------------------------------------------deactivate STB ---------------
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		String trigget_on = details_trigger_on.getText();
		System.out.println(trigget_on);
		String deactivation_time = details_Deactivate_time.getText();
		String cust_name=details_customer_name.getText();
		System.out.println(cust_name);                             	            	  //copy_STB Details	

		//---------------------------------------------------------------------------------------Check in Logs (STB DEACTIVATION)---------------


		this.click_on_Complete_Logs();
		Complete_logs_STB_search_box.sendKeys(STB_NO);
		new Select(command_select_option).selectByValue("1");                       //select STB De-activation in Complete Logs
		search_option.click();
		String str1 = "//td[@class='left' and text()='";
		String STB_Trigger_Date_time = str1+trigget_on+"']";

		String STB_NO_ = str1+STB_NO+"']";


		driver.findElement(By.xpath(STB_Trigger_Date_time)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_)).isDisplayed();
		System.out.println("Deactivation Date and Time in Complete Logs---------------->"+driver.findElement(By.xpath(STB_Trigger_Date_time)).getText());
		System.out.println("Deactivate STB NO in Complete Logs------------------------>"+driver.findElement(By.xpath(STB_NO_)).getText());
		//--------------------------------------------------------------------------	
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//	this.click_on_Activation_Deactivation_Logs();                       //Check De-activations in STB Activations/De-activations Logs
		reports.click();
		Thread.sleep(2000);
		Logs.click();
		Thread.sleep(2000);
		Activation_Deactivation_Logs.click();
		//		   WebDriverWait wait = new WebDriverWait(driver,10);
		////		   wait.until(ExpectedConditions.elementToBeClickable(reports)).click();
		//		   wait.until(ExpectedConditions.elementToBeClickable(Logs)).click();
		//		   Thread.sleep(1000);
		//		   wait.until(ExpectedConditions.elementToBeClickable(Activation_Deactivation_Logs)).click();



		Complete_logs_STB_search_box.sendKeys(STB_NO);
		search_option.click();

		driver.findElement(By.xpath(STB_Trigger_Date_time)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_)).isDisplayed();
		System.out.println("Deactivation Date and Time in Activations/De-activations Logs---------------->"+driver.findElement(By.xpath(STB_Trigger_Date_time)).getText());
		System.out.println("Deactivate STB NO in Activations/De-activations Logs------------------------>"+driver.findElement(By.xpath(STB_NO_)).getText());


		//----------------------------------------------------------------------------go to Commands STB Activation -----------------------------------------------------------------------------------------------

		this.click_on_commands_STB_Activation();
		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					                  //Activate STB

		String trigget_on_after_activate = details_trigger_on.getText();
		System.out.println(trigget_on_after_activate);
		String deactivation_time_after_activate = details_Deactivate_time.getText();
		String cust_name_after_activate=details_customer_name.getText();
		System.out.println(cust_name_after_activate);                             	            	  //copy_STB Details	



		//---------------------------------------------------------------------------------------Check in Complete Logs(STB ACTIVATION) ---------------

		this.click_on_Complete_Logs();
		Complete_logs_STB_search_box.sendKeys(STB_NO);
		new Select(command_select_option).selectByValue("0");                       //select STB activation in Complete Logs
		search_option.click();
		String str2 = "//td[@class='left' and text()='";
		String STB_Trigger_Date_time_after_activation = str2+trigget_on_after_activate+"']";

		String STB_NO__after_activation = str2+STB_NO+"']";

		driver.findElement(By.xpath(STB_Trigger_Date_time_after_activation)).isDisplayed();
		driver.findElement(By.xpath(STB_NO__after_activation)).isDisplayed();
		System.out.println("activation Date and Time in Complete Logs---------------->"+driver.findElement(By.xpath(STB_Trigger_Date_time_after_activation)).getText());
		System.out.println("activate STB NO in Complete Logs------------------------>"+driver.findElement(By.xpath(STB_NO__after_activation)).getText());





		//--------------------------------------------------------------------------	
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//	this.click_on_Activation_Deactivation_Logs();                       //Check activations in STB Activations/De-activations Logs
		reports.click();
		Thread.sleep(2000);
		Logs.click();
		Thread.sleep(2000);
		Activation_Deactivation_Logs.click();

		Complete_logs_STB_search_box.sendKeys(STB_NO);
		search_option.click();

		driver.findElement(By.xpath(STB_Trigger_Date_time_after_activation)).isDisplayed();
		driver.findElement(By.xpath(STB_NO__after_activation)).isDisplayed();
		System.out.println("activation Date and Time in Activations/De-activations Logs---------------->"+driver.findElement(By.xpath(STB_Trigger_Date_time_after_activation)).getText());
		System.out.println("activate STB NO in Activations/De-activations Logs------------------------>"+driver.findElement(By.xpath(STB_NO__after_activation)).getText());


	}


	public void STB_History_method(){

		//---------------------------------------------------------------------------------------deactivate STB ------------------------------------------------------------------------------------------------------	
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		//----------------------------------------------------------------------------go to Commands STB Activation -----------------------------------------------------------------------------------------------

		this.click_on_commands_STB_Activation();

		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					   //Activate STB

		String trigget_on_after_activate = details_trigger_on.getText();
		System.out.println(trigget_on_after_activate);
		String deactivation_time_after_activate = details_Deactivate_time.getText();
		System.out.println(deactivation_time_after_activate);
		String cust_name_after_activate=details_customer_name.getText();
		System.out.println(cust_name_after_activate);                             	            	  //copy_STB Details	


		//----------------------------------------------------------------------------go to STB History -----------------------------------------------------------------------------------------------

		this.click_on_STB_Historyt();
		filter_stbno_box.sendKeys(STB_NO);
		Select sel = new Select(filter_command_dropdown);
		sel.selectByVisibleText("Box Activation");
		Filter_button.click();
		String str2 = "//td[@class='left' and text()='";
		String STB_Trigger_Date_time_after_activation = str2+trigget_on_after_activate+"']";
		String STB_deactivation_date_time_after_activation = str2+deactivation_time_after_activate+"']";
		String STB_NO_after_activation = str2+STB_NO+"']";
		String Customer_name_after_activation = str2+cust_name_after_activate+"']";

		driver.findElement(By.xpath(STB_Trigger_Date_time_after_activation)).isDisplayed();
		driver.findElement(By.xpath(STB_deactivation_date_time_after_activation)).isDisplayed();
		driver.findElement(By.xpath(Customer_name_after_activation)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_after_activation)).isDisplayed();
		System.out.println("STB activation Date and Time in STB History---------------->"+driver.findElement(By.xpath(STB_Trigger_Date_time_after_activation)).getText());
		System.out.println("STB activation Date and Time in STB History---------------->"+driver.findElement(By.xpath(STB_deactivation_date_time_after_activation)).getText());
		System.out.println("activate STB NO in STB History------------------------>"+driver.findElement(By.xpath(Customer_name_after_activation)).getText());
		System.out.println("activate Customer name in STB History------------------------>"+driver.findElement(By.xpath(STB_NO_after_activation)).getText());

		//---------------------------------------------------------------------------------------deactivate STB ------------------------------------------------------------------------------------------------------	
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		String trigget_on_after_deactivate = details_trigger_on.getText();
		System.out.println(trigget_on_after_deactivate);
		String deactivation_time_after_deactivate = details_Deactivate_time.getText();
		System.out.println(deactivation_time_after_deactivate);
		String cust_name_afet_deactivate=details_customer_name.getText();
		System.out.println(cust_name_afet_deactivate);                             	            	  //copy_STB Details	

		//----------------------------------------------------------------------------go to STB History -----------------------------------------------------------------------------------------------

		this.click_on_STB_Historyt();
		filter_stbno_box.sendKeys(STB_NO);
		Select sell = new Select(filter_command_dropdown);
		sell.selectByVisibleText("Box De-Activation");
		Filter_button.click();

		String STB_Trigger_Date_time_after_deactivation = str2+trigget_on_after_deactivate+"']";
		String STB_NO_after_deactivation = str2+STB_NO+"']";
		String Customer_name_after_deactivation = str2+cust_name_afet_deactivate+"']";

		driver.findElement(By.xpath(STB_Trigger_Date_time_after_deactivation)).isDisplayed();
		//driver.findElement(By.xpath(STB_deactivation_date_time_after_deactivation)).isDisplayed();
		driver.findElement(By.xpath(Customer_name_after_deactivation)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_after_deactivation)).isDisplayed();
		System.out.println("STB deactivation Date and Time in STB History---------------->"+driver.findElement(By.xpath(STB_Trigger_Date_time_after_deactivation)).getText());
		System.out.println("deactivate STB NO in STB History------------------------>"+driver.findElement(By.xpath(Customer_name_after_deactivation)).getText());
		System.out.println("deactivate Customer name in STB History------------------------>"+driver.findElement(By.xpath(STB_NO_after_deactivation)).getText());
	}










	@FindBy(xpath = "//a[text()='Sales']")
	WebElement Sales;

	@FindBy(xpath = "//a[@class='parent' and text()='Customers']")
	public WebElement Customertab;

	@FindBy(xpath = "(//a[text()='Customers'])[2]")
	public WebElement Customersel;

	@FindBy(xpath = "(//a[text()='Packages'])[1]")
	public WebElement Cust_package;

	@FindBy(xpath = "//a[text()=' Package1 ']")
	public WebElement Cust_package1;

	@FindBy(xpath = "//select[@name='option[1417]']")
	public WebElement Cust_package_subs_select;

	@FindBy(xpath = "//select[@name='option[1417]']")
	public WebElement Cust_package_subs_select_one_month;

	@FindBy(xpath = "//input[@id='button-cart' and @value='Add to Cart']")
	public WebElement Add_to_cart_button;

	@FindBy(xpath = ".//*[@id='notification']/div")
	public WebElement sucess_msg_add_to_cart;

	@FindBy(xpath = "//a[text()='Checkout']")
	public WebElement Checkout_button;

	@FindBy(xpath = "//input[@id='button-payment-address' and @value='Continue']")
	public WebElement Continue_button_payment_1;

	@FindBy(xpath = "//input[@id='button-shipping-address' and @type='button']")
	public WebElement Continue_button_shipping_2;

	@FindBy(xpath = "//input[@id='button-shipping-method' and @value='Continue']")
	public WebElement Continue_button_shipping_3;

	@FindBy(xpath = "//input[@id='button-payment-method' and @value='Continue']")
	public WebElement Continue_button_shipping_4;

	@FindBy(xpath = "//label[text()='Cash On Delivery' and @for='cod']")
	public WebElement cash_on_delivery;

	@FindBy(xpath = "//input[@type='checkbox' and @name='agree']")
	public WebElement Agree_terms_condition;

	@FindBy(xpath="//input[@id='button-confirm' and @value='Confirm Order']")
	private WebElement Confirm_Order;

	//		@FindBy(xpath="(//a[text()='Package Subscription'])[1]")
	@FindBy(partialLinkText="Package Subscription")
	private WebElement Commands_Package_activation;

	@FindBy(xpath = "(//td[@class='left'])[15]")
	WebElement Cmds_Pkg_Subscrptn_tigger_On;

	@FindBy(xpath = "(//td[@class='left'])[16]")
	WebElement Cmds_Pkg_Subscrptn_Expiry_date;

	@FindBy(xpath = "(//td[@class='left'])[12]")
	WebElement Cmds_Pkg_Subscrptn_Package_name;
	
	@FindBy(xpath="//input[@id='scriptBox' and @name='filter_value']")
	WebElement Cmds_Pkg_Subscrptn_Search_STB_No;

	@FindBy(xpath="(//a[text()='De activate '])[1]")
	WebElement Cmds_Pkg_Subscrptn_Deactivate_STB;

	@FindBy(xpath="(//a[text()='De activate '])[1]")
	WebElement Cmds_Prdct_Subscrptn_Deactivate_STB;

	@FindBy(xpath="//input[@type='text' and @name='filter_stb']")
	WebElement Sales_cust_filter_STB;

	@FindBy(xpath="(//td[@class='left'])[18]")
	WebElement Sales_cust_Login_TO_Store_Pls_Select_option;

	@FindBy(xpath="//option[text()='Default']")
	WebElement Sales_cust_Login_TO_Store_default_button;

	@FindBy(xpath="//h1[text()='Package Subscription added  successfully!']")
	WebElement order_confirm;

	@FindBy(partialLinkText = "Package Desubscription")
	WebElement Package_DeSubscription;

	@FindBy(xpath="//select[@id='selectoption' and @name='option']")
	WebElement selectoption_from_to_;

	@FindBy(xpath="(//td[@class='model'])[2]")
	WebElement Pkg_nmbr;

	@FindBy(partialLinkText="STB wise change of Package/Channel")
	WebElement STB_wise_change_of_Package_Product;


	@FindBy(xpath = ".//*[@id='to_date']")
	WebElement from_date_option;

	@FindBy(xpath = ".//*[@id='from_date']")
	WebElement to_date_option;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[1]")
	WebElement from_from_date_prev_month;

	@FindBy(xpath = "//a[@class='ui-state-default' and text()='1']")
	WebElement from_from_date_first_date;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement from_from_date_next_month;

	@FindBy(xpath = "//a[@class='ui-state-default ui-state-active' and text()='1']")
	WebElement from_from_date_next_month_first_date;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement to_date_next_month;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[5]/a")
	WebElement to_date_next_month_first_date;

	@FindBy(xpath="//input[@type='text' and @name='filter_stbno']")
	WebElement STB_NO_box;

	@FindBy(partialLinkText = "Product Subscription")
	WebElement Product_Subscription;

	@FindBy(partialLinkText="Product Subscription")
	WebElement EMM_commands_product_subscription;

	@FindBy(partialLinkText = "Product Desubscription")
	WebElement Product_Desubscription;

	private void click_on_Commands_product_subscription(){
		commands.click();
		EMM_commands.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		EMM_commands_product_subscription.click();
		Cmds_Pkg_Subscrptn_Search_STB_No.sendKeys(STB_NO);
		search_option.click();
	}

	private void click_on_reports_historical_Product_Subscription_method() {
		reports.click();
		Historical.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Product_Subscription.click();
	}

	private void click_on_reports_historical_Product_Desubscription_method() {
		reports.click();
		Historical.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Product_Desubscription.click();

	}

	private void click_on_STB_wise_change_of_Package_Product(){

		reports.click();
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.elementToBeClickable(STB_wise_change_of_Package_Product)).click();
		from_date_option.click();
		from_date_option.sendKeys(Keys.ENTER);
		//			from_from_date_prev_month.click();
		//			from_from_date_first_date.click();
		to_date_option.click();
		to_date_option.sendKeys(Keys.ENTER);
		STB_NO_box.sendKeys(STB_NO);
		Filter_button.click();	
	}

	private void click_on_count_Package_Subscription(){


		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		//		act.moveToElement(count);
		count.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		act.click(Package_Subscription).build().perform();

		new Select(selectoption_from_to_).selectByVisibleText("Yearly");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String year = GetReportFilePath.current_year();
		select_year.click();
		new Select(select_year).selectByVisibleText(year);
		Filter_button.click();
	}

	private void click_on_count_Prdct_Subscription(){


		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		//		act.moveToElement(count);
		count.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		act.click(Prdct_Subscription).build().perform();

		new Select(selectoption_from_to_).selectByVisibleText("Yearly");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String year = GetReportFilePath.current_year();
		select_year.click();
		new Select(select_year).selectByVisibleText(year);
		Filter_button.click();
	}
	
	private void click_on_Reports_History_Package_DeSubscription() throws InterruptedException {

		Actions act = new Actions(driver);
		//act.moveToElement(reports).perform();
		//act.moveToElement(Historical);
		//act.click(Package_Subscription).build().perform();
		act.moveToElement(reports).build().perform();
		Historical.click();
		Thread.sleep(2000);
		Package_DeSubscription.click(); 

	}

	private void click_on_Reports_History_Package_Subscription() throws InterruptedException {

		Actions act = new Actions(driver);
		//act.moveToElement(reports).perform();
		//act.moveToElement(Historical);
		//act.click(Package_Subscription).build().perform();
		act.moveToElement(reports).build().perform();
		Historical.click();
		Thread.sleep(2000);
		Package_Subscription.click(); 

	}

	public static PDDocument PDF_Data_Reader() throws Throwable{

		PDDocument pdDoc;
		pdDoc = PDDocument.load( new File("D:\\Unzip\\packagesubscription_1.pdf"));
		return pdDoc;
	}

	public static PDDocument PDF_Data_Reader_prdct() throws Throwable{

		PDDocument pdDoc;
		pdDoc = PDDocument.load( new File("D:\\Unzip\\productsubscription_1.pdf"));
		return pdDoc;
	}

	public static PDDocument PDF_Data_Reader_prdct_DeSub() throws Throwable{

		PDDocument pdDoc;
		pdDoc = PDDocument.load( new File("D:\\Unzip\\productdesubscription_1.pdf"));
		return pdDoc;
	}
	public static PDDocument PDF_Data_Reader_Package_Desub() throws Throwable{

		PDDocument pdDoc;
		pdDoc = PDDocument.load( new File("D:\\Unzip\\packagedesubscription_1.pdf"));
		return pdDoc;
	}

	private void click_on_commands_Package_Subscription() throws InterruptedException {

		commands.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(2000);
		EMM_commands.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Commands_Package_activation.click();
	}

	private void Commands_Package_deactivate(){
		try {
			this.click_on_commands_Package_Subscription();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Cmds_Pkg_Subscrptn_Search_STB_No.sendKeys(STB_NO);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		search_option.click();
		Cmds_Pkg_Subscrptn_Deactivate_STB.click();
		//		String Package_name_after_deactivate = Cmds_Pkg_Subscrptn_Package_name.getText();
		//		String Package_trigger_on_after_deactivate = Cmds_Pkg_Subscrptn_tigger_On.getText();
		//		String Package_Expiry_after_deactivate = Cmds_Pkg_Subscrptn_Expiry_date.getText();
		//		System.out.println(Package_name_after_deactivate);
		//		System.out.println(Package_trigger_on_after_deactivate);
		//		System.out.println(Package_Expiry_after_deactivate);
		//		System.out.println(STB_NO);
	}


	private void Commands_Deactivate_STB(){
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

	}

	private void Commands_activate_STB(){
		this.click_on_commands_STB_Activation();
		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();    
	}

	private String Store_front_activate_package(){
		Actions act=new Actions(driver);		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		Sales.click();
		wait.until(ExpectedConditions.elementToBeClickable(Customertab)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Customersel)).click();
		Sales_cust_filter_STB.sendKeys(STB_NO);
		search_option.click();
		Sales_cust_Login_TO_Store_Pls_Select_option.click();
		Sales_cust_Login_TO_Store_default_button.click();
		System.out.println(driver.getTitle());

		// Store the current window handle
		String winHandleBefore = driver.getWindowHandle();

		// Perform the click operation that opens new window

		// Switch to new window opened
		for(String winHandle : driver.getWindowHandles()){
			driver.switchTo().window(winHandle);
		}

		act.moveToElement(Cust_package).build().perform();
		String aa=Cust_package1.getText();
		Cust_package1.click();
		System.out.println(aa);

		Select sel = new Select(Cust_package_subs_select);
		sel.selectByValue("1563");                                                                         //select first package

		wait.until(ExpectedConditions.elementToBeClickable(Add_to_cart_button)).click();
		//	assertEquals("Success: You have added", sucess_msg_add_to_cart.getText().substring(0, 23));
		Checkout_button.click();			
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_payment_1)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_shipping_2)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_shipping_3)).click();
		wait.until(ExpectedConditions.elementToBeClickable(cash_on_delivery)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Agree_terms_condition)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_shipping_4)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Confirm_Order)).click();
		String pkg_numbr=Pkg_nmbr.getText();
		WebDriverWait waited = new WebDriverWait(driver, 25);
		waited.until(ExpectedConditions.elementToBeClickable(order_confirm));


		// Perform the actions on new window

		// Close the new window, if that window no more required
		driver.close();

		// Switch back to original browser (first window)
		driver.switchTo().window(winHandleBefore);


		return pkg_numbr;
		// Continue with original browser (first window)


	}
	//------------------------------------------------------------------Pkg Subs and Pkg DeSub--------------------------------------------------------------------------

	public void Reports_historical_Package_Subscription_and_Desubcription_method() throws Throwable{

		//-----------------------------------------------------------------------------------Commands Package Deactivate---------------------------------------------			
		this.click_on_commands_Package_Subscription();
		Cmds_Pkg_Subscrptn_Search_STB_No.sendKeys(STB_NO);
		search_option.click();
		Cmds_Pkg_Subscrptn_Deactivate_STB.click();

		//---------------------------------------------------------------------------------------deactivate STB ------------------------------------------------------------------------------------------------------	
		this.click_on_commands_STB_Activation();
		box_act_search_box.sendKeys(STB_NO);
		search_option.click();
		command_deact_stb.click();	

		//----------------------------------------------------------------------------go to Commands STB Activation -----------------------------------------------------------------------------------------------

		this.click_on_commands_STB_Activation();
		command_act_insert_option.click();
		command_act_insert_STB_No.sendKeys(STB_NO);
		command_act_insert_Activate_button.click();                					   //Activate STB

		//-------------------------------------------------------------- go to Sales -> Customers -> Customer -> Subs Package-----------------------------------------------------------------------			
		this.Store_front_activate_package();

		//----------------------------------------------------------------Go to EMM Commands -> Package Subscription -----------------------------------------------------------------------

		this.click_on_commands_Package_Subscription();
		Cmds_Pkg_Subscrptn_Search_STB_No.sendKeys(STB_NO);
		search_option.click();
		String Package_name = Cmds_Pkg_Subscrptn_Package_name.getText();
		String Package_trigger_on = Cmds_Pkg_Subscrptn_tigger_On.getText();
		String Package_Expiry = Cmds_Pkg_Subscrptn_Expiry_date.getText();
		System.out.println(Package_name);
		System.out.println(Package_trigger_on+"-------------------------------------------------<");
		System.out.println(Package_Expiry);
		System.out.println(STB_NO);

		//----------------------------------------------------------------Go to Historical Package Subscription-----------------------------------------------------------------------

		//driver.quit();
		GetReportFilePath.DeleteFolderfiles();

		this.click_on_Reports_History_Package_Subscription();
		//		Actions act = new Actions(driver);
		//		Thread.sleep(2000);
		//		act.moveToElement(reports).perform();
		//		act.moveToElement(Historical);
		//		act.click(Package_Subscription).build().perform();

		Select sele = new Select(from_to_monthly_yearly_option);


		sele.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Thread.sleep(1000);

		GetReportFilePath.FileNameReadUnzip();
		Thread.sleep(1000);

		GetReportFilePath.FileNameRead();

		String value = GetReportFilePath.Read_PDF_name();
		System.out.println(value);
		Assert.assertEquals(value, "packagesubscription_1.pdf");			

		PDFTextStripper g = new PDFTextStripper();
		//System.out.println(g.getText(PDF_Data_Reader()));
		assertTrue(g.getText(PDF_Data_Reader()).contains(Package_name));  //Package_name 
		assertTrue(g.getText(PDF_Data_Reader()).contains(Package_trigger_on));  //Package_trigger_on 
		assertTrue(g.getText(PDF_Data_Reader()).contains(Package_Expiry));  //Package_Expiry 
		assertTrue(g.getText(PDF_Data_Reader()).contains(STB_NO));  //STB_NO 
		System.out.println("Package_name in PDF Historical -> Package Subscription------------->"+ Package_name);
		System.out.println("Package_trigger_on in PDF Historical -> Package Subscription------------->"+ Package_trigger_on);
		System.out.println("Package_Expiry in PDF Historical -> Package Subscription------------->"+ Package_Expiry);
		System.out.println("STB_NO in PDF Historical -> Package Subscription------------->"+ STB_NO);

		//----------------------------------------------------------------------------go to STB History and Check Package Subscription -----------------------------------------------------------------------------------------------

		this.click_on_STB_Historyt();
		filter_stbno_box.sendKeys(STB_NO);
		Select sell = new Select(filter_command_dropdown);
		sell.selectByVisibleText("Package Subscription");
		Filter_button.click();
		String str = "//td[@class='left' and text()='";
		String Package_Trigger_Date_time_after_package_Sub = str+Package_trigger_on+"']";
		String Package_deactivation_date_time_after__package_Sub = str+Package_Expiry+"']";
		String STB_NO_after_package_Sub = str+STB_NO+"']";
		String Package_name_After_Package_sub = str+Package_name+"']";

		driver.findElement(By.xpath(Package_Trigger_Date_time_after_package_Sub)).isDisplayed();
		driver.findElement(By.xpath(Package_deactivation_date_time_after__package_Sub)).isDisplayed();
		driver.findElement(By.xpath(Package_name_After_Package_sub)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_after_package_Sub)).isDisplayed();
		System.out.println("Package Sub_Trigger Date and Time in STB History---------------->"+driver.findElement(By.xpath(Package_Trigger_Date_time_after_package_Sub)).getText());
		System.out.println("Package Sub_deactivation Date and Time in STB History---------------->"+driver.findElement(By.xpath(Package_deactivation_date_time_after__package_Sub)).getText());
		System.out.println("Package Sub _deactivation in STB History------------------------>"+driver.findElement(By.xpath(Package_name_After_Package_sub)).getText());
		System.out.println("STB_NO in STB History------------------------>"+driver.findElement(By.xpath(STB_NO_after_package_Sub)).getText());




		//----------------------------------------------------------------Go to EMM Commands -> Package Subscription -> Deactivate Package -----------------------------------------------------------------------

		this.click_on_commands_Package_Subscription();
		Thread.sleep(1000);
		Cmds_Pkg_Subscrptn_Search_STB_No.sendKeys(STB_NO);
		Thread.sleep(1000);
		search_option.click();
		Cmds_Pkg_Subscrptn_Deactivate_STB.click();
		String Package_name_after_deactivate = Cmds_Pkg_Subscrptn_Package_name.getText();
		String Package_trigger_on_after_deactivate = Cmds_Pkg_Subscrptn_tigger_On.getText();
		String Package_Expiry_after_deactivate = Cmds_Pkg_Subscrptn_Expiry_date.getText();
		System.out.println(Package_name_after_deactivate);
		System.out.println(Package_trigger_on_after_deactivate);
		System.out.println(Package_Expiry_after_deactivate);
		System.out.println(STB_NO);


		//----------------------------------------------------------------Go to Historical Package DeSubscription-----------------------------------------------------------------------

		this.click_on_Reports_History_Package_DeSubscription();
		GetReportFilePath.DeleteFolderfiles();

		sele.selectByVisibleText("Yearly");
		selec.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Thread.sleep(1000);

		GetReportFilePath.FileNameReadUnzip();
		Thread.sleep(1000);

		GetReportFilePath.FileNameRead();
		String valuee = GetReportFilePath.Read_PDF_name();
		System.out.println(valuee);

		Assert.assertEquals(valuee, "packagedesubscription_1.pdf");			


		//System.out.println(g.getText(PDF_Data_Reader()));
		assertTrue(g.getText(PDF_Data_Reader_Package_Desub()).contains(Package_name_after_deactivate));  //Package_name 
		assertTrue(g.getText(PDF_Data_Reader_Package_Desub()).contains(Package_trigger_on_after_deactivate));  //Package_trigger_on 
		//	assertTrue(g.getText(PDF_Data_Reader_Package_Desub()).contains(Package_Expiry_after_deactivate));  //Package_Expiry 
		assertTrue(g.getText(PDF_Data_Reader_Package_Desub()).contains(STB_NO));  //STB_NO 
		System.out.println("Package_name_after_deactivate in PDF Historical -> Package Subscription------------->"+ Package_name_after_deactivate);
		System.out.println("Package_trigger_on_after_deactivate in PDF Historical -> Package Subscription------------->"+ Package_trigger_on_after_deactivate);
		//System.out.println("Package_Expiry_after_deactivate in PDF Historical -> Package Subscription------------->"+ Package_Expiry_after_deactivate);
		System.out.println("STB_NO in PDF Historical -> Package Subscription------------->"+ STB_NO);


		//----------------------------------------------------------------------------go to STB History and Check Package DeSubscription -----------------------------------------------------------------------------------------------

		this.click_on_STB_Historyt();
		filter_stbno_box.sendKeys(STB_NO);
		sell.selectByVisibleText("Package De-Subscription");
		Filter_button.click();

		String Package_Trigger_Date_time_after_package_DeSub = str+Package_trigger_on_after_deactivate+"']";
		//String Package_deactivation_date_time_after__package_DeSub = str+Package_Expiry_after_deactivate+"']";
		String STB_NO_after_package_DeSub = str+STB_NO+"']";
		String Package_name_After_Package_Desub = str+Package_name_after_deactivate+"']";

		driver.findElement(By.xpath(Package_name_After_Package_Desub)).isDisplayed();
		//driver.findElement(By.xpath(Package_deactivation_date_time_after__package_DeSub)).isDisplayed();
		driver.findElement(By.xpath(Package_name_After_Package_Desub)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_after_package_DeSub)).isDisplayed();
		System.out.println("Package DeSub_Trigger Date and Time in STB History---------------->"+driver.findElement(By.xpath(Package_Trigger_Date_time_after_package_DeSub)).getText());
		//System.out.println("Package Desub_deactivation Date and Time in STB History---------------->"+driver.findElement(By.xpath(Package_deactivation_date_time_after__package_DeSub)).getText());
		System.out.println("Package Desub_deactivation in STB History------------------------>"+driver.findElement(By.xpath(Package_name_After_Package_Desub)).getText());
		System.out.println("STB_NO in STB History------------------------>"+driver.findElement(By.xpath(STB_NO_after_package_DeSub)).getText());



	}
	@FindBy(xpath=".//*[@id=' ']/ul/li[7]/ul/a[4]")
	WebElement Package_subscription;
	
	@FindBy(xpath=".//*[@id=' ']/ul/li[7]/ul/a[3]")
	WebElement Prdct_subscription;

	String str3 = "//td[@class='left' and text()='";
	String str1 = "//td[@class='center' and text()='";
	String str2 = "(//td[@class='center' and text()='";
	
	private void click_on_list_package_subscription(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(list);
		act.click(Package_subscription).build().perform();
		new Select(selectoption_from_to).selectByVisibleText("Yearly");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String year = GetReportFilePath.current_year();
		select_year.click();
		new Select(select_year).selectByVisibleText(year);
		Filter_button.click();
	}

	private void click_on_list_prdct_subscription(){

		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(list);
		act.click(Prdct_subscription).build().perform();
		new Select(selectoption_from_to).selectByVisibleText("Yearly");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String year = GetReportFilePath.current_year();
		select_year.click();
		new Select(select_year).selectByVisibleText(year);
		Filter_button.click();
	}
	public void Reports_List_and_Count_Package_Subscription_and_STB_wise_change_of_Package_Product_method() throws InterruptedException{


		this.Commands_Package_deactivate();

		//		this.click_on_count_Package_Subscription();
		//		WebElement pkg_nme = driver.findElement(By.xpath("(//td[@class='left'])[4]"));
		//		WebElement adjecent_count = pkg_nme.findElement(By.xpath("(//td[@class='left'])[5]"));
		//		System.out.println("before-------------->"+ adjecent_count.getText());

		this.Commands_activate_STB();
		String pkg_nmbr=this.Store_front_activate_package();

		//		this.click_on_count_Package_Subscription();
		//		WebElement pkg_nme_aft_subs = driver.findElement(By.xpath("(//td[@class='left'])[4]"));
		//		WebElement adjecent_count_aft_sub = pkg_nme_aft_subs.findElement(By.xpath("(//td[@class='left'])[5]"));
		//		System.out.println("After-------------->"+adjecent_count_aft_sub.getText());

		this.click_on_commands_Package_Subscription();
		String Pkg_name_aft_Subs = Cmds_Pkg_Subscrptn_Package_name.getText();
		String Pkg_triggr_on_aft_Subs = Cmds_Pkg_Subscrptn_tigger_On.getText();
		String Pkg_Exp_aft_Subs = Cmds_Pkg_Subscrptn_Expiry_date.getText();
		System.out.println(Pkg_name_aft_Subs);
		System.out.println(Pkg_triggr_on_aft_Subs);
		System.out.println(Pkg_Exp_aft_Subs);
		System.out.println(STB_NO);

		this.click_on_list_package_subscription();
		driver.findElement(By.xpath(str3+pkg_nmbr+"']")).isDisplayed();
		driver.findElement(By.xpath(str3+Pkg_triggr_on_aft_Subs+"']")).isDisplayed();
		driver.findElement(By.xpath(str3+Pkg_Exp_aft_Subs+"']")).isDisplayed();
		driver.findElement(By.xpath(str3+STB_NO+"']")).isDisplayed();

		System.out.println(pkg_nmbr);

		this.click_on_STB_wise_change_of_Package_Product();
		driver.findElement(By.xpath(str2+pkg_nmbr+"'])[1]")).isDisplayed();
		driver.findElement(By.xpath(str1+Pkg_triggr_on_aft_Subs+"']")).isDisplayed();
		driver.findElement(By.xpath(str1+Pkg_Exp_aft_Subs+"']")).isDisplayed();
		driver.findElement(By.xpath(str1+STB_NO+"']")).isDisplayed();

		this.Commands_Package_deactivate();
		String Package_trigger_on_after_deactivate = Cmds_Pkg_Subscrptn_tigger_On.getText();
		String Package_Expiry_after_deactivate = Cmds_Pkg_Subscrptn_Expiry_date.getText();

		this.click_on_STB_wise_change_of_Package_Product();
		driver.findElement(By.xpath(str1+Package_trigger_on_after_deactivate+"']")).isDisplayed();
		driver.findElement(By.xpath(str1+Package_Expiry_after_deactivate+"']")).isDisplayed();
		driver.findElement(By.xpath(str1+STB_NO+"']")).isDisplayed();

	}

	private void cmds_deAct_prdct(){
		this.click_on_Commands_product_subscription();
		Cmds_Prdct_Subscrptn_Deactivate_STB.click();

	}

	@FindBy(xpath = "(//a[text()='Channel Packages'])[1]")
	public WebElement Cust_prdct;

	@FindBy(xpath = "//a[text()='News (11)']")
	public WebElement Cust_prdct_news;

	@FindBy(xpath = "(//input[@class='button' and @value='Check Details'])[1]")
	public WebElement Cust_prdct_news_Chck_details;

	@FindBy(xpath = "//select[@name='option[1406]']")
	public WebElement Cust_prdct_subs_select;

	@FindBy(xpath = "//h1[text()='Product Subscription added  successfully!']")
	public WebElement ordr_cnfrm_prdct;


	private String Store_front_activate_Product(){
		Actions act=new Actions(driver);		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		Sales.click();
		wait.until(ExpectedConditions.elementToBeClickable(Customertab)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Customersel)).click();
		Sales_cust_filter_STB.sendKeys(STB_NO);
		search_option.click();
		Sales_cust_Login_TO_Store_Pls_Select_option.click();
		Sales_cust_Login_TO_Store_default_button.click();
		System.out.println(driver.getTitle());

		// Store the current window handle
		String winHandleBefore = driver.getWindowHandle();

		// Perform the click operation that opens new window

		// Switch to new window opened
		for(String winHandle : driver.getWindowHandles()){
			driver.switchTo().window(winHandle);
		}

		act.moveToElement(Cust_prdct).build().perform();
		String aa=Cust_prdct_news.getText();
		Cust_prdct_news.click();
		System.out.println(aa);
		//Cust_prdct.click();

		Cust_prdct_news_Chck_details.click();                                    //select first product
		Select sel = new Select(Cust_prdct_subs_select);
		sel.selectByValue("1508");                                                                     

		wait.until(ExpectedConditions.elementToBeClickable(Add_to_cart_button)).click();
		//	assertEquals("Success: You have added", sucess_msg_add_to_cart.getText().substring(0, 23));
		Checkout_button.click();			
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_payment_1)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_shipping_2)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_shipping_3)).click();
		wait.until(ExpectedConditions.elementToBeClickable(cash_on_delivery)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Agree_terms_condition)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Continue_button_shipping_4)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Confirm_Order)).click();
		String pkg_numbr=Pkg_nmbr.getText();
		WebDriverWait waited = new WebDriverWait(driver, 25);
		waited.until(ExpectedConditions.elementToBeClickable(ordr_cnfrm_prdct));


		// Perform the actions on new window

		// Close the new window, if that window no more required
		driver.close();

		// Switch back to original browser (first window)
		driver.switchTo().window(winHandleBefore);


		return pkg_numbr;
		// Continue with original browser (first window)
	}

	public void Rprts_Hstricl_Prdct_Act_Deact_and_Histry_Act_DeAct_method() throws Throwable{
		this.Commands_Package_deactivate();
		this.cmds_deAct_prdct();
		this.Store_front_activate_Product();
		this.click_on_Commands_product_subscription();

		String Prdct_name_aft_Subs = Cmds_Pkg_Subscrptn_Package_name.getText();
		String Pkg_triggr_on_aft_Subs = Cmds_Pkg_Subscrptn_tigger_On.getText();
		String Pkg_Exp_aft_Subs = Cmds_Pkg_Subscrptn_Expiry_date.getText();

		this.click_on_reports_historical_Product_Subscription_method();
		Select sele = new Select(from_to_monthly_yearly_option);
		sele.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches("Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Thread.sleep(1000);
		GetReportFilePath.FileNameReadUnzip();
		Thread.sleep(1000);
		GetReportFilePath.FileNameRead();

		PDFTextStripper g = new PDFTextStripper();
		assertTrue(g.getText(PDF_Data_Reader_prdct()).contains(Prdct_name_aft_Subs));  //Product_name 
		assertTrue(g.getText(PDF_Data_Reader_prdct()).contains(Pkg_triggr_on_aft_Subs));  //Product_trigger_on 
		assertTrue(g.getText(PDF_Data_Reader_prdct()).contains(Pkg_Exp_aft_Subs));  //Product_Expiry 
		assertTrue(g.getText(PDF_Data_Reader_prdct()).contains(STB_NO));  //STB_NO 

		
		this.click_on_STB_Historyt();
		filter_stbno_box.sendKeys(STB_NO);
		Select sell = new Select(filter_command_dropdown);
		sell.selectByVisibleText("Product Subscription");
		Filter_button.click();
		String str = "//td[@class='left' and text()='";
		String Prdct_Trigger_Date_time_after_prdct_Sub = str+Pkg_triggr_on_aft_Subs+"']";
		String Prdct_deactivation_date_time_after__prdct_Sub = str+Pkg_Exp_aft_Subs+"']";
		String STB_NO_after_Prdct_Sub = str+STB_NO+"']";
		String Prdct_name_After_Prdct_sub = str+Prdct_name_aft_Subs+"']";

		driver.findElement(By.xpath(Prdct_Trigger_Date_time_after_prdct_Sub)).isDisplayed();
		driver.findElement(By.xpath(Prdct_deactivation_date_time_after__prdct_Sub)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_after_Prdct_Sub)).isDisplayed();
		driver.findElement(By.xpath(Prdct_name_After_Prdct_sub)).isDisplayed();

		this.cmds_deAct_prdct();
		this.click_on_Commands_product_subscription();
		String Prdct_name_aft_DeSubs = Cmds_Pkg_Subscrptn_Package_name.getText();
		String Prdct_triggr_on_aft_DeSubs = Cmds_Pkg_Subscrptn_tigger_On.getText();

		this.click_on_reports_historical_Product_Desubscription_method();
		sele.selectByVisibleText("Yearly");
		selec.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches("Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Thread.sleep(1000);
		GetReportFilePath.FileNameReadUnzip();
		Thread.sleep(1000);
		GetReportFilePath.FileNameRead();

		assertTrue(g.getText(PDF_Data_Reader_prdct_DeSub()).contains(Prdct_name_aft_DeSubs));  //Product_name 
		assertTrue(g.getText(PDF_Data_Reader_prdct_DeSub()).contains(Prdct_triggr_on_aft_DeSubs));  //Product_trigger_on 
		assertTrue(g.getText(PDF_Data_Reader_prdct_DeSub()).contains(STB_NO));  //STB_NO 
		
		this.click_on_STB_Historyt();
		filter_stbno_box.sendKeys(STB_NO);
		sell.selectByVisibleText("Product De-Subscription");
		Filter_button.click();
		String Prdct_Trigger_Date_time_after_prdct_DeSub = str+Prdct_triggr_on_aft_DeSubs+"']";
		String STB_NO_after_Prdct_DeSub = str+STB_NO+"']";
		String Prdct_name_After_Prdct_Desub = str+Prdct_name_aft_DeSubs+"']";

		driver.findElement(By.xpath(Prdct_Trigger_Date_time_after_prdct_DeSub)).isDisplayed();
		driver.findElement(By.xpath(STB_NO_after_Prdct_DeSub)).isDisplayed();
		driver.findElement(By.xpath(Prdct_name_After_Prdct_Desub)).isDisplayed();


	}

	public void Reprts_List_Count_Prdct_Subs_method(){
		this.Commands_Package_deactivate();
		this.cmds_deAct_prdct();
		String Prdct_name=Store_front_activate_Product();
		this.click_on_Commands_product_subscription();

		String Prdct_triggr_on_aft_Subs = Cmds_Pkg_Subscrptn_tigger_On.getText();
		String Prdct_Exp_aft_Subs = Cmds_Pkg_Subscrptn_Expiry_date.getText();

		this.click_on_list_prdct_subscription();
		driver.findElement(By.xpath(str3+Prdct_Exp_aft_Subs+"']")).isDisplayed();
		driver.findElement(By.xpath(str3+Prdct_triggr_on_aft_Subs+"']")).isDisplayed();
		driver.findElement(By.xpath(str3+STB_NO+"']")).isDisplayed();
		
		this.cmds_deAct_prdct();
		this.click_on_Commands_product_subscription();
	//	String Prdct_name_aft_DeSubs = Cmds_Pkg_Subscrptn_Package_name.getText();
		String Prdct_triggr_on_aft_DeSubs = Cmds_Pkg_Subscrptn_tigger_On.getText();
		
		this.click_on_list_prdct_subscription();
		driver.findElement(By.xpath(str3+Prdct_triggr_on_aft_DeSubs+"']")).isDisplayed();
		driver.findElement(By.xpath(str3+STB_NO+"']")).isDisplayed();
		
		this.click_on_count_Prdct_Subscription();
		WebElement prdct_nme = driver.findElement(By.xpath("//td[@class='left' and text()='"+Prdct_name+"']"));
        WebElement adjecent_count = prdct_nme.findElement(By.xpath("//td[@class='left' and text()='"+Prdct_name+"']/../td[4]"));
        int count = Integer.parseInt(adjecent_count.getText());
        System.out.println(adjecent_count.getText()+"...........................");
        
        String Prdct_namee=Store_front_activate_Product();
        this.click_on_count_Prdct_Subscription();
		WebElement prdct_nmeee = driver.findElement(By.xpath("//td[@class='left' and text()='"+Prdct_namee+"']"));
        WebElement adjecent_countt = prdct_nmeee.findElement(By.xpath("//td[@class='left' and text()='"+Prdct_namee+"']/../td[4]"));
        String ccccc=adjecent_countt.getText();
        System.out.println(ccccc+"''''''''''''''''''''''''");
        assertEquals(count, ccccc);
		
		
	}

}