package com.reports;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import test.baseclass.*;
import excelreader.ExcelReader;

import test.reports.Historical_STB_DeActivations;

public class Reports_history_DeActivations {

	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
	
	@FindBy(xpath = "//a[@class='parent' and text()='Historical']")
	WebElement Historical;
	
	@FindBy(partialLinkText = "STB DeActivations")
	WebElement STB_DeActivations;
	
	@FindBy(xpath = ".//*[@id='content']/div[1]/a[2]")
	WebElement Historical_STB_DeActivations_link;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath = ".//*[@id='selectoption']")
	WebElement from_to_monthly_yearly_option;
	
	@FindBy(xpath = "//input[@id='to_date' and @type='text' and @name='filter_date_start']")
	WebElement date_start_box;
	
	@FindBy(xpath = "//input[@id='from_date' and @type='text' and @name='filter_date_end']")
	WebElement date_end_box;
	
	@FindBy(xpath = "//a[@class='button' and text()='Report Generate']")
	WebElement Report_Generate_button;
	
	@FindBy(xpath = ".//*[@id='date-start']")
	WebElement date_start;
	
	@FindBy(xpath = ".//*[@id='date-end']")
	WebElement date_end;
	
	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[1]/span")
	WebElement date_start_calender_back_month;
	
	@FindBy(xpath = "//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_calender_back_month_first_date;
	
	@FindBy(xpath = "(.//*[@id='form']/table/tbody/tr[1]/td[2])[2]")
	WebElement Date_of_Generation_first_option;
	
	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[1]")
	WebElement Report_Name_first_option;
	
	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[3]/a")
	WebElement download_first_option;
	
	@FindBy(xpath = ".//*[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[6]/a")
	WebElement date_start_box_first_date;
	
	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[6]/a")
	WebElement date_end_box_first_date;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_start_box_next_month;
	
	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_end_box_next_month;
	
	@FindBy(xpath = ".//*[@id='year_date']")
	WebElement date_year;
	
	@FindBy(xpath = "//a[@class='top' and text()='Commands']")
	WebElement commands;
	
	@FindBy(xpath = "//a[@class='parent' and text()='EMM Commands']")
	public WebElement EMM_commands;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[4]")
	WebElement EMM_Commands_search_Ist_Result;
	
	@FindBy(xpath=".//*[@class='left' and text()='0000-00-00 00:00:00']")
	WebElement EMM_Commands_search_00;
	
	@FindBy(partialLinkText = "Box Activation")
	public WebElement Box_Activation;
	
	 @FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[2]")   //commands>EMM Commands >STB Activation
	 WebElement copy_first_customer_STB_NO;
	
	 @FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[5]")
	 WebElement copy_first_customer_first_name;
	
	 @FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[3]")
	 WebElement copy_first_customer_Activation_time_;
	
	 @FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[4]")
	 WebElement copy_first_customer_Deactivation_time_;
	
	 @FindBy(xpath = "//a[text()='Sales']")
	 WebElement Sales;
		
	@FindBy(partialLinkText = "Customers")
	public WebElement Customertab;
	
	@FindBy(xpath = "(//a[text()='Customers'])[2]")
	public WebElement Customersel;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[2]/td[4]")
	WebElement sales_customer_copy_first_STB_NO;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[4]/input")
	WebElement sales_customers_STB_search_option;
	
	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement sales_customers_search_option;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[2]/td[11]/a")
	WebElement sales_customers_click_first_edit;
	
	@FindBy(xpath=".//*[@id='tab-customer']/table/tbody/tr[2]/td[2]/input")
	WebElement sales_customers_click_first_name_option;
	
	@FindBy(xpath="//a[@class='button' and  text()='Submit']")
	WebElement sales_customers_Submit_button;
		
	@FindBy(xpath=".//*[@id='tab-customer']/table/tbody/tr[6]/td[2]/input")
	WebElement sales_customers_confirm_passwd;
	
	@FindBy(xpath="//a[@class='button' and  text()='Submit']")
	WebElement sales_customers_Success_msg;
	
	
	
	
	
private void click_on_commands_STB_Activation(WebDriver driver) {
		
	    commands.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		EMM_commands.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Box_Activation.click();
	}

    private void click_on_sales_customers(WebDriver driver) {
		
     	Actions act=new Actions(driver);
		act.moveToElement(Sales).perform();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		act.moveToElement(Customertab);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		act.click(Customersel).build().perform();
		
 }

	ExcelReader read = new ExcelReader();
	
	public void click_on_reports_historical_STB_DeActivation_method() {
		reports.click();
		Historical.click();
		STB_DeActivations.click();
	}
	
public static PDDocument PDF_Data_Reader() throws Throwable{
		
		PDDocument pdDoc;
		//String value = Read_PDF_name();
		pdDoc = PDDocument.load( new File("D:\\Unzip\\historicaldeactivation_1.pdf"));
		                        //          \\"D:\\Unzip\\historicalactivation_1.pdf"
		System.out.println(pdDoc.getNumberOfPages());
		return pdDoc;
}	
	
	public void verify_element_method(WebDriver driver) {
		this.click_on_reports_historical_STB_DeActivation_method();
		
		Historical_STB_DeActivations_link.click();
		assertTrue(driver.getTitle().matches("Historical STB DeActivations"));
		
		assertTrue(Historical_STB_DeActivations_link.getText().trim()
				.matches("Historical STB DeActivations"));
		assertTrue(date_start.getText().substring(1, 5).matches("From"));
		assertTrue(date_end.getText().substring(1, 4).matches("To:"));
		assertTrue(Report_Generate_button.getText().trim()
				.matches("Report Generate"));
		assertTrue(driver.getTitle().matches("Historical STB DeActivations"));
		assertTrue(driver
				.findElement(By.xpath(".//*[text()='Report History']"))
				.getText().matches("REPORT HISTORY"));
		assertTrue(driver
				.findElement(
						By.xpath(".//*[@class='left' and text()='Report Name']"))
				.getText().matches("Report Name"));
		assertTrue(driver
				.findElement(
						By.xpath(".//*[@class='left' and text()='Date of Generation']"))
				.getText().matches("Date of Generation"));
		assertTrue(driver
				.findElement(
						By.xpath(".//*[@class='center' and text()='Download Link']"))
				.getText().matches("Download Link"));

		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Monthly");
		sel.selectByVisibleText("Yearly");
		
		Home_link.click();
		assertTrue(driver.getTitle().matches("Dashboard"));	
	
	}
	 
	public void Validation_Generate_button_method(WebDriver driver) throws InterruptedException {
		this.click_on_reports_historical_STB_DeActivation_method();
		date_start_box.click();
		date_start_calender_back_month.click();
		date_start_calender_back_month_first_date.click();
		date_end_box.click();
		date_end_box.sendKeys(Keys.ENTER);
		Report_Generate_button.click();
		Thread.sleep(5000);
		assertTrue(msg_sucess.getText().matches("Report Generated Successfully!"));
 
		GetReportFilePath.date_time_stamp();
		String str3 = String.valueOf(Report_Name_first_option.getText().subSequence(0, 19));
	    //assertTrue(str3.matches("Hist_DeAct_" + GetReportFilePath.date_time_stamp()));
		System.out.println(GetReportFilePath.date_time_stamp());

		String str4 = String.valueOf(Date_of_Generation_first_option.getText().subSequence(0, 10));
		System.out.println(str4);
		assertTrue(str4.matches(GetReportFilePath.date_time_stamp()));

		assertTrue(download_first_option.getText().matches("Download"));

	}

	public void invalid_test_cases_method(WebDriver driver) {
		this.click_on_reports_historical_STB_DeActivation_method();
		Report_Generate_button.click();
		assertTrue(msg_error.getText().matches(
				"Warning : Invalid date specified!"));

		date_start_box.click();
		date_start_box.sendKeys(Keys.ENTER);
		date_end_box.click();
		driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w' and text()='Prev']")).click();
		driver.findElement(By.xpath("//a[@class='ui-state-default' and text()='1']")).click();
		Report_Generate_button.click();
		assertTrue(msg_error.getText().matches("Warning : To date is greater than From date!"));

		date_start_box.click();
		date_start_box_next_month.click();
		date_start_box_first_date.click();
		date_end_box.click();
		date_end_box_next_month.click();
		date_end_box_next_month.click();
		date_end_box_first_date.click();
		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches("No Records in this duration!"));

		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Monthly");
		Report_Generate_button.click();
		assertTrue(msg_error.getText().matches("Warning : Please select month!"));

		//sel.selectByVisibleText("Monthly");
		// System.out.println(month_verify());
		// this.getMonthForInt(11);

		sel.selectByVisibleText("Yearly");
		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches("No Records in this duration!"));

		Select sell = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText("2019");
		Report_Generate_button.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(msg_sucess.getText().matches("No Records in this duration!"));

	}
	@FindBy(xpath="//input[@id='month_date' and @name='month']")
	WebElement month_sel;
	
	public void Validation_method(WebDriver driver) throws Throwable {
		
		this.click_on_reports_historical_STB_DeActivation_method();
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files
		// date_start_box.click();
		// date_start_calender_back_month.click();
		// date_start_box_first_date.click();
		// date_end_box.click();
		// date_end_box.sendKeys(Keys.ENTER);

		Select selll = new Select(from_to_monthly_yearly_option);
		selll.selectByVisibleText("Monthly");
		month_sel.click();
		String dateee = GetReportFilePath.current_month();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//td[@class='ui-state-default mtz-monthpicker mtz-monthpicker-month' and text()='"+dateee+"']")).click();

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		
		
		
		
		
		this.click_on_reports_historical_STB_DeActivation_method();
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files
		// date_start_box.click();
		// date_start_calender_back_month.click();
		// date_start_box_first_date.click();
		// date_end_box.click();
		// date_end_box.sendKeys(Keys.ENTER);

		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		Robot object = new Robot();
//		object.keyPress(KeyEvent.VK_DOWN);
//		object.keyRelease(KeyEvent.VK_DOWN);
//		Thread.sleep(2000);
//		object.keyPress(KeyEvent.VK_ENTER);
//		object.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		GetReportFilePath.FileNameReadUnzip();
		GetReportFilePath.FileNameRead();

		String value = GetReportFilePath.Read_PDF_name();
		System.out.println(value);
		Assert.assertEquals(value, "historicaldeactivation_1.pdf");
		
		
		PDFTextStripper g = new PDFTextStripper();
		String str1 = read.getsheetnumber(44, 0, 0);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str1));  //Sl No.
		
		String str2 = read.getsheetnumber(44, 0, 1);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str2));   //Customer No
				
		String str4 = read.getsheetnumber(44, 0, 2);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str4));   //Customer Name
		
		String str5 = read.getsheetnumber(44, 0, 3);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str5));   //STB No.
		
		String str6 = read.getsheetnumber(44, 0, 4);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str6));    //Trigger On
		
		String str7 = read.getsheetnumber(44, 0, 5);
		System.out.println(str7);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str7));    //Operator
		
//		String str8 = String.valueOf(read.getsheetnumber(45, 0, 6));
//		System.out.println(str8);
//		assertTrue(g.getText(PDF_Data_Reader()).contains(str8));   //Company Email ID and Full Address 
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		this.click_on_commands_STB_Activation(driver);
		
	
		
		String str11 = copy_first_customer_first_name.getText().trim();             //first Name
		System.out.println(str11);
		String str12 = copy_first_customer_STB_NO.getText().trim();                 // First STB No.
		System.out.println(str12);
		String str13 = copy_first_customer_Activation_time_.getText().trim();       // First STB Activation Time
		System.out.println(str13);
		String str14 = copy_first_customer_Deactivation_time_.getText().trim();       // First STB DeActivation Time
		System.out.println(str14);
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		String[] parts = str11.split("\\ "); // String array, each element is text between space
		String First_name = parts[0]; 
		System.out.println(First_name);
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//assertTrue(g.getText(PDF_Data_Reader()).contains(First_name)); // First Customer name search in PDF
				
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str12));           // First STB No. search in PDF
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str13));     // First STB No Trigger On search in PDF
		
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//assertTrue(g.getText(PDF_Data_Reader()).contains(str14));    // First STB No DeActivation Time search in PDF
			
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   
		assertTrue(g.getText(PDF_Data_Reader()).contains(GetReportFilePath.current_date()));	// Find current date in PDF	

	}
	
	public void change_customer_name_check_in_PDF_method(WebDriver driver) throws Throwable{
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files
		this.click_on_sales_customers(driver);
		String copy_customer_new_name = read.getsheetnumber(44, 1, 0);
		String copy_first_STB_NO =sales_customer_copy_first_STB_NO.getText().trim();
		sales_customers_STB_search_option.sendKeys(copy_first_STB_NO);
		sales_customers_search_option.click();      // Click Search
		sales_customers_click_first_edit.click();    //click first edit button
		sales_customers_click_first_name_option.clear();
		sales_customers_click_first_name_option.sendKeys(copy_customer_new_name);
		sales_customers_Submit_button.click();
		
		this.click_on_commands_STB_Activation(driver);
		driver.findElement(By.xpath(".//*[@id='scriptBox']")).sendKeys(copy_first_STB_NO);
		driver.findElement(By.xpath("//a[@class='button' and text()='Search']")).click();
		if(EMM_Commands_search_Ist_Result.getText().trim().matches("0000-00-00 00:00:00")==true){
			System.out.println("if loop is running");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
			this.execute_process(driver);			
		}
		else
		{
		System.out.println("else isworking now");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
		driver.findElement(By.xpath(".//*[@id='form']/table/tbody/tr[1]/td[9]/a")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		this.execute_process(driver);	
		}
	}
			
		
		public void execute_process(WebDriver driver) throws Throwable{
		String copy_customer_new_name = read.getsheetnumber(44, 1, 0);
	
		this.click_on_reports_historical_STB_DeActivation_method();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files
		
		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches("Report Generated Successfully!"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		Robot object = new Robot();
////		object.keyPress(KeyEvent.VK_DOWN);
////		object.keyRelease(KeyEvent.VK_DOWN);
//		Thread.sleep(2000);
//		object.keyPress(KeyEvent.VK_ENTER);
//		object.keyRelease(KeyEvent.VK_ENTER);
		
		Thread.sleep(2000);
		
		GetReportFilePath.FileNameReadUnzip();
		GetReportFilePath.FileNameRead();

		String value = GetReportFilePath.Read_PDF_name();
		System.out.println(value);
		Assert.assertEquals(value, "historicaldeactivation_1.pdf");
				
		PDFTextStripper g = new PDFTextStripper();
			
     	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     	assertTrue(g.getText(PDF_Data_Reader()).contains(copy_customer_new_name));   //Check edited customer name 
				
	}
}

