package com.reports;

import static org.testng.Assert.assertTrue;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class Reports_Historical_product_subscription {

	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;

	@FindBy(xpath = "//a[@class='parent' and text()='Historical']")
	WebElement Historical;

	@FindBy(partialLinkText = "Product Subscription")
	WebElement Product_Subscription;

	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Historical_Product_Subscription_link;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;

	@FindBy(xpath = ".//*[@id='selectoption']")
	WebElement from_to_monthly_yearly_option;

	@FindBy(xpath = "//input[@id='to_date' and @type='text' and @name='filter_date_start']")
	WebElement date_start_box;

	@FindBy(xpath = "//input[@id='from_date' and @type='text' and @name='filter_date_end']")
	WebElement date_end_box;

	@FindBy(xpath = "//a[@class='button' and text()='Report Generate']")
	WebElement Report_Generate_button;

	@FindBy(xpath = ".//*[@id='date-start']")
	WebElement date_start;

	@FindBy(xpath = ".//*[@id='date-end']")
	WebElement date_end;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[1]/span")
	WebElement date_start_calender_back_month;
	
	@FindBy(xpath = "//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_calender_back_month_1st_date;

	@FindBy(xpath = "//div[@id='success' and text()='Report Generated Successfully!']")
	WebElement msg_report_generated_sucessfully;

	@FindBy(xpath = "(.//*[@id='form']/table/tbody/tr[1]/td[2])[2]")
	WebElement Date_of_Generation_first_option;

	@FindBy(xpath = "(.//*[@id='form']/table/tbody/tr[1]/td[1])[2]")
	WebElement Report_Name_first_option;

	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[3]/a")
	WebElement download_first_option;

	@FindBy(xpath = ".//*[@id='error_generated']")
	WebElement msg_error;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[6]/a")
	WebElement date_start_box_first_date;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[6]/a")
	WebElement date_end_box_first_date;

	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_start_box_next_month;

	@FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_end_box_next_month;

	@FindBy(xpath = ".//*[@id='year_date']")
	WebElement date_year;
	
	@FindBy(xpath = "//a[@class='top' and text()='Commands']")
	WebElement commands;
	
	@FindBy(xpath = "//a[@class='parent' and text()='EMM Commands']")
	WebElement EMM_commands;
	
	@FindBy(partialLinkText="Product Subscription")
	WebElement EMM_commands_product_subscription;
	
	@FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[2]")   //commands>EMM Commands >STB Activation
	 WebElement copy_first_customer_STB_NO_EMM_Product_subscription;
	
	 @FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[3]")
	 WebElement copy_first_product_name_EMM_Product_subscription;
	
	 @FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[5]")
	 WebElement copy_first_trigger_on_time_EMM_Product_subscription_;
	
	 @FindBy (xpath=".//*[@id='form']/table/tbody/tr/td[6]")
	 WebElement copy_first_expiry_time_EMM_Product_subscription;
 
	 @FindBy(xpath = ".//*[@id='catalog']/a")
	 WebElement catalog;
	 
	 @FindBy(partialLinkText = "Channels")
	 WebElement catalog_Channels;
	 
	 @FindBy(xpath = ".//*[@id='form']/table/tbody/tr[2]/td[9]/a")
	 WebElement catalog_Channels_first_Edit;
	 
	 @FindBy(xpath = "//input[@type='channel_name_none' and @name='broadcaster_channel_name']")
	 WebElement catalog_Channels_channel_name;
	 
	 @FindBy(xpath = "//a[@class='button' and text()='Submit']")
	 WebElement Catalog_channel_submit_button;

	ExcelReader read = new ExcelReader();

	private void click_on_catalog_channels_and_edit_button(){
		catalog.click();
		catalog_Channels.click();
		catalog_Channels_first_Edit.click();
		catalog_Channels_channel_name.clear();
	}
	
	private void click_on_Commands_product_subscription(){
		commands.click();
		EMM_commands.click();
		EMM_commands_product_subscription.click();
	}
	
	private void click_on_reports_historical_Product_Subscription_method() {
		reports.click();
		Historical.click();
		Product_Subscription.click();

	}
	
    public static PDDocument PDF_Data_Reader() throws Throwable{
		
		PDDocument pdDoc;
		//String value = Read_PDF_name();
		pdDoc = PDDocument.load( new File("D:\\Unzip\\productsubscription_1.pdf"));
		//System.out.println(pdDoc.getNumberOfPages());
		return pdDoc;
    }
	
	public void verify_element_method(WebDriver driver) {
		this.click_on_reports_historical_Product_Subscription_method();
		
		Historical_Product_Subscription_link.click();
		assertTrue(driver.getTitle().matches("Product Subscription"));
		
		assertTrue(Historical_Product_Subscription_link.getText().trim()
				.matches("Product Subscription"));
		assertTrue(date_start.getText().substring(1, 5).matches("From"));
		assertTrue(date_end.getText().substring(1, 4).matches("To:"));
		assertTrue(Report_Generate_button.getText().trim()
				.matches("Report Generate"));
		assertTrue(driver.getTitle().matches("Product Subscription"));
		assertTrue(driver
				.findElement(By.xpath(".//*[text()='Report History']"))
				.getText().matches("REPORT HISTORY"));
		assertTrue(driver
				.findElement(
						By.xpath(".//*[@class='left' and text()='Report Name']"))
				.getText().matches("Report Name"));
		assertTrue(driver
				.findElement(
						By.xpath(".//*[@class='left' and text()='Date of Generation']"))
				.getText().matches("Date of Generation"));
		assertTrue(driver
				.findElement(
						By.xpath(".//*[@class='center' and text()='Download Link']"))
				.getText().matches("Download Link"));

		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Monthly");
		sel.selectByVisibleText("Yearly");
		
		Home_link.click();
		assertTrue(driver.getTitle().matches("Dashboard"));	

	}
	@FindBy(xpath="//input[@id='month_date' and @name='month']")
	WebElement month_sel;
	
	
	public void Validation_Generate_button_method(WebDriver driver) {
		this.click_on_reports_historical_Product_Subscription_method();
		try {
			GetReportFilePath.DeleteFolderfiles();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Delete Old files
		Select selll = new Select(from_to_monthly_yearly_option);
		selll.selectByVisibleText("Monthly");
		month_sel.click();
		String dateee = GetReportFilePath.current_month();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//td[@class='ui-state-default mtz-monthpicker mtz-monthpicker-month' and text()='"+dateee+"']")).click();

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		
		
		
		
		
		
		
		this.click_on_reports_historical_Product_Subscription_method();
		date_start_box.click();
		date_start_calender_back_month.click();
		date_start_calender_back_month_1st_date.click();
		date_end_box.click();
		date_end_box.sendKeys(Keys.ENTER);
		Report_Generate_button.click();
		assertTrue(msg_report_generated_sucessfully.getText().matches(
				"Report Generated Successfully!"));

		String str3 = String.valueOf(Report_Name_first_option.getText()
				.subSequence(0, 20));
		String value = GetReportFilePath.date_time_stamp();
		assertTrue(str3.matches("Hist_Prod_" + value));
		System.out.println(value);

		String str4 = String.valueOf(Date_of_Generation_first_option.getText()
				.subSequence(0, 10));
		assertTrue(str4.matches(GetReportFilePath.date_time_stamp()));

		assertTrue(download_first_option.getText().matches("Download"));

	}
	public void invalid_test_cases_method(WebDriver driver) {
		this.click_on_reports_historical_Product_Subscription_method();
		Report_Generate_button.click();
		assertTrue(msg_error.getText().matches(
				"Warning : Invalid date specified!"));

		date_start_box.click();
		date_start_box.sendKeys(Keys.ENTER);
		date_end_box.click();
		driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w' and text()='Prev']")).click();
		driver.findElement(By.xpath("//a[@class='ui-state-default' and text()='1']")).click();
		Report_Generate_button.click();
		assertTrue(msg_error.getText().matches("Warning : To date is greater than From date!"));

//		date_start_box.click();
//		for(int i=0;i<16;i++){
//		date_start_box_next_month.click();
//		}
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		date_start_box_first_date.click();
//		date_end_box.click();
//		for(int i=0;i<17;i++){
//		date_end_box_next_month.click();
//		}
//		date_end_box_first_date.click();
//		Report_Generate_button.click();                                            //Bug in version 3.10 
//		assertTrue(msg_sucess.getText().matches("No Records in this duration!"));  // Showing Wrong Error

		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Monthly");
		Report_Generate_button.click();
		assertTrue(msg_error.getText().matches("Warning : Please select month!"));

		//sel.selectByVisibleText("Monthly");
		// System.out.println(month_verify());
		// this.getMonthForInt(11);

		sel.selectByVisibleText("Yearly");
		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches("No Records in this duration!"));

		Select sell = new Select(from_to_monthly_yearly_option);
		sell.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText("2019");
		Report_Generate_button.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(msg_sucess.getText().matches("No Records in this duration!"));

	}

	public void Validation_method(WebDriver driver) throws Throwable {
		this.click_on_reports_historical_Product_Subscription_method();
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files
		// date_start_box.click();
		// date_start_calender_back_month.click();
		// date_start_box_first_date.click();
		// date_end_box.click();
		// date_end_box.sendKeys(Keys.ENTER);

		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches(
				"Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		Robot object = new Robot();
//		object.keyPress(KeyEvent.VK_DOWN);
//		object.keyRelease(KeyEvent.VK_DOWN);
//		Thread.sleep(2000);
//		object.keyPress(KeyEvent.VK_ENTER);
//		object.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);

		GetReportFilePath.FileNameReadUnzip();
		GetReportFilePath.FileNameRead();

		String value = GetReportFilePath.Read_PDF_name();
		System.out.println(value);
	//	Assert.assertEquals(value, "productsubscription_1.pdf");
		
		
		PDFTextStripper g = new PDFTextStripper();
		String str1 = read.getsheetnumber(45, 0, 0);
		//System.out.println(g.getText(PDF_Data_Reader()));
		assertTrue(g.getText(PDF_Data_Reader()).contains(str1));  //Sl No. 
		
		String str2 = read.getsheetnumber(45, 0, 1);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str2));   // A-la-carte Name
				
		String str4 = read.getsheetnumber(45, 0, 2);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str4));  //Prod.No
		
		String str5 = read.getsheetnumber(45, 0, 3);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str5));   //STB No
		
		String str6 = read.getsheetnumber(45, 0, 4);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str6));    //Triggered On
		
		String str7 = read.getsheetnumber(45, 0, 5);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str7));    //Expiry Date
		
		String str8 = read.getsheetnumber(45, 0, 6);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str8));    //Operator
		
		String str9 = read.getsheetnumber(45, 0, 7);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str9));    //Historical A-ca-carte Subscription
		
		String str10 = String.valueOf(read.getsheetnumber(45, 0, 8));
	//	assertTrue(g.getText(PDF_Data_Reader()).contains(str10));   //Company Email ID and Full Address 
		
		
//-----------------------------------------------------------------This Code is applicable only for fresh database------------------------------------------------------------------------------------------------
				
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		this.click_on_Commands_product_subscription();
//				
//		String str11 = copy_first_customer_STB_NO_EMM_Product_subscription.getText().trim();         //first STB No.
//		String str12 = copy_first_product_name_EMM_Product_subscription.getText().trim();            // First Product name
//		String str13 = copy_first_trigger_on_time_EMM_Product_subscription_.getText().trim();        // First Product Activation Time
//		//String str14 = copy_first_expiry_time_EMM_Product_subscription.getText().trim();             // First Product DeActivation Time
//				
//     	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		assertTrue(g.getText(PDF_Data_Reader()).contains(str11));           // First STB No. search in PDF
//				
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		assertTrue(g.getText(PDF_Data_Reader()).contains(str12));           // First Product name search in PDF
//		
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		assertTrue(g.getText(PDF_Data_Reader()).contains(str13));           // First Product Activation Time search in PDF
//		
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		//assertTrue(g.getText(PDF_Data_Reader()).contains(str14));           // First Product DeActivation Time search in PDF
//			
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   
//		assertTrue(g.getText(PDF_Data_Reader()).contains(GetReportFilePath.current_date()));	// Find current date in PDF	
		
//---------------------------------------------------------------------------------End here----------------------------------------------------------------------------------------------------------------------------
	}
	
	public void change_customer_name_check_in_PDF_method(WebDriver driver) throws Throwable{
		GetReportFilePath.DeleteFolderfiles(); // Delete Old files
		this.click_on_catalog_channels_and_edit_button();
		String copy_random_number=BaseClass.givenUsingApache_whenGeneratingRandomStringBounded_thenCorrect();
		System.out.println(copy_random_number);
		String copy_new_product_name = read.getsheetnumber(45, 1, 0);
		catalog_Channels_channel_name.sendKeys(copy_random_number);
		Thread.sleep(1000);
		Catalog_channel_submit_button.click();
		Thread.sleep(6000);
		assertTrue(driver.findElement(By.xpath(".//*[@id='content']/div[2]")).getText().trim().matches("Product updated successfully!"));
		
		this.click_on_reports_historical_Product_Subscription_method();
		
		Select sel = new Select(from_to_monthly_yearly_option);
		sel.selectByVisibleText("Yearly");
		Select selec = new Select(date_year);
		selec.selectByVisibleText(GetReportFilePath.current_year());
		System.out.println(GetReportFilePath.current_year());

		Report_Generate_button.click();
		assertTrue(msg_sucess.getText().matches("Report Generated Successfully!"));
		download_first_option.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		Robot object = new Robot();
////		object.keyPress(KeyEvent.VK_DOWN);
////		object.keyRelease(KeyEvent.VK_DOWN);
//		Thread.sleep(2000);
//		object.keyPress(KeyEvent.VK_ENTER);
//		object.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);

		GetReportFilePath.FileNameReadUnzip();
		GetReportFilePath.FileNameRead();
		
		String value = GetReportFilePath.Read_PDF_name();
		System.out.println(value);
		Assert.assertEquals(value, "productsubscription_1.pdf");
				
		PDFTextStripper g = new PDFTextStripper();
			
     	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     	assertTrue(g.getText(PDF_Data_Reader()).contains(copy_random_number));   //Check edited product name 
			
				
	}
	
}
