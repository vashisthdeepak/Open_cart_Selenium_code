package com.reports_list;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class STB_Deactivation extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="List")
	WebElement list;
	
	@FindBy(xpath=".//*[@id=' ']/ul/li[7]/ul/a[2]")
	WebElement STB_deactivation;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement STB_deactivation_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='center' and text()='Customer No']")
	WebElement subheading_Customer_No;
	
	@FindBy(xpath="//td[@class='center' and text()='Customer Name']")
	WebElement subheading_Customer_Name;
	
	@FindBy(xpath="//td[@class='center' and text()='STB No']")
	WebElement subheading_STB_No;
	
	@FindBy(xpath="//td[@class='center' and text()='De-Activation Date']")
	WebElement subheading_deactivation_Date;
		
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_STB_deactivation;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(id="selectoption")
	WebElement selectoption_from_to;
	
	@FindBy(xpath=".//*[@id='from_date']")
	WebElement from_date_start_box;
	
	@FindBy(xpath=".//*[@id='month_date']")
	WebElement month_start_box;
	
	@FindBy(xpath="//select[@class='mtz-monthpicker mtz-monthpicker-year']")
	WebElement month_start_box_year_picker;
	
	@FindBy(xpath="//select[@name='filter_operator']")
	WebElement filter_operator;
	
	@FindBy(partialLinkText="Filter")
	WebElement Filter_button;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr/td[2]")
	WebElement details_customer_no;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[3]")
	WebElement details_customer_name;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr/td[4]")
	WebElement details_STB_no;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr/td[5]")
	WebElement details_deactivation_date;
	
	@FindBy(xpath="//td[@class='ui-state-default mtz-monthpicker mtz-monthpicker-month' and text()='Jan']")
	WebElement select_jan;
	
	@FindBy(xpath="//*[@class='ui-icon ui-icon-circle-triangle-w']")
	WebElement date_start_prew_month;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[1]")
	WebElement date_end_pre_month;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_start_next_month;
	
	@FindBy(xpath="//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_first_date;
	
	@FindBy(xpath="//select[@class='mtz-monthpicker mtz-monthpicker-year']")
	WebElement date_start_Year_option;
		
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	private void click_on_list_STB_deactivation(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(list);
		act.click(STB_deactivation).build().perform();
	}
	
	public void Verify_element_method(){
		this.click_on_list_STB_deactivation();
		
		assertEquals(driver.getTitle(), "STB DeActive List");
		Home_link.isDisplayed();
		STB_deactivation_link.isDisplayed();
		subheading_deactivation_Date.isDisplayed();
		subheading_Customer_Name.isDisplayed();
		subheading_Customer_No.isDisplayed();
		subheading_STB_No.isDisplayed();
		heading_STB_deactivation.isDisplayed();
		print_button.isDisplayed();
		filter_operator.isDisplayed();
		new Select(filter_operator).selectByVisibleText("ALL");
		new Select(filter_operator).selectByVisibleText("admin");
		STB_deactivation_link.click();
		Filter_button.isDisplayed();
		selectoption_from_to.isDisplayed();
		new Select(selectoption_from_to).selectByVisibleText("Monthly");
		new Select(selectoption_from_to).selectByVisibleText("On-Date");
		assertEquals(driver.getTitle(), "STB DeActive List");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	public void valid_method(){		
		
		this.click_on_list_STB_deactivation();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("On-Date");
	    from_date_start_box.click();
	    from_date_start_box.sendKeys(Keys.ENTER);
	    Filter_button.click();
	    details_customer_no.isDisplayed();
	    details_customer_name.isDisplayed();
	    details_deactivation_date.isDisplayed();
	    details_STB_no.isDisplayed();
	    System.out.println(details_customer_no.getText().trim() + details_customer_name.getText() + details_deactivation_date.getText() + details_STB_no.getText());
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");  			//get data by date
	    
	    STB_deactivation_link.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("Monthly");
		month_start_box.click();
		String str = GetReportFilePath.current_month();
		String str1 = "//td[text()='";
		String str2 = str+"']";
		String str3 = str1+str2;
		driver.findElement(By.xpath(str3)).click();
	    Filter_button.click();
	    details_customer_no.isDisplayed();
	    details_customer_name.isDisplayed();
	    details_deactivation_date.isDisplayed();
	    details_STB_no.isDisplayed();
	    System.out.println(details_customer_no.getText().trim() + details_customer_name.getText() + details_deactivation_date.getText() + details_STB_no.getText());
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");  			//get data by Month
	    
	    STB_deactivation_link.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("Monthly");
		month_start_box.click();
		new Select(month_start_box_year_picker).selectByVisibleText("2012");
		month_start_box.click();
		driver.findElement(By.xpath(str3)).click();
	    Filter_button.click();
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");          //Check for previous months
	   
	}

	public void invalid_method(){
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		this.click_on_list_STB_deactivation();
		
		STB_deactivation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("On-Date");
	    Filter_button.click();
	    assertEquals(msg_error.getText(), "Warning : On date required!");
	    System.out.println(msg_error.getText());                              //Filter without date
  
	    STB_deactivation_link.click();
	    print_button.click();
	    assertEquals(msg_error.getText(), "Warning : Please filter records before printing!");
	    System.out.println(msg_error.getText());   
	    
  
	}
}