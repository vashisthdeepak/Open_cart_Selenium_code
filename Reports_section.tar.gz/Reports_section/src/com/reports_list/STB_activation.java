package com.reports_list;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class STB_activation extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="List")
	WebElement list;
	
	@FindBy(xpath=".//*[@id=' ']/ul/li[7]/ul/a[1]")
	WebElement STB_activation;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement STB_activation_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='center' and text()='Customer No']")
	WebElement subheading_Customer_No;
	
	@FindBy(xpath="//td[@class='center' and text()='Customer Name']")
	WebElement subheading_Customer_Name;
	
	@FindBy(xpath="//td[@class='center' and text()='STB No']")
	WebElement subheading_STB_No;
	
	@FindBy(xpath="//td[@class='center' and text()='Activation Date']")
	WebElement subheading_Activation_Date;
	
	@FindBy(xpath="//td[@class='center' and text()='Expiry Date']")
	WebElement subheading_Expiry_Date;
	
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_STB_activation;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(id="selectoption")
	WebElement selectoption_from_to;
	
	@FindBy(xpath=".//*[@id='month_date']")
	WebElement from_date_start_box;
	
	@FindBy(id="date-start")
	WebElement date_start_option;
	
	@FindBy(id="date-end")
	WebElement date_end_option;
	
	@FindBy(id="from_date")
	WebElement date_end_box;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_end_next_month;
	
	@FindBy(xpath="//select[@name='filter_operator']")
	WebElement filter_operator;
	
	@FindBy(partialLinkText="Filter")
	WebElement Filter_button;
	
	@FindBy(id="year_date")
	WebElement select_year;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr/td[2]")
	WebElement details_customer_no;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[3]")
	WebElement details_customer_name;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[4]")
	WebElement details_STB_no;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[5]")
	WebElement details_activation_date;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[6]")
	WebElement details_expiry_date;
	
	@FindBy(xpath="//td[@class='ui-state-default mtz-monthpicker mtz-monthpicker-month' and text()='Jan']")
	WebElement select_jan;
	
	@FindBy(xpath="//*[@class='ui-icon ui-icon-circle-triangle-w']")
	WebElement date_start_prew_month;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[1]")
	WebElement date_end_pre_month;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[2]/span")
	WebElement date_start_next_month;
	
	@FindBy(xpath="//a[@class='ui-state-default' and text()='1']")
	WebElement date_start_first_date;
	
	@FindBy(xpath="//select[@class='mtz-monthpicker mtz-monthpicker-year']")
	WebElement date_start_Year_option;
		
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	private void click_on_list_STB_activation(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(list);
		act.click(STB_activation).build().perform();
	}
	
	public void Verify_element_method(){
		this.click_on_list_STB_activation();
		
		assertEquals(driver.getTitle(), "STB Active List");
		Home_link.isDisplayed();
		STB_activation_link.isDisplayed();
		subheading_Activation_Date.isDisplayed();
		subheading_Customer_Name.isDisplayed();
		subheading_Customer_No.isDisplayed();
		subheading_Expiry_Date.isDisplayed();
		subheading_STB_No.isDisplayed();
		heading_STB_activation.isDisplayed();
		print_button.isDisplayed();
		filter_operator.isDisplayed();
		new Select(filter_operator).selectByVisibleText("ALL");
		new Select(filter_operator).selectByVisibleText("admin");
		STB_activation_link.click();
		Filter_button.isDisplayed();
		selectoption_from_to.isDisplayed();
		new Select(selectoption_from_to).selectByVisibleText("Monthly");
		new Select(selectoption_from_to).selectByVisibleText("Yearly");
		assertEquals(driver.getTitle(), "STB Active List");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	public void valid_method(){		
		
		this.click_on_list_STB_activation();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    for(int i=0;i<10;i++){
	    	date_start_prew_month.click(); 
	     }
	    date_start_first_date.click();
	    date_end_box.click();
	    date_end_box.sendKeys(Keys.ENTER);
	    Filter_button.click();
	    details_customer_no.isDisplayed();
	    details_customer_name.isDisplayed();
	    details_STB_no.isDisplayed();
	    details_activation_date.isDisplayed();
	    details_expiry_date.isDisplayed();
	    //System.out.println(details_product_no.getText().trim()+details_product_name.getText()+details_Subscription_Count.getText());
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");  			//get data by date
	    
	    this.click_on_list_STB_activation();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    for(int i=0;i<135;i++){                                              //value of 'i' can be change according to expiry date 
	    	date_start_next_month.click(); 
	     }
	    date_start_first_date.click();
	    date_end_box.click();
	    for(int i=0;i<136;i++){                                               //value of 'i' can be change according to expiry date
	    date_end_next_month.click();
	    }
	    date_start_first_date.click();
	    Filter_button.click();
	   assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");  			//Future date no result    
        	    
	    STB_activation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Monthly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    from_date_start_box.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    String value = GetReportFilePath.current_month();
	    System.out.println("Current month : "+value);
	    String str = "//td[text()='"+value+"']";
	    driver.findElement(By.xpath(str)).click();
	   	Filter_button.click();
	   	details_customer_no.isDisplayed();
	    details_customer_name.isDisplayed();
	   	details_STB_no.isDisplayed();
	    details_activation_date.isDisplayed();
	    details_expiry_date.isDisplayed();     //valid month data
	    
	    
	    STB_activation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Yearly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    String year = GetReportFilePath.current_year();
	    select_year.click();
	    new Select(select_year).selectByVisibleText(year);
	   	Filter_button.click();
	   	details_customer_no.isDisplayed();
	    details_customer_name.isDisplayed();
	   	details_STB_no.isDisplayed();
	    details_activation_date.isDisplayed();
	    details_expiry_date.isDisplayed();  
	    assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");     //valid Year data
	    
	   
	}

	public void invalid_method(){
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		this.click_on_list_STB_activation();
		
		STB_activation_link.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    date_start_next_month.click();
	    date_start_first_date.click();
	    date_end_box.click();
	    date_end_box.sendKeys(Keys.ENTER);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    Filter_button.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    System.out.println(msg_error.getText().trim());
	    assertEquals(msg_error.getText(), "Warning : From date is greater than To date!");      //invalid date
	    
	    
	    STB_activation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Monthly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    from_date_start_box.click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    date_start_Year_option.click();
	    new Select(date_start_Year_option).selectByVisibleText("2012");
	    select_jan.click();
	   	Filter_button.click();                                                                
	   	assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");                 //Invalid month
	   	
	   	STB_activation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Yearly");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    select_year.click();
	    new Select(select_year).selectByVisibleText("2016");
	    Filter_button.click();
	   	assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");     //Invalid Year data
	   	
	   	
	   	STB_activation_link.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(selectoption_from_to).selectByVisibleText("From-To");
	    driver.findElement(By.xpath(".//*[@id='to_date']")).click();
	    for(int i=0;i<30;i++){
	    	date_start_prew_month.click(); 
	     }
	    date_start_first_date.click();
	    date_end_box.click();
	    for(int i=0;i<30;i++){
	    	date_end_pre_month.click(); 
	     }
	    date_start_first_date.click();
	    Filter_button.click();
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");	     //invalid date
	   	    
		STB_activation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("From-To");
	    Filter_button.click();
	    assertEquals(msg_error.getText(), "Warning : From date required!");
	    System.out.println(msg_error.getText());                              //Filter without date
	    	    
	    STB_activation_link.click();
	    new Select(selectoption_from_to).selectByVisibleText("Monthly");
	    Filter_button.click();
	    assertEquals(msg_error.getText(), "Warning : Please select month!");
	    System.out.println(msg_error.getText());                              //Filter without Month
	    
//	    STB_activation_link.click();
//	    new Select(selectoption_from_to).selectByVisibleText("Yearly");
//	    Filter_button.click();
//	    assertEquals(msg_error.getText(), "Warning : Please select year!");
//	    System.out.println(msg_error.getText());    						 //Filter without year -------------Bug in SMS
	    
	    STB_activation_link.click();
	    print_button.click();
	    assertEquals(msg_error.getText(), "Warning : Please filter records before printing!");
	    System.out.println(msg_error.getText());   
	    
  
	}
}