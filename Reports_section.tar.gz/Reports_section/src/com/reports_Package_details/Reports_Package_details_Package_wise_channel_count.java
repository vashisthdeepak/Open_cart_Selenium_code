package com.reports_Package_details;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.baseclass.BaseClass;

public class Reports_Package_details_Package_wise_channel_count extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(xpath="//a[@class='parent' and text()='Package Details']")
	WebElement Package_Details;
	
	@FindBy(xpath=".//*[@id=' ']/ul/li[9]/ul/a[2]")
	WebElement Package_wise_channel_count;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Package_wise_channel_count_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='center' and text()='Package No.']")
	WebElement subheading_Package_No;
	
	@FindBy(xpath="//td[@class='center' and text()='Package Name']")
	WebElement subheading_Package_Name;
	
	@FindBy(xpath="//td[@class='center' and text()='Channel Count']")
	WebElement subheading_Channel_count;
			
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Package_wise_channel_count;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
		
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[1]")
	WebElement details_package_no;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[2]")
	WebElement details_package_name;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[3]")
	WebElement details_channel_count;
	
	
private void click_on_Package_details_Package_wise_channel_count(){
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		reports.click();
    	wait.until(ExpectedConditions.elementToBeClickable(Package_Details)).click();
		wait.until(ExpectedConditions.elementToBeClickable(Package_wise_channel_count)).click();
	}
	
	public void Verify_element_method(){
		this.click_on_Package_details_Package_wise_channel_count();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		assertEquals(driver.getTitle(), "Package Wise Channel Count");
		Home_link.isDisplayed();
		Package_wise_channel_count_link.isDisplayed();
		subheading_Channel_count.isDisplayed();
		subheading_Package_Name.isDisplayed();
		subheading_Package_No.isDisplayed();
		print_button.isDisplayed();
		Package_wise_channel_count_link.click();
		assertEquals(driver.getTitle(), "Package Wise Channel Count");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		this.click_on_Package_details_Package_wise_channel_count();
	    details_channel_count.isDisplayed();
		details_package_name.isDisplayed();
		details_package_no.isDisplayed();
		System.out.println(details_channel_count.getText() + details_package_name.getText() + details_package_no.getText());
				
	}
		
}
