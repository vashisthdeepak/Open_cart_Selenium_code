package com.reports_Package_details;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.baseclass.BaseClass;

public class Reports_Alacarte_details extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(xpath=".//*[@id=' ']/ul/li[10]/a")
	WebElement Alacarte_Details;
			
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Alacarte_Details_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Product Id']")
	WebElement subheading_Product_ID;
	
	@FindBy(xpath="//td[@class='left' and text()='Channel No.']")
	WebElement subheading_Channel_No;
	
	@FindBy(xpath="//td[@class='left' and text()='Channel Name']")
	WebElement subheading_Channel_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Broadcaster']")
	WebElement subheading_BroadCaster;
		
	@FindBy(xpath="//td[@class='left' and text()='Service Id']")
	WebElement subheading_Service_Id;
	
	@FindBy(xpath="//td[@class='left' and text()='Access Criteria']")
	WebElement subheading_Access_Criteria;
	
	@FindBy(xpath="//td[@class='left' and text()='LCN']")
	WebElement subheading_LCN;
	
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Alacarte_Details;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement Filter_Search;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[2]")
	WebElement details_Product_ID;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[4]")
	WebElement details_channel_name;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[3]")
	WebElement details_Channel_No;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[5]")
	WebElement details_broadcaster;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[6]")
	WebElement details_Service_Id;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[7]")
	WebElement details_Access_Criteria;
	
	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[8]")
	WebElement details_LCN;
	
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
	@FindBy(xpath="(//td[@class='left'])[9]")
	WebElement first_option_channel_no;
	
	@FindBy(xpath=".//*[@id='scriptBox']")
	WebElement channel_no_search_box;

	
private void click_on_Alacarte_details(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
//     wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText("A-la-carte Details"))).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Alacarte_Details)).click();
	
	}
	
	public void Verify_element_method(){
		this.click_on_Alacarte_details();
		
		assertEquals(driver.getTitle(), "A-la-carte details");
		Home_link.isDisplayed();
		Alacarte_Details_link.isDisplayed();
		subheading_BroadCaster.isDisplayed();
		subheading_Channel_Name.isDisplayed();
		subheading_Access_Criteria.isDisplayed();
		subheading_Channel_No.isDisplayed();
		subheading_LCN.isDisplayed();
		subheading_Service_Id.isDisplayed();
		subheading_Product_ID.isDisplayed();
		print_button.isDisplayed();
		Filter_Search.isDisplayed();
		Alacarte_Details_link.click();
		assertEquals(driver.getTitle(), "A-la-carte details");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		this.click_on_Alacarte_details();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String str1 = first_option_channel_no.getText();
		channel_no_search_box.sendKeys(str1);
		Filter_Search.click();
		details_Access_Criteria.isDisplayed();
		details_broadcaster.isDisplayed();
		details_channel_name.isDisplayed();
		details_Channel_No.isDisplayed();
		details_LCN.isDisplayed();
		details_Product_ID.isDisplayed();
		details_Service_Id.isDisplayed();
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");        //Search Valid 
		
	}
	
	public void Invalid_methos(){
		this.click_on_Alacarte_details();
	   
		channel_no_search_box.sendKeys("999999");
		Filter_Search.click();
		details_no_results.isDisplayed();                              //Invalid Channel number
		
		channel_no_search_box.sendKeys("99asdfsrf");
		Filter_Search.click();
		details_no_results.isDisplayed();                             //Invalid Character
		
		Alacarte_Details_link.click();
		Filter_Search.click();
		System.out.println(driver.switchTo().alert().getText());
		assertEquals("Please Insert the channel no.!", driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
								
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
