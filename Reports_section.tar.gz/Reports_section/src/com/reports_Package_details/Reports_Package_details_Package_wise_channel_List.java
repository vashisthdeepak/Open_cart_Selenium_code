package com.reports_Package_details;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import test.baseclass.BaseClass;

public class Reports_Package_details_Package_wise_channel_List extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Package Details")
	WebElement Package_Details;
	
	@FindBy(xpath=".//*[@id=' ']/ul/li[9]/ul/a[1]")
	WebElement Package_wise_channel_List;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Package_wise_channel_List_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Product No.']")
	WebElement subheading_Product_No;
	
	@FindBy(xpath="//td[@class='left' and text()='Channel Name']")
	WebElement subheading_Channel_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Free']")
	WebElement subheading_Free;
	
	@FindBy(xpath="//td[@class='left' and text()='BroadCaster']")
	WebElement subheading_BroadCaster;
		
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Package_wise_channel_List;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(xpath="//select[@name='filter_broadcaster']")
	WebElement filter_broadcaster;
	
	@FindBy(partialLinkText="Filter")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath=".//*[@id='filter_package']")
	WebElement select_package;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[2]")
	WebElement details_product_no;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[3]")
	WebElement details_channel_name;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[4]")
	WebElement details_free;
	
	@FindBy(xpath=".//*[@id='form']/table[2]/tbody/tr[1]/td[5]")
	WebElement details_broadcaster;
	
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
private void click_on_Package_details_Package_wise_channel_List(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(Package_Details);
		act.click(Package_wise_channel_List).build().perform();
	}
	
	public void Verify_element_method(){
		this.click_on_Package_details_Package_wise_channel_List();
		
		assertEquals(driver.getTitle(), "Package Wise Channel Details");
		Home_link.isDisplayed();
		Package_wise_channel_List_link.isDisplayed();
		subheading_BroadCaster.isDisplayed();
		subheading_Channel_Name.isDisplayed();
		subheading_Free.isDisplayed();
		subheading_Product_No.isDisplayed();
		print_button.isDisplayed();
		filter_broadcaster.isDisplayed();
		new Select(filter_broadcaster).selectByVisibleText("ALL");
		new Select(filter_broadcaster).selectByVisibleText("No Broadcaster");
		Package_wise_channel_List_link.click();
		Filter_button.isDisplayed();
		select_package.isDisplayed();
		new Select(select_package).selectByValue("1302");
		new Select(select_package).selectByValue("1303");
		assertEquals(driver.getTitle(), "Package Wise Channel Details");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		this.click_on_Package_details_Package_wise_channel_List();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new Select(select_package).selectByValue("1302");
		Filter_button.click();
		
		String str1 = details_free.getText().trim();
//		if(str1.equals("Paid") || str1.equals("Free")){
	    assertTrue(str1.equals("Paid") || str1.equals("Free"));
	    //assertTrue(true, ("Free" || "Paid"));
	    details_free.isDisplayed();
		details_product_no.isDisplayed();
		details_broadcaster.isDisplayed();
		details_channel_name.isDisplayed();
		System.out.println(details_broadcaster.getText() + details_channel_name.getText() + details_free.getText() + details_product_no.getText());
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");
	
		
	
	
	
	}
	
	public void Invalid_methos(){
		this.click_on_Package_details_Package_wise_channel_List();
	    Filter_button.click();
	    assertEquals("No results!", details_no_results.getText());
	    
		Package_wise_channel_List_link.click();
        print_button.click();
        assertEquals("Warning : Please select atleast one to process!",msg_error.getText());
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
