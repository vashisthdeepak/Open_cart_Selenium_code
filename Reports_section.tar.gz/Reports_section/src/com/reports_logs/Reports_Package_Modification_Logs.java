package com.reports_logs;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import test.baseclass.BaseClass;

public class Reports_Package_Modification_Logs extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(xpath="//a[@class='parent' and text()='Logs']")
	WebElement Logs;
	
	@FindBy(xpath="(//a[text()='Package Modification Logs'])[1]")
	WebElement Package_Modification_Logs;
			
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Package_Modification_Logs_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='PACKAGE NAME']")
	WebElement subheading_PACKAGE_NAME;
	
	@FindBy(xpath="//td[@class='left' and text()='PACKAGE NUMBER']")
	WebElement subheading_PACKAGE_NUMBER;
	
	@FindBy(xpath="//td[@class='left' and text()='ACTION']")
	WebElement subheading_ACTION;
		
	@FindBy(xpath="//td[@class='left' and text()='FROM DATE']")
	WebElement subheading_FROM_DATE;
	
	@FindBy(xpath="//td[@class='left' and text()='TO DATE']")
	WebElement subheading_TO_DATE;
					
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Package_Modification_Logs;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[6]")
	WebElement details_PACKAGE_NAME;
	
	@FindBy(xpath="(//td[@class='left'])[7]")
	WebElement details_PACKAGE_NUMBER;
	
	@FindBy(xpath="(//td[@class='left'])[8]")
	WebElement details_ACTION;
	
	@FindBy(xpath="(//td[@class='left'])[9]")
	WebElement details_FROM_DATE;
	
	@FindBy(xpath="(//td[@class='left'])[10]")
	WebElement details_TO_DATE;
					
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
    @FindBy(xpath="//input[@id='scriptBox' and @name='filter_value']")
    WebElement target_box;
    
    @FindBy(xpath=".//*[@id='filter_command' and @name='filter_command']")
    WebElement command_select_option;
	
    @FindBy(xpath="//input[@id='date' and @name='filter_date_added']")
    WebElement date_time_option;
    
    @FindBy(xpath="//td[text()='Jan']")
    WebElement jan_month;

    
    private void click_on_Package_Modification_Logs(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(Logs)).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Package_Modification_Logs)).click();
	}
	
	public void Verify_element_method(){
		this.click_on_Package_Modification_Logs();
		
		assertEquals(driver.getTitle(), "Package Modification Logs");
		Home_link.isDisplayed();
		Package_Modification_Logs_link.isDisplayed();
		subheading_ACTION.isDisplayed();
		subheading_FROM_DATE.isDisplayed();
		subheading_PACKAGE_NAME.isDisplayed();
		subheading_PACKAGE_NUMBER.isDisplayed();
		subheading_TO_DATE.isDisplayed();
		heading_Package_Modification_Logs.isDisplayed();
		Package_Modification_Logs_link.isDisplayed();
		Filter_button.isDisplayed();		
		print_button.isDisplayed();
		details_ACTION.isDisplayed();
		details_FROM_DATE.isDisplayed();
		details_PACKAGE_NAME.isDisplayed();
		details_PACKAGE_NUMBER.isDisplayed();
		details_TO_DATE.isDisplayed();
		
		Package_Modification_Logs_link.click();
		assertEquals(driver.getTitle(), "Package Modification Logs");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
			 
	public void Invalid_method(){	
		this.click_on_Package_Modification_Logs();
		Filter_button.click();
		assertEquals("Warning : Please select Option (Package Name ) !",msg_error.getText());
		
		Package_Modification_Logs_link.click();
		print_button.click();
		assertEquals("Warning : Please select atleast one to process!",msg_error.getText());
				
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}