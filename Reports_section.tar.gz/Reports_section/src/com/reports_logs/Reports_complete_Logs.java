package com.reports_logs;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.baseclass.BaseClass;

public class Reports_complete_Logs extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Logs")
	WebElement Logs;
	
	@FindBy(xpath="(//a[text()='Complete Logs'])[1]")
	WebElement Complete_Logs;
			
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Complete_Logs_link;
	
	@FindBy(xpath = "//div[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Target']")
	WebElement subheading_Target;
	
	@FindBy(xpath="//td[@class='left' and text()='Command']")
	WebElement subheading_Command;
	
	@FindBy(xpath="//td[@class='left' and text()='Target Level']")
	WebElement subheading_Target_Level;
		
	@FindBy(xpath="//td[@class='left' and text()='Date Time']")
	WebElement subheading_Date_Time;
	
	@FindBy(xpath="//td[@class='left' and text()='Status']")
	WebElement subheading_Status;
	
	@FindBy(xpath="//td[@class='left' and text()='Resend']")
	WebElement subheading_Resend;
	
	@FindBy(xpath="//td[@class='left' and text()='Target No.']")
	WebElement subheading_Target_No;
			
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Complete_Logs;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement Search_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[8]")
	WebElement details_Target;
	
	@FindBy(xpath="(//td[@class='left'])[9]")
	WebElement details_Command;
	
	@FindBy(xpath="(//td[@class='left'])[10]")
	WebElement details_Target_Level;
	
	@FindBy(xpath="(//td[@class='left'])[11]")
	WebElement details_Date_Time;
	
	@FindBy(xpath="(//td[@class='left'])[12]")
	WebElement details_Status;
	
	@FindBy(xpath="(//td[@class='left'])[13]")
	WebElement details_Resend;
			
	@FindBy(xpath="(//td[@class='left'])[14]")
	WebElement details_Target_No;		
		
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
    @FindBy(xpath="//input[@id='scriptBox' and @name='filter_value']")
    WebElement target_box;
    
    @FindBy(xpath=".//*[@id='filter_command' and @name='filter_command']")
    WebElement command_select_option;
	
    @FindBy(xpath="//input[@id='date' and @name='filter_date_added']")
    WebElement date_time_option;
    
    @FindBy(xpath="//td[text()='Jan']")
    WebElement jan_month;
    
    
private void click_on_Complete_Logs(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(Logs)).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Complete_Logs)).click();
	}
	
	public void Verify_element_method(){
		this.click_on_Complete_Logs();
		
		assertEquals(driver.getTitle(), "Complete Logs");
		Home_link.isDisplayed();
		Complete_Logs_link.isDisplayed();
		subheading_Command.isDisplayed();
		subheading_Date_Time.isDisplayed();
		subheading_Resend.isDisplayed();
		subheading_Status.isDisplayed();
		subheading_Target.isDisplayed();
		subheading_Target_Level.isDisplayed();
		subheading_Target_No.isDisplayed();
		heading_Complete_Logs.isDisplayed();
		Search_button.isDisplayed();		
		print_button.isDisplayed();
		
		Complete_Logs_link.click();
		assertEquals(driver.getTitle(), "Complete Logs");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		//this.click_on_Complete_Logs();
		reports.click();
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.elementToBeClickable(Logs)).click();
		driver.findElement(By.xpath(".//*[@id=' ']/ul/li[18]/ul/a[1]")).click();		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String[] aa = { "STB ACTIVATION", "STB DEACTIVATION", "PACKAGE ENTITLEMENT","PACKAGE DEENTITLEMENT", "SPECIAL COMMANDS", "PPV ENTITLEMENT", "SERVICE ENTITLEMENT","SERVICE DEENTITLEMENT" };
		for (String s: aa) {           ; 
		new Select(command_select_option).selectByVisibleText(s);
		Search_button.click();
	    details_Command.isDisplayed();
	    details_Date_Time.isDisplayed();
	    details_Resend.isDisplayed();
	    details_Status.isDisplayed();
	    details_Target.isDisplayed();
	    details_Target_Level.isDisplayed();
	    details_Target_No.isDisplayed();	
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");   
		}
		 
	}
		
}