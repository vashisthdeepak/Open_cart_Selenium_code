package com.reports_Location_Wise_SettopBox;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.baseclass.BaseClass;

public class Reports_Service_Wise_Packages_List extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Service Wise Packages List")
	WebElement Service_Wise_Packages_List;
				
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Service_Wise_Packages_List_link;
	
	@FindBy(xpath = "//div[@id='error_generated' and @class='warning']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Service Number']")
	WebElement subheading_Service_Number;
	
	@FindBy(xpath="//td[@class='left' and text()='Service Name']")
	WebElement subheading_Service_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Package Id']")
	WebElement subheading_Package_Id;
				
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Service_Wise_Packages_List;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[4]")
	WebElement details_Service_Number;

	@FindBy(xpath="(//td[@class='left'])[5]")
	WebElement details_Service_Name;
	
	@FindBy(xpath="(//td[@class='left'])[6]")
	WebElement details_Package_Id;
		
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;											 
	
    @FindBy(xpath="//select[@id='filter_product' and @name='filter_product']")
    WebElement select_product_option;
    	
	private void click_on_Service_Wise_Packages_List(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(Service_Wise_Packages_List)).click();
	 }
	
	public void Verify_element_method(){
		this.click_on_Service_Wise_Packages_List();
		
		assertEquals(driver.getTitle(), "Service-Wise Total Active Packages");
		Home_link.isDisplayed();
		Service_Wise_Packages_List_link.isDisplayed();
		subheading_Service_Name.isDisplayed();
		subheading_Service_Number.isDisplayed();
		subheading_Package_Id.isDisplayed();
		Filter_button.isDisplayed();		
		print_button.isDisplayed();
		Service_Wise_Packages_List_link.click();
		assertEquals(driver.getTitle(), "Service-Wise Total Active Packages");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify
	}
		
	public void valid_method(){		
		this.click_on_Service_Wise_Packages_List();
		new Select(select_product_option).getFirstSelectedOption();
		Filter_button.click();
		details_Package_Id.isDisplayed();
		details_Service_Name.isDisplayed();
		details_Service_Number.isDisplayed();
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 1");		
	}
	
	public void Invalid_method(){
		this.click_on_Service_Wise_Packages_List();
		Filter_button.click();
		assertEquals("Warning : Please select any product to process!", msg_error.getText());
		
		Service_Wise_Packages_List_link.click();
		print_button.click();
		assertEquals("Warning : Please select atleast one to process!", msg_error.getText());
						
	}
	
}
