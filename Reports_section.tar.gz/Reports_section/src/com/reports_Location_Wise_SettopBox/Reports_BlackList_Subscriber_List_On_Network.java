package com.reports_Location_Wise_SettopBox;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.baseclass.BaseClass;

public class Reports_BlackList_Subscriber_List_On_Network extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="BlackList Subscriber List On Network")
	WebElement BlackList_Subscriber_List_On_Network;
				
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement BlackList_Subscriber_List_On_Network_link;
	
	@FindBy(xpath = "//div[@id='error_generated' and @class='warning']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='STB No.']")
	WebElement subheading_STB_No;
						
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_BlackList_Subscriber_List_On_Network;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
		
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[2]")
	WebElement details_STB_No;

	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;											 
	       	
	private void click_on_BlackList_Subscriber_List_On_Network(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(BlackList_Subscriber_List_On_Network)).click();
	 }
	
	public void Verify_element_method(){
		this.click_on_BlackList_Subscriber_List_On_Network();
		
		assertEquals(driver.getTitle(), "BlackList Subscriber List On Network");
		Home_link.isDisplayed();
		BlackList_Subscriber_List_On_Network_link.isDisplayed();
		subheading_STB_No.isDisplayed();
		print_button.isDisplayed();
		BlackList_Subscriber_List_On_Network_link.click();
		assertEquals(driver.getTitle(), "BlackList Subscriber List On Network");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify
	}
				
	public void Invalid_method(){
				
		this.click_on_BlackList_Subscriber_List_On_Network();
		print_button.click();
		assertEquals("Warning : Please select atleast one to process!", msg_error.getText());
						
	}
	
}
