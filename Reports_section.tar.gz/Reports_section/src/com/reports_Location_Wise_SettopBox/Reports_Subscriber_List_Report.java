package com.reports_Location_Wise_SettopBox;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;

public class Reports_Subscriber_List_Report extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Subscriber List Report")
	WebElement Subscriber_List_Report;
				
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Subscriber_List_Report_link;
	
	@FindBy(xpath = "//div[@id='error_generated' and @class='warning']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Customer No']")
	WebElement subheading_Customer_No;
	
	@FindBy(xpath="//td[@class='left' and text()='Customer Name']")
	WebElement subheading_Customer_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Operators']")
	WebElement subheading_Operators;
		
	@FindBy(xpath="//td[@class='left' and text()='Customer Group']")
	WebElement subheading_Customer_Group;
	
	@FindBy(xpath="//td[@class='left' and text()='STB No.']")
	WebElement subheading_STB_No;
	
	@FindBy(xpath="//td[@class='left' and text()='Product/Package No.']")
	WebElement subheading_Product_Package_No;
	
	@FindBy(xpath="//td[@class='left' and text()='Mobile']")
	WebElement subheading_Mobile;
	
	@FindBy(xpath="//td[@class='left' and text()='STB Status']")
	WebElement subheading_STB_Status;
				
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Subscriber_List_Report;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement Search_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[9]")
	WebElement details_Customer_No;

	@FindBy(xpath="(//td[@class='left'])[10]")
	WebElement details_Customer_Name;
	
	@FindBy(xpath="(//td[@class='left'])[11]")
	WebElement details_Operators;
	
	@FindBy(xpath="(//td[@class='left'])[12]")
	WebElement details_Customer_Group;
	
	@FindBy(xpath="(//td[@class='left'])[13]")
	WebElement details_STB_No;
	
	@FindBy(xpath="(//td[@class='left'])[14]")
	WebElement details_Product_Package_No;
	
	@FindBy(xpath="(//td[@class='left'])[15]")
	WebElement details_Mobile;
	
	@FindBy(xpath="(//td[@class='left'])[16]")
	WebElement details_STB_Status;                        
	
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;											 //
	
    @FindBy(xpath="//input[@type='text' and @name='filter_stb']")
    WebElement STB_NO_box;
    
    @FindBy(xpath=".//*[@id='region_id']")
    WebElement select_region_name;
	
    @FindBy(xpath = "//a[text()='Sales']")
	WebElement Sales;
	
	@FindBy(xpath = "(//a[text()='Customers'])[1]")
	public WebElement sales_Customertab;
	
	@FindBy(xpath = "(//a[text()='Customers'])[2]")
	public WebElement sales_Customersel;
	
	@FindBy(xpath="(//a[@class='button'])[3]")
	public WebElement sales_Insert;
    
	@FindBy(xpath="(//a[text()='Edit'])[1]")
	WebElement sales_edit_first_customer;
	
	@FindBy(xpath="(//td[@class='left'])[12]")
	WebElement sales_copy_first_STB_no;
	
	@FindBy(xpath="(//td[@class='left'])[11]")
	WebElement sales_copy_first_Customer_name;		
			
	@FindBy(xpath=".//*[@id='address-1']")
	WebElement sales_Click_address_tab;
	
	@FindBy(xpath="//select[@name=\"address[1][region_id]\"]")
	WebElement sales_cust_region;
	
	@FindBy(xpath="//select[@name='status']")
	WebElement sales_cust_status;
			
	@FindBy(xpath="(//a[text()='General'])[2]")
	WebElement sales_general_tab;		
	
	@FindBy(xpath="//input[@type='password' and @name='confirm']")
	WebElement sales_confirm_password;
		
	@FindBy(xpath="//a[@class='button' and text()='Submit']")
	WebElement sales_Submit_button;
	
	@FindBy(xpath="//input[@type='text' and @name='address[1][address_1]']")
	WebElement sales_select_address_box;
	
	@FindBy(xpath="//input[@type='text' and @name=\"firstname\"]")
	WebElement sales_first_name;	
	
	@FindBy(xpath="//input[@type='text' and @name='lastname']")
	WebElement sales_last_name;	  
	
	@FindBy(xpath="//select[@name='customer_group_id']")
	WebElement sales_cust_group;
	
	@FindBy(xpath="//input[@type='text' and @name='telephone']")
	WebElement sales_copy_mobile_no;
	
	ExcelReader read =new ExcelReader();
	private void click_on_Sales_Customers(){

		   Sales.click();
		   WebDriverWait wait = new WebDriverWait(driver,10);
		   wait.until(ExpectedConditions.elementToBeClickable(sales_Customertab)).click();
		   wait.until(ExpectedConditions.elementToBeClickable(sales_Customersel)).click();
		}
	
	
   private void click_on_Subscriber_List_Report(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(Subscriber_List_Report)).click();
	 }
	
	public void Verify_element_method(){
		this.click_on_Subscriber_List_Report();
		
		assertEquals(driver.getTitle(), "Subscriber List Report");
		Home_link.isDisplayed();
		Subscriber_List_Report_link.isDisplayed();
		subheading_Customer_Group.isDisplayed();
		subheading_Customer_No.isDisplayed();
		subheading_Customer_Name.isDisplayed();
		subheading_Mobile.isDisplayed();
		subheading_Operators.isDisplayed();
		subheading_Product_Package_No.isDisplayed();
		subheading_STB_Status.isDisplayed();
		subheading_STB_No.isDisplayed();
		Search_button.isDisplayed();		
		print_button.isDisplayed();
		Subscriber_List_Report_link.click();
		assertEquals(driver.getTitle(), "Subscriber List Report");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
		
	public void valid_method(){		
		this.click_on_Sales_Customers();
		String str5 = Page_info.getText().substring(13, 16);
		System.out.println(str5);
		String sales_cust_first_STB_NO = sales_copy_first_STB_no.getText();
		String sales_cust_first_cust_name = sales_copy_first_Customer_name.getText();
		sales_edit_first_customer.click();
		String sales_mobile_no = sales_copy_mobile_no.getAttribute("value");
						
		this.click_on_Subscriber_List_Report();
		String str6 = Page_info.getText().substring(13, 16);
		System.out.println(str6);
		assertEquals(str5, str6);                                                        //Verify total count
		STB_NO_box.sendKeys(sales_cust_first_STB_NO);
		Search_button.click();
		assertEquals(sales_cust_first_cust_name, details_Customer_Name.getText());       //verify customer name
		assertEquals(sales_mobile_no, details_Mobile.getText());						 //verify mobile
				
		this.click_on_Sales_Customers();
		sales_edit_first_customer.click();
		sales_first_name.clear();
		String new_cust_name = BaseClass.givenUsingApache_whenGeneratingRandomStringBounded_thenCorrect();
		sales_first_name.sendKeys(new_cust_name);
		sales_last_name.clear();
		sales_last_name.sendKeys(new_cust_name);
		String random_mobile_no = BaseClass.random_number();
		sales_copy_mobile_no.clear();
		sales_copy_mobile_no.sendKeys(random_mobile_no);	
		Select comboBox = new Select(sales_cust_group); 
		String copy_cust_group = comboBox.getFirstSelectedOption().getText();
        System.out.println(copy_cust_group);
		sales_Submit_button.click();
		
		this.click_on_Subscriber_List_Report();
		STB_NO_box.sendKeys(sales_cust_first_STB_NO);
		assertEquals(new_cust_name+" "+new_cust_name, details_Customer_Name.getText());    //verify changed customer name
		assertEquals(random_mobile_no, details_Mobile.getText());						//verify changed customer name
		assertEquals(copy_cust_group, details_Customer_Group.getText());				//verify changed customer group
				
	}
	
	public void Invalid_method(){
		this.click_on_Subscriber_List_Report();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		print_button.click();
		assertEquals("Warning : Please select atleast one to process!", msg_error.getText());    
						
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
