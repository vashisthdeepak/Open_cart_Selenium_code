package com.reports_Location_Wise_SettopBox;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;

public class Reports_STB_wise_change_of_Package_Product extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="STB wise change of Package/Channel")
	WebElement STB_wise_change_of_Package_Product;
				
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement STB_wise_change_of_Package_Product_link;
	
	@FindBy(xpath = "//div[@id='error_generated' and @class='warning']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='center' and text()='STB No']")
	WebElement subheading_STB_No;
	
	@FindBy(xpath="//td[@class='center' and text()='Command Triggered']")
	WebElement subheading_Command_Triggered;
	
	@FindBy(xpath="//td[@class='center' and text()='Package/Product No.']")
	WebElement subheading_Package_Product_No;
	
	@FindBy(xpath="//td[@class='center' and text()='Activation Date']")
	WebElement subheading_Activation_Date;	
	
	@FindBy(xpath="//td[@class='center' and text()='Expiry Date']")
	WebElement subheading_Expiry_Date;
				
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_STB_wise_change_of_Package_Product;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='center'])[6]")
	WebElement details_STB_No;

	@FindBy(xpath="(//td[@class='center'])[7]")
	WebElement details_Command_Triggered;
	
	@FindBy(xpath="(//td[@class='center'])[8]")
	WebElement details_Package_Product_No;
	
	@FindBy(xpath="(//td[@class='center'])[9]")
	WebElement details_Activation_Date;
	
	@FindBy(xpath="(//td[@class='center'])[10]")
	WebElement details_Expiry_Date;
		
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;											 
	
    @FindBy(xpath="//input[@type='text' and @name='filter_stb']")
    WebElement STB_NO_box;
    	
    @FindBy(xpath = ".//*[@id='to_date']")
	WebElement from_date_option;
	
    @FindBy(xpath = ".//*[@id='from_date']")
   	WebElement to_date_option;
    
    @FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[1]")
   	WebElement from_from_date_prev_month;
    
    @FindBy(xpath = "//a[@class='ui-state-default' and text()='1']")
   	WebElement from_from_date_first_date;
    
    @FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
   	WebElement from_from_date_next_month;
    
    @FindBy(xpath = "//a[@class='ui-state-default ui-state-active' and text()='1']")
   	WebElement from_from_date_next_month_first_date;
    
    @FindBy(xpath = ".//*[@id='ui-datepicker-div']/div/a[2]/span")
   	WebElement to_date_next_month;
    
    @FindBy(xpath = ".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[5]/a")
   	WebElement to_date_next_month_first_date;
	
	
	ExcelReader read =new ExcelReader();
  private void click_on_STB_wise_change_of_Package_Product(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(STB_wise_change_of_Package_Product)).click();
	 }
	
	public void Verify_element_method(){
		this.click_on_STB_wise_change_of_Package_Product();
		
		assertEquals(driver.getTitle(), "STB wise change of Package/Product");
		Home_link.isDisplayed();
		STB_wise_change_of_Package_Product_link.isDisplayed();
		subheading_Activation_Date.isDisplayed();
		subheading_Command_Triggered.isDisplayed();
		subheading_Expiry_Date.isDisplayed();
		subheading_STB_No.isDisplayed();
		subheading_Package_Product_No.isDisplayed();
		Filter_button.isDisplayed();		
		print_button.isDisplayed();
		STB_wise_change_of_Package_Product_link.click();
		assertEquals(driver.getTitle(), "STB wise change of Package/Product");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
		
	public void valid_method(){		
		this.click_on_STB_wise_change_of_Package_Product();
		from_date_option.click();
		from_from_date_prev_month.click();
		from_from_date_first_date.click();
		to_date_option.click();
		to_date_option.sendKeys(Keys.ENTER);
		Filter_button.click();	
		details_Activation_Date.isDisplayed();
		details_Command_Triggered.isDisplayed();
		details_Expiry_Date.isDisplayed();
		details_Package_Product_No.isDisplayed();
		details_STB_No.isDisplayed();
				
	}
	
	public void Invalid_method(){
		this.click_on_STB_wise_change_of_Package_Product();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Filter_button.click();
		assertEquals("Warning : From date required!", msg_error.getText());  
		
		STB_wise_change_of_Package_Product_link.click();
		from_date_option.click();
		from_from_date_next_month.click();
		from_from_date_first_date.click();
		to_date_option.click();
		to_date_next_month.click();
		to_date_next_month_first_date.click();
		Filter_button.click();
		assertEquals(Page_info.getText().subSequence(0, 9),"Showing 0");
				
		STB_wise_change_of_Package_Product_link.click();
		from_date_option.click();
		from_from_date_next_month.click();
		from_from_date_first_date.click();
		to_date_option.click();
		to_date_option.sendKeys(Keys.ENTER);
		Filter_button.click();
		assertEquals("Warning : From date is greater than To date!", msg_error.getText());  
			
		STB_wise_change_of_Package_Product_link.click();
		print_button.click();
		assertEquals("Warning : Please filter records before printing!", msg_error.getText());
						
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
