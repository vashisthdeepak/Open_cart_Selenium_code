package com.reports_Location_Wise_SettopBox;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;

public class Reports_Location_Wise_SettopBox_Count extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Location Wise STB")
	WebElement Location_Wise_STB;
	
	@FindBy(xpath="(//a[text()='Count'])[2]")
	WebElement Count;
			
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Location_Wise_SettopBox_Count_link;
	
	@FindBy(xpath = "//div[@id='error_generated' and @class='warning']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Region Name']")
	WebElement subheading_Region_Name;
		
	@FindBy(xpath="//td[@class='left' and text()='Sl.No.']")
	WebElement subheading_SL_no;
		
	@FindBy(xpath="//td[@class='left' and text()='Count']")
	WebElement subheading_Count;
				
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Location_Wise_SettopBox_Count;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[5]")
	WebElement details_region_name;
	   
	@FindBy(xpath="(//td[@class='left'])[4]")
    WebElement details_SL_no;	
		
	@FindBy(xpath="(//td[@class='left'])[6]")
	WebElement details_count;
						
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
    @FindBy(xpath=".//*[@id='zone_id']")
    WebElement select_zones;
    
    @FindBy(xpath=".//*[@id='region_id']")
    WebElement select_region_name;
			
	ExcelReader read =new ExcelReader();
		
   private void click_on_Location_Wise_STB_Count(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(Location_Wise_STB)).click();
	   wait.until(ExpectedConditions.elementToBeClickable(Count)).click();
	}
	
	public void Verify_element_method(){
		this.click_on_Location_Wise_STB_Count();
		
		assertEquals(driver.getTitle(), "Location Wise SettopBox Count");
		Home_link.isDisplayed();
		Location_Wise_SettopBox_Count_link.isDisplayed();
		subheading_Count.isDisplayed();
		subheading_SL_no.isDisplayed();
		subheading_Region_Name.isDisplayed();
		Filter_button.isDisplayed();		
		print_button.isDisplayed();
		select_zones.isDisplayed();
		select_region_name.isDisplayed();		
		Location_Wise_SettopBox_Count_link.click();
		assertEquals(driver.getTitle(), "Location Wise SettopBox Count");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		this.click_on_Location_Wise_STB_Count();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Location_Wise_SettopBox_Count_link.click();
		new Select(select_zones).selectByValue("1489");
		new Select(select_region_name).selectByValue("30");
		Filter_button.click();
		details_SL_no.isDisplayed();
		details_count.isDisplayed();
		details_region_name.isDisplayed();
	
	}
	
	public void Invalid_method(){
		this.click_on_Location_Wise_STB_Count();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Filter_button.click();
		assertEquals("Warning : Please select zone!", msg_error.getText());    
		
		Location_Wise_SettopBox_Count_link.click();
		new Select(select_zones).selectByValue("1489");
		Filter_button.click();
		assertEquals("Warning : Please select region!", msg_error.getText());
		
		Location_Wise_SettopBox_Count_link.click();
		print_button.click();
		assertEquals("Warning : Please select atleast one to process!", msg_error.getText());

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
