package com.reports_Location_Wise_SettopBox;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;

public class Reports_Customer_Modification_List extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Customer Modification List")
	WebElement Customer_Modification_List;
				
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Customer_Modification_List_link;
	
	@FindBy(xpath = "//div[@id='error_generated' and @class='warning']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='center' and text()='Customer No']")
	WebElement subheading_Customer_No;
	
	@FindBy(xpath="//td[@class='center' and text()='STB No.']")
	WebElement subheading_STB_No;
	
	@FindBy(xpath="//td[@class='center' and text()='Group']")
	WebElement subheading_Group;
	
	@FindBy(xpath="//td[@class='center' and text()='Region Name']")
	WebElement subheading_Region_Name;
	
	@FindBy(xpath="//td[@class='center' and text()='Pin']")
	WebElement subheading_Pin;
	
	@FindBy(xpath="//td[@class='center' and text()='Pairing Status']")
	WebElement subheading_Pairing_Status;
	
	@FindBy(xpath="//td[@class='center' and text()='Date']")
	WebElement subheading_Date;
				
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Customer_Modification_List;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement Search_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='center'])[9]")
	WebElement details_Customer_No;
	
	@FindBy(xpath="(//td[@class='center'])[10]")
	WebElement details_STB_No;
	
	@FindBy(xpath="(//td[@class='center'])[11]")
	WebElement details_Group;
	
	@FindBy(xpath="(//td[@class='center'])[12]")
	WebElement details_Region_Name;
	
	@FindBy(xpath="(//td[@class='center'])[13]")
	WebElement details_Pin;
	
	@FindBy(xpath="(//td[@class='center'])[14]")
	WebElement details_Pairing_Status;
	
	@FindBy(xpath="(//td[@class='center'])[15]")
	WebElement details_Date;
		
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;											 
	
    @FindBy(xpath="//input[@id='scriptBox' and @name='filter_value']")
    WebElement STB_No_box;
    
    @FindBy(xpath = "//a[text()='Sales']")
   	WebElement Sales;
   	
   	@FindBy(xpath = "(//a[text()='Customers'])[1]")
   	public WebElement sales_Customertab;
   	
   	@FindBy(xpath = "(//a[text()='Customers'])[2]")
   	public WebElement sales_Customersel;
   	
   	@FindBy(xpath="(//a[@class='button'])[3]")
   	public WebElement sales_Insert;
       
   	@FindBy(xpath="(//a[text()='Edit'])[1]")
   	WebElement sales_edit_first_customer;
   	
   	@FindBy(xpath="(//td[@class='left'])[12]")
   	WebElement sales_copy_first_STB_no;
   	
   	@FindBy(xpath="(//td[@class='left'])[11]")
   	WebElement sales_copy_first_Customer_name;		
   			
   	@FindBy(xpath=".//*[@id='address-1']")
   	WebElement sales_Click_address_tab;
   	
   	@FindBy(xpath="//select[@name=\"address[1][region_id]\"]")
   	WebElement sales_cust_region;
   	
   	@FindBy(xpath="//select[@name='status']")
   	WebElement sales_cust_status;
   			
   	@FindBy(xpath="(//a[text()='General'])[2]")
   	WebElement sales_general_tab;		
   	
   	@FindBy(xpath="//input[@type='password' and @name='confirm']")
   	WebElement sales_confirm_password;
   		
   	@FindBy(xpath="//a[@class='button' and text()='Submit']")
   	WebElement sales_Submit_button;
   	
   	@FindBy(xpath="//input[@type='text' and @name='address[1][address_1]']")
   	WebElement sales_select_address_box;
   	
   	@FindBy(xpath="//input[@type='text' and @name=\"firstname\"]")
   	WebElement sales_first_name;	
   	
   	@FindBy(xpath="//input[@type='text' and @name='lastname']")
   	WebElement sales_last_name;	  
   	
   	@FindBy(xpath="//select[@name='customer_group_id']")
   	WebElement sales_cust_group;
   	
   	@FindBy(xpath="//input[@type='text' and @name='telephone']")
   	WebElement sales_copy_mobile_no;
   	
    @FindBy(xpath="//input[@type='text' and @name='filter_stb']")
    WebElement STB_NO_box;
    
    @FindBy(xpath="(//td[@class='left'])[14]")
   	WebElement sales_copy_first_cust_group;
    
    @FindBy(xpath="(//td[@class='left'])[17]")
   	WebElement sales_copy_first_date_added;
    
    @FindBy(xpath="(//td[@class='left'])[10]")
   	WebElement sales_copy_first_cust_no;
    
    @FindBy(xpath="//input[@id='address[1][postcode]' and @name='address[1][postcode]']")
   	WebElement sales_copy_pincode;
    
  
   	ExcelReader read =new ExcelReader();
   	private void click_on_Sales_Customers(){
   		   Sales.click();
   		   WebDriverWait wait = new WebDriverWait(driver,10);
   		   wait.until(ExpectedConditions.elementToBeClickable(sales_Customertab)).click();
   		   wait.until(ExpectedConditions.elementToBeClickable(sales_Customersel)).click();
   		}
    	
	private void click_on_Customer_Modification_List(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(Customer_Modification_List)).click();
	 }
	
	public void Verify_element_method(){
		this.click_on_Customer_Modification_List();
		
		assertEquals(driver.getTitle(), "Customer Modification List");
		Home_link.isDisplayed();
		Customer_Modification_List_link.isDisplayed();
        subheading_Customer_No.isDisplayed();
        subheading_Date.isDisplayed();
        subheading_Group.isDisplayed();
        subheading_Pairing_Status.isDisplayed();
        subheading_Pin.isDisplayed();
        subheading_Region_Name.isDisplayed();
        subheading_STB_No.isDisplayed();
        Search_button.isDisplayed();
		print_button.isDisplayed();
		Customer_Modification_List_link.click();
		assertEquals(driver.getTitle(), "Customer Modification List");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify
	}
		
	public void valid_method(){		
		this.click_on_Sales_Customers();
		String sales_first_cust_STB_NO = sales_copy_first_STB_no.getText();
		String sales_first_cust_group = sales_copy_first_cust_group.getText();
		String sales_first_cust_date_added = sales_copy_first_date_added.getText();
		String sales_first_cust_no = sales_copy_first_cust_no.getText();
		sales_edit_first_customer.click();
        sales_Click_address_tab.click();
        Select comboBox = new Select(sales_cust_region); 
        String sales_cust_region_name = comboBox.getFirstSelectedOption().getText();
        String sales_pincode = sales_copy_pincode.getAttribute("value");
						
		this.click_on_Customer_Modification_List();
		STB_No_box.sendKeys(sales_first_cust_STB_NO);
		Search_button.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(sales_pincode, details_Pin.getText());						                //verify PIN
		assertEquals(sales_cust_region_name, details_Region_Name.getText());				   //verify Region Name
		assertEquals(sales_first_cust_group, details_Group.getText());						  //verify group	
		assertEquals(sales_first_cust_date_added, details_Date.getText());					 //verify date added
		assertEquals(sales_first_cust_no, details_Customer_No.getText());	                //verify customer no.
		System.out.println(sales_pincode);
		System.out.println(sales_cust_region_name);
		System.out.println(sales_first_cust_group);
		System.out.println(sales_first_cust_date_added);				
	}
	
	public void Invalid_method(){
		this.click_on_Customer_Modification_List();
		Search_button.click();
		String alert_text= driver.switchTo().alert().getText();
		assertEquals("Please Insert the stb no.!", alert_text);
		driver.switchTo().alert().accept();
									
	}
	
}
