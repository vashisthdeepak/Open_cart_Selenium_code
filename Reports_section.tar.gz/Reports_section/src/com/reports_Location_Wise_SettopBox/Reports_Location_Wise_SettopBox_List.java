package com.reports_Location_Wise_SettopBox;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;

public class Reports_Location_Wise_SettopBox_List extends BaseClass{
	
	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Location Wise STB")
	WebElement Location_Wise_STB;
	
	@FindBy(xpath="(//a[text()='List'])[2]")
	WebElement List;
			
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Location_Wise_SettopBox_link;
	
	@FindBy(xpath = "//div[@id='error_generated' and @class='warning']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Region Name']")
	WebElement subheading_Region_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Location']")
	WebElement subheading_Location;
	
	@FindBy(xpath="//td[@class='left' and text()='STB No']")
	WebElement subheading_STB_No;
		
	@FindBy(xpath="//td[@class='left' and text()='Customer Name']")
	WebElement subheading_Customer_Name;
				
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_Location_Wise_SettopBox;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;
	
	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(xpath="//div[@class='results']")
	WebElement Page_info;
	
	@FindBy(xpath="(//td[@class='left'])[5]")
	WebElement details_region_name;
	
   	@FindBy(xpath=".//*[@id='form']/table/tbody/tr[1]/td[3]")
    WebElement details_location;	
		
	@FindBy(xpath="(//td[@class='left'])[7]")
	WebElement details_customer_name;
	
	@FindBy(xpath="(//td[@class='left'])[8]")
	WebElement details_STB_No;
				
	@FindBy(xpath="//td[@class='center' and text()='No results!']")
	WebElement details_no_results;
	
    @FindBy(xpath=".//*[@id='zone_id']")
    WebElement select_zones;
    
    @FindBy(xpath=".//*[@id='region_id']")
    WebElement select_region_name;
	
    @FindBy(xpath = "//a[text()='Sales']")
	WebElement Sales;
	
	@FindBy(xpath = "(//a[text()='Customers'])[1]")
	public WebElement sales_Customertab;
	
	@FindBy(xpath = "(//a[text()='Customers'])[2]")
	public WebElement sales_Customersel;
	
	@FindBy(xpath="(//a[@class='button'])[3]")
	public WebElement sales_Insert;
    
	@FindBy(xpath="(//a[text()='Edit'])[1]")
	WebElement sales_edit_first_customer;
	
	@FindBy(xpath="(//td[@class='left'])[12]")
	WebElement sales_copy_first_STB_no;
	
	@FindBy(xpath=".//*[@id='address-1']")
	WebElement sales_Click_address_tab;
	
	@FindBy(xpath="//select[@name=\"address[1][region_id]\"]")
	WebElement sales_cust_region;
	
	@FindBy(xpath="//select[@name='address[1][zone_id]']")
	WebElement sales_cust_state_zone;
			
	@FindBy(xpath="(//a[text()='General'])[2]")
	WebElement sales_general_tab;		
	
	@FindBy(xpath="//input[@type='password' and @name='confirm']")
	WebElement sales_confirm_password;
		
	@FindBy(xpath="//a[@class='button' and text()='Submit']")
	WebElement sales_Submit_button;
	
	@FindBy(xpath="//input[@type='text' and @name='address[1][address_1]']")
	WebElement sales_select_address_box;
	
	@FindBy(xpath="//input[@type='text' and @name=\"firstname\"]")
	WebElement sales_first_name;
	
	
	@FindBy(xpath="//input[@type='text' and @name='lastname']")
	WebElement sales_last_name;	
	
	
	ExcelReader read =new ExcelReader();
	private void click_on_Sales_Customers(){

		Sales.click();
		   WebDriverWait wait = new WebDriverWait(driver,10);
		   wait.until(ExpectedConditions.elementToBeClickable(sales_Customertab)).click();
		   wait.until(ExpectedConditions.elementToBeClickable(sales_Customersel)).click();
		}
	
	
   private void click_on_Location_Wise_STB_List(){

	   reports.click();
	   WebDriverWait wait = new WebDriverWait(driver,10);
	   wait.until(ExpectedConditions.elementToBeClickable(Location_Wise_STB)).click();
	   wait.until(ExpectedConditions.elementToBeClickable(List)).click();
	}
	
	public void Verify_element_method(){
		this.click_on_Location_Wise_STB_List();
		
		assertEquals(driver.getTitle(), "Location Wise SettopBox");
		Home_link.isDisplayed();
		Location_Wise_SettopBox_link.isDisplayed();
		subheading_Customer_Name.isDisplayed();
		subheading_Location.isDisplayed();
		subheading_Region_Name.isDisplayed();
		subheading_STB_No.isDisplayed();
		Filter_button.isDisplayed();		
		print_button.isDisplayed();
		select_zones.isDisplayed();
		select_region_name.isDisplayed();		
		Location_Wise_SettopBox_link.click();
		assertEquals(driver.getTitle(), "Location Wise SettopBox");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");                           //content Verify

	}
	
	
	public void valid_method(){		
		this.click_on_Location_Wise_STB_List();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Location_Wise_SettopBox_link.click();
		new Select(select_zones).selectByValue("1489");
		new Select(select_region_name).selectByValue("30");
		Filter_button.click();
		details_customer_name.isDisplayed();
		details_location.isDisplayed();
		details_region_name.isDisplayed();
		details_STB_No.isDisplayed();
				
		this.click_on_Sales_Customers();
		String STB_no = sales_copy_first_STB_no.getText();
		System.out.println(STB_no);
		sales_edit_first_customer.click();
		sales_Click_address_tab.click();
		String Copy_Address = sales_select_address_box.getAttribute("value");
        System.out.println(Copy_Address);
		Select comboBox = new Select(sales_cust_state_zone); 
		String copy_State_zone_name = comboBox.getFirstSelectedOption().getText();
        System.out.println(copy_State_zone_name);
            
        Select comboBox1 = new Select(sales_cust_region); 
        String region_name = comboBox1.getFirstSelectedOption().getText();
        System.out.println("Old selected region Name : "+region_name);
        
        java.util.List<WebElement> elementCount = comboBox1.getOptions();
        Iterator<WebElement> itr =elementCount.iterator();
        String new_selected_region_name="NULL";
        while(itr.hasNext()) {        	
            WebElement row = itr.next();            
            new_selected_region_name=row.getText();
            if(new_selected_region_name.equals(region_name) || new_selected_region_name.equals("-- Please Select --"))
            {
            	
            }
            else
            {
            	comboBox1.selectByVisibleText(new_selected_region_name);
            	System.out.println("New Selected Region name : "+new_selected_region_name);
            	break;
            }
        }
        sales_general_tab.click();
        sales_confirm_password.sendKeys("passwd");
        sales_Submit_button.click();
        
        this.click_on_Location_Wise_STB_List();
        new Select(select_zones).selectByVisibleText(copy_State_zone_name);
        new Select(select_region_name).selectByVisibleText(new_selected_region_name);
        Filter_button.click();
        assertEquals(STB_no, details_STB_No.getText());                                     //Check Region
        assertTrue(details_location.getText().contains(Copy_Address));                      // Check Address
                      
        this.click_on_Sales_Customers();
		sales_edit_first_customer.click();
		sales_first_name.clear();
		String new_cust_name = BaseClass.givenUsingApache_whenGeneratingRandomStringBounded_thenCorrect();
		sales_first_name.sendKeys(new_cust_name);
		System.out.println(new_cust_name);
		sales_last_name.clear();
		sales_last_name.sendKeys(new_cust_name);
		sales_Click_address_tab.click();
		sales_select_address_box.clear();
		sales_select_address_box.sendKeys(read.getsheetnumber(74, 0, 0));
		System.out.println(read.getsheetnumber(74, 0, 0));
		sales_general_tab.click();
        sales_confirm_password.sendKeys("passwd");
        sales_Submit_button.click();
        this.click_on_Location_Wise_STB_List();
        new Select(select_zones).selectByVisibleText(copy_State_zone_name);
        new Select(select_region_name).selectByVisibleText(new_selected_region_name);
        Filter_button.click();
        assertTrue(details_location.getText().contains(read.getsheetnumber(74, 0, 0)));        //Verify Changed Address
        assertTrue(details_customer_name.getText().contains(new_cust_name));                   //Verify Changed First name
		String first_and_last_name = details_customer_name.getText();
		assertTrue(first_and_last_name.contains(new_cust_name+" "+new_cust_name));              //Verify Changed First and Last name
		
	}
	
	public void Invalid_method(){
		this.click_on_Location_Wise_STB_List();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Filter_button.click();
		assertEquals("Warning : Please select zone!", msg_error.getText());    
		
		Location_Wise_SettopBox_link.click();
		new Select(select_zones).selectByValue("1489");
		Filter_button.click();
		assertEquals("Warning : Please select region!", msg_error.getText());
		
		Location_Wise_SettopBox_link.click();
		print_button.click();
		assertEquals("Warning : Please select atleast one to process!", msg_error.getText());
						
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
