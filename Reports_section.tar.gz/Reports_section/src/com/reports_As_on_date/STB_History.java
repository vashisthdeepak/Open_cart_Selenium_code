package com.reports_As_on_date;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class STB_History extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="STB History")
	WebElement STB_Histroy;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement STB_Histroy_link;
	
	@FindBy(xpath = ".//*[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Customer Name']")
	WebElement subheading_Customer_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Customer No']")
	WebElement subheading_Customer_No;
	
	@FindBy(xpath="//td[@class='left' and text()='STBNO']")
	WebElement subheading_STBNO;
	
	@FindBy(xpath="//td[@class='left' and text()='Command']")
	WebElement subheading_Command;
	
	@FindBy(xpath="//td[@class='left' and text()='Product/Package Name']")
	WebElement subheading_Product_Package_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Date Triggered']")
	WebElement subheading_Date_Triggered;
	
	@FindBy(xpath="//td[@class='left' and text()='Exp Date']")
	WebElement subheading_Exp_Date;
	
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_STB_history;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(xpath="//a[@class='button' and text()='Filter']")
	WebElement Filter_button;
	
	@FindBy(id="filter_stbno")
	WebElement filter_stbno_box;
	
	@FindBy(id="filter_command")
	WebElement filter_command_dropdown;
	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
	
	
	private void click_on_broadcaster_report(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.click(STB_Histroy).build().perform();
	}
	
	public void Verify_element_method() throws IOException{
		GetReportFilePath.DeleteFolderfiles();
		this.click_on_broadcaster_report();
		STB_Histroy_link.click();
		//assertEquals(driver.getTitle(), "STB History");     //History Spelling is wrong in Head-end build 3.10E
		Home_link.isDisplayed();
		STB_Histroy_link.isDisplayed();
		subheading_Command.isDisplayed();
		subheading_Customer_No.isDisplayed();
		subheading_Customer_Name.isDisplayed();
		subheading_Date_Triggered.isDisplayed();
		subheading_Exp_Date.isDisplayed();
		subheading_Product_Package_Name.isDisplayed();
		subheading_STBNO.isDisplayed();
		print_button.isDisplayed();
		Filter_button.isDisplayed();
		
		//assertEquals(driver.getTitle(), "STB History");     //History Spelling is wrong in Head-end build 3.10E
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");

		this.click_on_broadcaster_report();
		Select sel = new Select(filter_command_dropdown);
		sel.selectByVisibleText("Box Activation");
		sel.selectByVisibleText("Box De-Activation");
		sel.selectByVisibleText("Package Subscription");
		sel.selectByVisibleText("Package De-Subscription");
		sel.selectByVisibleText("Product Subscription");
		sel.selectByVisibleText("Product De-Subscription");
		sel.selectByVisibleText("PPV Subscription");
		sel.selectByVisibleText("PPV De-Subscription");

	}

		
	
	
	
	  
	

	
	

}