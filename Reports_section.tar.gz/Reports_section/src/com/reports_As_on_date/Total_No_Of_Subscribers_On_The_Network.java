package com.reports_As_on_date;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class Total_No_Of_Subscribers_On_The_Network extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Total No Of Subscribers On The n/w")
	WebElement Total_No_Of_Subscribers_On_The_network;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement Total_No_Of_Subscribers_On_The_network_link;
	
	@FindBy(xpath = ".//*[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Total Enabled Subscribers']")
	WebElement subheading_Total_Enabled_Subscribers;
	
	@FindBy(xpath="//td[@class='left' and text()='Paired Subscriber']")
	WebElement subheading_Paired_Subscriber;
	
	@FindBy(xpath="//td[@class='left' and text()='Unpaired Subscriber']")
	WebElement subheading_UnPaired_Subscriber;
	
	@FindBy(xpath="//td[@class='left' and text()='Active Subscriber']")
	WebElement subheading_Active_Subscriber;
	
	@FindBy(xpath="//td[@class='left' and text()='DeActive Subscriber']")
	WebElement subheading_DeActive_Subscriber;
	
	@FindBy(xpath=".//*[@id='content']/div[2]/div[1]/h1")
	WebElement heading_Total_No_Of_Subscribers_On_The_network;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(xpath="//div[text()='Total Enabled Subscriber']")
	WebElement page2;
	
	@FindBy(xpath="((//div)[45]")
	WebElement page3;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
	
	
	private void click_on_Total_No_Of_Subscribers_On_The_network(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.click(Total_No_Of_Subscribers_On_The_network).build().perform();
	}
	
	public void Verify_element_method() throws Throwable{
		GetReportFilePath.DeleteFolderfiles();
		this.click_on_Total_No_Of_Subscribers_On_The_network();
		Total_No_Of_Subscribers_On_The_network_link.click();
		assertEquals(driver.getTitle(), "Total No Of Subscribers On The Network");
		Home_link.isDisplayed();
		Total_No_Of_Subscribers_On_The_network_link.isDisplayed();
		subheading_Active_Subscriber.isDisplayed();
		subheading_DeActive_Subscriber.isDisplayed();
		subheading_Paired_Subscriber.isDisplayed();
		subheading_Total_Enabled_Subscribers.isDisplayed();
		subheading_UnPaired_Subscriber.isDisplayed();
		print_button.isDisplayed();
		
		assertEquals(driver.getTitle(), "Total No Of Subscribers On The Network");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");

//		this.click_on_Total_No_Of_Subscribers_On_The_network();
//		System.out.println(driver.getCurrentUrl()+"First Link");
//		print_button.click();
		
//		SwitchToStoreFrontWindow();
////		SwitchToParentWindow(); 
//      for (String winHandle : driver.getWindowHandles()) {
//	        driver.switchTo().window(winHandle);
//	        Thread.sleep(1000);
//	      }
//      
//		Thread.sleep(1000);
//		ArrayList<String> tabs= new ArrayList<String>(driver.getWindowHandles());
//        driver.switchTo().window(tabs.get(1));
//        System.out.println(driver.getCurrentUrl());
//      //  WebElement title=driver.findElement(By.xpath("(//*[local-name() = 'div'])[55]"));
//        WebElement title1=driver.findElement(By.xpath("//*[local-name() = 'div' and text()='Paired Subscriber']"));
//       // Assert.assertEquals(true, title.isDisplayed());
//        Assert.assertEquals(true, title1.isDisplayed());
        
        
      //  Assert.assertEquals("-: Total No Of Subscribers On The Network :-1",title.getText());
     //   System.out.println(title.getText());
	
		
	}

//	public void invalid_method(){
//		
//		this.click_on_Total_No_Of_Subscribers_On_The_network();
//		Report_Generate_button.click();
//		assertEquals(msg_sucess.getText(),"No Records in this duration!");
//		
//		date_start_option.click();
//		for(int i=0;i<20;i++){
//			date_start_option_back_month.click();
//		}
//		date_start_option.sendKeys(Keys.ENTER);
//		assertEquals("No Records in this duration!", msg_sucess.getText().trim());
//	}
//			
	
	
	
	
	  
	

	
	

}