package com.reports_As_on_date;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class Broadcaster_Report extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
		
	@FindBy(partialLinkText="Broadcaster Report")
	WebElement broadcaster_report;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath="(//a[text()='Broadcaster Report'])[2]")
	WebElement broadcaster_report_link;
	
	@FindBy(xpath = ".//*[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath="//td[@class='left' and text()='Region Name']")
	WebElement subheading_Region_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Product / Package Name']")
	WebElement subheading_Product_Package_Name;
	
	@FindBy(xpath="//td[@class='left' and text()='Channel Count']")
	WebElement subheading_Channel_Count;
	
	@FindBy(xpath="//td[@class='left' and text()='SMS Opening']")
	WebElement subheading_SMS_Opening;
	
	@FindBy(xpath="//td[@class='left' and text()='SMS Activated']")
	WebElement subheading_SMS_Activated;
	
	@FindBy(xpath="//td[@class='left' and text()='SMS De-activated']")
	WebElement subheading_SMS_De_activated;
	
	@FindBy(xpath="//td[@class='left' and text()='SMS Closing']")
	WebElement subheading_SMS_Closing;
	
	@FindBy(xpath="//td[@class='left' and text()='Average']")
	WebElement subheading_Average;
	
	@FindBy(xpath=".//*[@id='content']/div[4]/div[1]/h1")
	WebElement heading_broadcaster_report;
	
	@FindBy(xpath="//a[@class='button' and text()='Print']")
	WebElement print_button;

	@FindBy(xpath="//select[@id='mode' and @name='mode']")
	WebElement mode_drop_Down_option;
	
	@FindBy(id="month_date")
	WebElement month_selecting_option;
	
	@FindBy(xpath="//a[@class='button' and text()='Search']")
	WebElement Search_button;
	
	@FindBy(id="filter_broadcaster")
	WebElement filter_broadcaster;
	
	@FindBy(id="filter_region")
	WebElement filter_region;
	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
//	
//	@FindBy(xpath="")
//	WebElement ;
	
	
	private void click_on_broadcaster_report(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.click(broadcaster_report).build().perform();
	}
	
	public void Verify_element_method() throws IOException{
		GetReportFilePath.DeleteFolderfiles();
		this.click_on_broadcaster_report();
		broadcaster_report_link.click();
		assertEquals(driver.getTitle(), "Broadcaster Report");
		Home_link.isDisplayed();
		broadcaster_report_link.isDisplayed();
		subheading_Average.isDisplayed();
		subheading_Channel_Count.isDisplayed();
		subheading_Product_Package_Name.isDisplayed();
		subheading_Region_Name.isDisplayed();
		subheading_SMS_Activated.isDisplayed();
		subheading_SMS_Closing.isDisplayed();
		subheading_SMS_De_activated.isDisplayed();
		subheading_SMS_Opening.isDisplayed();
		print_button.isDisplayed();
		
		assertEquals(driver.getTitle(), "Broadcaster Report");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");

//		this.click_on_broadcaster_report();
//		print_button.click();

	}

		
	
	
	
	  
	

	
	

}