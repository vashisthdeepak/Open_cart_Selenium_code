package com.reports_As_on_date;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import excelreader.ExcelReader;
import test.baseclass.BaseClass;
import test.baseclass.GetReportFilePath;

public class STB_Transactions extends BaseClass{

	
	@FindBy(xpath = "//a[@class='top' and text()='Reports']")
	WebElement reports;
	
	@FindBy( partialLinkText = "As on date")
	WebElement as_on_date;
	
	@FindBy(partialLinkText="STB Transactions")
	WebElement STB_Transactions;
	
	@FindBy(xpath="//a[text()='Home']")
	WebElement Home_link;
	
	@FindBy(xpath = ".//*[@id='selectoption']")
	WebElement from_to_monthly_yearly_option;
	
	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[2]")
	WebElement Date_of_Generation_first_option;
	
	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[1]")
	WebElement Report_Name_first_option;
	
	@FindBy(xpath = ".//*[@id='form']/table/tbody/tr[1]/td[3]/a")
	WebElement download_first_option;
	
	@FindBy(xpath = ".//*[@id='error_generated']")
	WebElement msg_error;
	
	@FindBy(xpath = ".//*[@id='success']")
	WebElement msg_sucess;
	
	@FindBy(xpath = "//a[@class='button' and text()='Report Generate']")
	WebElement Report_Generate_button;
	
	@FindBy(xpath = "//input[@id='to_date' and @type='text' and @name='filter_date_start']")
	WebElement date_start_box;
	
	@FindBy(xpath=".//*[@id='content']/div[1]/a[2]")
	WebElement STB_transactions_link;
	
	@FindBy(xpath=".//*[@id='date-end']")
	WebElement to_date_option;
	
	@FindBy(xpath="//td[@class='left' and text()='Report Name']")
	WebElement subheading_reports_name;
	
	@FindBy(xpath="//td[@class='left' and text()='Date of Generation']")
	WebElement subheading_Date_of_Generation;
	
	@FindBy(xpath="//td[@class='center' and text()='Download Link']")
	WebElement subheading_Download_Link;
	
	@FindBy(xpath=".//*[@id='content']/div[5]/div[1]/h1")
	WebElement heading_As_On_Date_Report_STB_Transactions;
	
	@FindBy(xpath=".//*[@id='from_date']")
	WebElement date_start_option;
//	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/a[1]/span")
	WebElement date_start_option_back_month;

	
public static PDDocument PDF_Data_Reader() throws Throwable{
		
		PDDocument pdDoc;
		//String value = Read_PDF_name();
		pdDoc = PDDocument.load( new File("D:\\Unzip\\asondate_1.pdf"));
		//System.out.println(pdDoc.getNumberOfPages());
		return pdDoc;
}	
	
	
	
	private void click_on_reports_As_on_date_STB_Transactions(){
		
		Actions act = new Actions(driver);
		act.moveToElement(reports).perform();
		act.moveToElement(as_on_date);
		act.click(STB_Transactions).build().perform();
	}
	
	public void Verify_element_method() throws Throwable{
		GetReportFilePath.DeleteFolderfiles();
		this.click_on_reports_As_on_date_STB_Transactions();
		STB_transactions_link.click();
		assertEquals(driver.getTitle(), "As On Date Report (STB Transactions)");
		Home_link.isDisplayed();
		STB_transactions_link.isDisplayed();
		Report_Generate_button.isDisplayed();
		from_to_monthly_yearly_option.isDisplayed();
		to_date_option.isDisplayed();
		subheading_reports_name.isDisplayed();
		subheading_Date_of_Generation.isDisplayed();
		subheading_Download_Link.isDisplayed();
		heading_As_On_Date_Report_STB_Transactions.isDisplayed();
		assertEquals(driver.getTitle(), "As On Date Report (STB Transactions)");
		Home_link.click();
		assertEquals(driver.getTitle(), "Dashboard");

		this.click_on_reports_As_on_date_STB_Transactions();
		date_start_option.click();
		date_start_option.sendKeys(Keys.ENTER); 
		Report_Generate_button.click();                                                  
		assertTrue(msg_sucess.getText().matches("Report Generated Successfully!"));
		
		String str1=String.valueOf(Report_Name_first_option.getText().subSequence(0, 10));
		System.out.println(str1);
		assertEquals(str1+GetReportFilePath.date_time_stamp(),String.valueOf(Report_Name_first_option.getText().subSequence(0, 20)));
		
		String str5 = String.valueOf(Date_of_Generation_first_option.getText().subSequence(0, 10));
		System.out.println(str5);
		assertEquals(str5,GetReportFilePath.date_time_stamp());

		String str3 = String.valueOf(download_first_option.getText());
		System.out.println(str3);
		assertEquals(str3,"Download");
		
		download_first_option.click();
		
		Thread.sleep(1000);
		GetReportFilePath.FileNameReadUnzip();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		GetReportFilePath.FileNameRead();
		
		String value = GetReportFilePath.Read_PDF_name();
		//System.out.println(value);
		Assert.assertEquals(value, "asondate_1.pdf");
		
		PDFTextStripper g = new PDFTextStripper();
		ExcelReader read = new ExcelReader();
		
		String str4 = read.getsheetnumber(50, 0, 0);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str4));  
		
		String str10 = read.getsheetnumber(50, 0, 1);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str10));  
				
		String str6 = read.getsheetnumber(50, 0, 2);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str6));   
		
		String str7 = read.getsheetnumber(50, 0, 3);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str7)); 
		
		String str8 = read.getsheetnumber(50, 0, 4);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str8));    
		
		String str9 = read.getsheetnumber(50, 0, 5);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str9));   
		
		String str101 = read.getsheetnumber(50, 0, 6);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str101));   
		
		String str11 = read.getsheetnumber(50, 0, 7);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str11));    
		
		String str12 = read.getsheetnumber(50, 0, 8);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str12));   
		
		String str13 = read.getsheetnumber(50, 0, 9);
		assertTrue(g.getText(PDF_Data_Reader()).contains(str13));  
		
		
		
	}
	
	
	public void invalid_method(){
		
		this.click_on_reports_As_on_date_STB_Transactions();
		Report_Generate_button.click();
		assertEquals(msg_sucess.getText(),"No Records in this duration!");
		
		date_start_option.click();
		for(int i=0;i<20;i++){
			date_start_option_back_month.click();
		}
		date_start_option.sendKeys(Keys.ENTER);
		assertEquals("No Records in this duration!", msg_sucess.getText().trim());
	}
			
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
